# LuPySNB
API integration wrappers for Revvity Signals Notebook.

The package contains the three sub packages:

- LuPySNB.model: pydantic classes representing schemas for requests and replies in the Signals Notebook API. These classes are controlling the json serialisation of requests and the deserialisation of json responsesinto Python objects.
- LuPySNB.API: Callable wrappers for invoking API operations, e.g. create an experiment or insert a row in an ADT in an experiment.
- LuPySNB.REST: A wrapping of `requests` operations to encapsulate type casting, connection settings, and authentication.

## Installation

The package is published to our internal Nexus repository (Artifactrix) at:

https://artifactrix.rix.lundbeck.com/repository/rix/simple/

### Using uv

To always use Artifactrix as the default index with `uv`, create a `uv.toml` file in `C:\Users\<USERNAME>\AppData\Roaming\uv` containing:

```toml
[[index]]
url = "https://artifactrix.rix.lundbeck.com/repository/rix/simple/"
default = true
```

Then install the package:

```bash
uv add lupysnb
```

### Using pip

Configure pip to use Artifactrix globally:

```bash
pip config --global set global.index https://artifactrix.rix.lundbeck.com/repository/rix
pip config --global set global.index-url https://artifactrix.rix.lundbeck.com/repository/rix/simple
```

Then install the package:

```bash
pip install lupysnb
```

> **Note:** All Python packages we depend on are proxied and cached in Artifactrix, so they will always be available through the same index.

## Examples
For basic examples on how to use LuPySNB refer to the [Examples](Examples) folder.

## Tests

The project has two test suites located in `tests/`:

- **Unit tests** (`tests/unit/`): Fast, isolated tests using mocked REST clients. Cover the API layer, REST clients, models, requests, and responses.
- **Integration tests** (`tests/integration/`): Run against a live Signals Notebook instance. Require environment configuration (see `tests/integration/README.md`).

### Running tests

```bash
# All tests
uv run python -m pytest tests/

# Unit tests only
uv run python -m pytest tests/unit/

# Integration tests only
uv run python -m pytest tests/integration/

# With coverage report
uv run python -m pytest tests/ --cov=LuPySNB --cov-report=term-missing
```

### Coverage

Overall test coverage is **90%** across 390 tests. Key areas:

| Layer | Coverage |
|-------|----------|
| REST clients (HTTPX sync/async, Requests) | 84–90% |
| API wrappers | 67–98% |
| Models, DTOs, requests, responses | 96–100% |