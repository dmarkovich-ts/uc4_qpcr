from LuPySNB import API, REST
import APIKey


headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)

eid = 'ado-4:9134629d-0cc1-48c8-a9f7-8f4276f327e2'
new_page_name = 'A Test Page'

# create new page
res = API.create_page(REST.RestClientHTTPX(config), eid, new_page_name, 0)
print(res)
page_id = res.data.id

# get pages
res = API.get_pages(REST.RestClientHTTPX(config), eid)
print(res)

# create entity and put it on specific page
entity_name = 'A Test Entity you can delete'
content_html = ('<p>Some HTML content</p>'
                '<span style="color: red;">Some red text</span>')
res = API.add_file_attachment(REST.RestClientHTTPX(config), eid, entity_name, 'text/html', content_html)
entity_id = res.data.id
API.put_entity_on_page(REST.RestClientHTTPX(config), entity_id,  page_id, 0)