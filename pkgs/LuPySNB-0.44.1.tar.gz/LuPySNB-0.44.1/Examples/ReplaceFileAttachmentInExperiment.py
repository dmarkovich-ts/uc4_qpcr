from io import BytesIO
from LuPySNB import API, REST
import APIKey
import os

print(os.getcwd())

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)
client = REST.RestClientHTTPX(config)

#experiment_name = "SNB:EXPBR-719"

# Add attachment
with open(".\\Resources\\Eventyr.docx", 'br') as f:
    buffer = f.read()
eid = "ado-4:9134629d-0cc1-48c8-a9f7-8f4276f327e2"
filename = 'a very long name that will be longer than 100 characters when url encoded.docx'

r = API.add_file_attachment(client, eid, filename, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', BytesIO(buffer))

# Replace attachment
with open(".\\Resources\\Eventyr med Pålæg.docx", 'br') as f:
    buffer = f.read()
r = API.replace_file_attachment(client, eid, filename, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', BytesIO(buffer))
attachment_eid = r.data.id
