import asyncio
from LuPySNB import API, REST
import APIKey
from LuPySNB.model.requests.CreateContainerRequest import CreateContainerRequest
from LuPySNB.model.responses import CreateContainerResponse

import smtplib  # smtp servers
from email.mime.text import MIMEText  # email composition
from email.mime.multipart import MIMEMultipart  # email composition
from email.mime.application import MIMEApplication  # email composition

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers, auto_expand=True, next_limit=15)


def _main():
    with (REST.RestClientHTTPX(config) as client):
        container = API.Container.get_container(client, '994234bc-920a-4303-b3f9-823d50d15fad')

        containers_modified_since_yesterday = API.Container.get_containers_by_status_and_days_since_edited(client,
                                                                                                           'Reagents (SNB)',
                                                                                                           'AVAILABLE',
                                                                                                           1)
        for container in containers_modified_since_yesterday.data:
            print(f'Found container {container.attributes.name} as eid {container.attributes.eid}')


def _test_getting_field():
    with (REST.RestClientHTTPX(config) as client):
        container = API.Container.get_container(client, 'container:994234bc-920a-4303-b3f9-823d50d15fad:ivt')
        tare_weight = API.Container.get_value_for_field(container, 'Tare Weight')
        print(f"Tare weight is {tare_weight}")


def _test_update_amount():
    with (REST.RestClientHTTPX(config) as client):
        container = API.Container.get_container(client, 'container:994234bc-920a-4303-b3f9-823d50d15fad:ivt')
        amount = 68.0
        update_container = API.Container.update_amount(client, container.data.attributes.id,
                                                       container.data.attributes.digest, amount)
        print("container updated")


def _test_creating_container_optimized() -> CreateContainerResponse:
    with REST.RestClientRequests(config) as client:
        vial_type = API.Inventory.get_inventory_types_by_name(client, 'container', 'Vial')[0]
        location_eid = '3a6f077d-0e27-4aa1-91f6-68d262dbf199'  # for Valby/G1/R1/K002/S03
        barcode = 'CAHL_import_20240916_4'
        content_eid = 'batch:6663046bda654d2755b64732'
        amount = 100
        coordinate_x = 2
        coordinate_y = 2
        fields = {'Gross Weight': amount,
                  'Inventory Security': 'Chemistry',
                  'Supplier': 'WuXi',
                  'Supplier Catalog Number': '12345'}

        created_container = API.Container.create_container(client, vial_type.id, 100, location_eid, barcode,
                                                           content_eid, fields, vial_type.get_field_map(),
                                                           coordinate_x, coordinate_y)

    return ''


async def _test_creating_container_optimized_async() -> CreateContainerResponse:
    async with (REST.RestClientAsyncHTTPX(config) as client):
        vial_type = (await API.Inventory.get_inventory_types_by_name_async(client, 'container', 'Test Vial'))[0]
        barcode = 'CAHL_import_20240916_9'
        content_eid = 'batch:66ec17ad7a22b309d98a7e5c'
        amount = 100
        coordinate_x = None
        coordinate_y = None
        print(vial_type.get_field_map())
        fields = [
            ('Gross Weight', (amount, str(amount) + 'g')),
            ('Inventory Security', 'Default'),
            ('Supplier', 'WuXi'),
            ('Supplier Catalog Number', '12345'),
            ('Link', ('DR', 'https://dr.dk'))
        ]

        location = await API.Inventory.get_inventory_location_by_path_async(client, '/Valby Test/G1')
        created_container = await API.Container.create_container_async(client, vial_type.id, 100,
                                                                       location.data.attributes.id,
                                                                       barcode, content_eid, fields,
                                                                       vial_type.get_field_map(), coordinate_x,
                                                                       coordinate_y)

    return created_container


def _test_creating_container_optimized_non_grid_location() -> CreateContainerResponse:
    with REST.RestClientRequests(config) as client:
        vial_type = API.Inventory.get_inventory_types_by_name(client, 'container', 'Vial')[0]
        barcode = 'CAHL_import_20240919_10'
        content_eid = 'batch:66ec17ad7a22b309d98a7e5c'
        amount = 100
        fields = [
            ('Gross Weight', amount),
            ('Inventory Security', 'Default'),
            ('Supplier', 'WuXi'),
            ('Supplier Catalog Number', '12345'),
            ('Concentration', '1.e-003 %')
        ]

        location = API.Inventory.get_inventory_location_by_path(client, '/Valby Test/G1')
        created_container = API.Container.create_container(client, vial_type.id, 100, location.data.attributes.id,
                                                           barcode, content_eid, fields,
                                                           vial_type.get_field_map())

    return created_container


async def _test_creating_container_optimized_non_grid_location_async() -> CreateContainerResponse:
    async with (REST.RestClientAsyncHTTPX(config) as client):
        vial_type = (await API.Inventory.get_inventory_types_by_name_async(client, 'container', 'Vial'))[0]
        barcode = 'CAHL_import_20240916_7'
        content_eid = 'batch:66ec17ad7a22b309d98a7e5c'
        amount = 100
        fields = [('Gross Weight', amount),
                  ('Inventory Security', 'Chemistry'),
                  ('Supplier', 'WuXi'),
                  ('Supplier Catalog Number', '12345')]
        location = await API.Inventory.get_inventory_location_by_path(client, '/Valby Test/G1')
        field_map = await API.Container.get_container_type_field_map_by_id_async(client, vial_type.id)
        created_container = await API.Container.create_container_async(client, vial_type.id, 100, location.id,
                                                                       barcode, content_eid, fields, field_map)

    return created_container


def _test_getting_location():
    with (REST.RestClientHTTPX(config) as client):
        location = API.Inventory.get_inventory_location_by_path(client, '/Valby/G1')
        print(location.model_dump())


def _test_getting_location_by_eid():
    with (REST.RestClientHTTPX(config) as client):
        location = API.Inventory.get_inventory_location_by_eid(client, '1234859a-f111-4245-a5b8-8eee708ff177')
        print(location.model_dump())


def _test_getting_container_type_by_name():
    with (REST.RestClientHTTPX(config) as client):
        container_type = API.Container.get_container_type_by_name(client, 'Vial')
        print(container_type.model_dump())


def _test_checking_out_container_to_user():
    with (REST.RestClientHTTPX(config) as client):
        container_eid = '0ecb8666-7ee4-4c6e-a397-2aca06bb5a62'
        action = 'checkout'
        digest = API.Container.get_container(client, container_eid).data.attributes.digest
        force = False
        location_eid = '8754a8f4-34a5-4bac-8f40-93a7d22d8d42'  # checked out location
        user_id = '109'
        container = API.Container.update_container_status(client, container_eid, action, force, digest, location_eid,
                                                          user_id)
        print(f"Container {container_eid} checked out to user with id {user_id} and location {location_eid}")


async def _test_checking_out_container_to_user_async():
    async with (REST.RestClientAsyncHTTPX(config) as client):
        container_eid = '0ecb8666-7ee4-4c6e-a397-2aca06bb5a62'
        action = 'checkout'
        digest = (await API.Container.get_container_async(client, container_eid)).data.attributes.digest
        force = False
        location_eid = '8754a8f4-34a5-4bac-8f40-93a7d22d8d42'
        user_id = '109'
        container = await API.Container.update_container_status_async(client, container_eid, action, force, digest,
                                                                      location_eid, user_id)
        print(f"Container {container_eid} checked out to user with id {user_id} and location {location_eid}")


def _test_checking_container_in_to_grid():
    with (REST.RestClientHTTPX(config) as client):
        container_eid = '0ecb8666-7ee4-4c6e-a397-2aca06bb5a62'
        action = 'checkin'
        digest = API.Container.get_container(client, container_eid).data.attributes.digest
        force = False
        location_eid = 'b83d0c02-e19c-4870-9aeb-a8259cac6864'
        coordinate_x = 2
        coordinate_y = 0
        user_id = None
        container = API.Container.update_container_status(client, container_eid, action, force, digest, location_eid,
                                                          user_id, coordinate_x, coordinate_y)
        return ''


async def _test_checking_container_in_to_grid_async():
    async with (REST.RestClientAsyncHTTPX(config) as client):
        container_eid = '0ecb8666-7ee4-4c6e-a397-2aca06bb5a62'
        action = 'checkin'
        digest = (await API.Container.get_container_async(client, container_eid)).data.attributes.digest
        force = False
        location_eid = 'b83d0c02-e19c-4870-9aeb-a8259cac6864'
        coordinate_x = 2
        coordinate_y = 0
        user_id = None
        container = await API.Container.update_container_status_async(client, container_eid, action, force, digest,
                                                                      location_eid, user_id, coordinate_x, coordinate_y)
        return ''


def _test_checking_container_in_to_non_grid():
    with (REST.RestClientHTTPX(config) as client):
        container_eid = '0ecb8666-7ee4-4c6e-a397-2aca06bb5a62'
        action = 'checkin'
        fetched_container = API.Container.get_container(client, container_eid)
        digest = fetched_container.data.attributes.digest
        force = False
        location_eid = '1234859a-f111-4245-a5b8-8eee708ff177'
        user_id = None
        container = API.Container.update_container_status(client, container_eid, action, force, digest, location_eid,
                                                          user_id)
        return ''


async def _test_checking_container_in_to_non_grid_async():
    async with (REST.RestClientAsyncHTTPX(config) as client):
        container_eid = '0ecb8666-7ee4-4c6e-a397-2aca06bb5a62'
        action = 'checkin'
        fetched_container = await API.Container.get_container_async(client, container_eid)
        digest = fetched_container.data.attributes.digest
        force = False
        location_eid = '1234859a-f111-4245-a5b8-8eee708ff177'
        user_id = None
        container = await API.Container.update_container_status_async(client, container_eid, action, force, digest,
                                                                      location_eid, user_id)


def _test_dispose_container():
    with (REST.RestClientHTTPX(config) as client):
        container_eid = '0ecb8666-7ee4-4c6e-a397-2aca06bb5a62'
        action = 'dispose'
        digest = API.Container.get_container(client, container_eid).data.attributes.digest
        force = False
        container = API.Container.update_container_status(client, container_eid, action, force, digest)
        return ''


async def _test_dispose_container_async():
    async with (REST.RestClientAsyncHTTPX(config) as client):
        container_eid = '0ecb8666-7ee4-4c6e-a397-2aca06bb5a62'
        action = 'dispose'
        digest = (await API.Container.get_container_async(client, container_eid)).data.attributes.digest
        force = False
        container = await API.Container.update_container_status_async(client, container_eid, action, force, digest)
        return ''


def _test_restore_container():
    with (REST.RestClientHTTPX(config) as client):
        container_eid = '0ecb8666-7ee4-4c6e-a397-2aca06bb5a62'
        action = 'restore'
        digest = API.Container.get_container(client, container_eid).data.attributes.digest
        force = False
        container = API.Container.update_container_status(client, container_eid, action, force, digest)
        return ''


async def _test_restore_container_async():
    async with (REST.RestClientAsyncHTTPX(config) as client):
        container_eid = '0ecb8666-7ee4-4c6e-a397-2aca06bb5a62'
        action = 'restore'
        digest = (await API.Container.get_container_async(client, container_eid)).data.attributes.digest
        force = False
        container = await API.Container.update_container_status_async(client, container_eid, action, force, digest)
        return ''


def _test_forced_checking_out_container_to_user():
    with (REST.RestClientHTTPX(config) as client):
        container_eid = '0ecb8666-7ee4-4c6e-a397-2aca06bb5a62'
        action = 'checkout'
        force = True
        location_eid = '8754a8f4-34a5-4bac-8f40-93a7d22d8d42'  # checked out location
        user_id = '109'
        digest = None
        container = API.Container.update_container_status(client, container_eid, action, force, digest, location_eid,
                                                          user_id)
        print(f"Container {container_eid} checked out to user with id {user_id} and location {location_eid}")


def _test_forced_checking_container_in_to_non_grid():
    with (REST.RestClientHTTPX(config) as client):
        container_eid = '0ecb8666-7ee4-4c6e-a397-2aca06bb5a62'
        action = 'checkin'
        force = True
        location_eid = '1234859a-f111-4245-a5b8-8eee708ff177'
        digest = None
        container = API.Container.update_container_status(client, container_eid, action, force, digest, location_eid)
        return ''


def _test_forced_dispose():
    with (REST.RestClientHTTPX(config) as client):
        container_eid = '0ecb8666-7ee4-4c6e-a397-2aca06bb5a62'
        action = 'dispose'
        force = True
        container = API.Container.update_container_status(client, container_eid, action, force)
        return ''


def _test_forced_restore():
    with (REST.RestClientHTTPX(config) as client):
        container_eid = '0ecb8666-7ee4-4c6e-a397-2aca06bb5a62'
        action = 'restore'
        force = True
        container = API.Container.update_container_status(client, container_eid, action, force)
        return ''


def _test_getting_disposed_containers():
    with (REST.RestClientHTTPX(config) as client):
        disposed_containers = API.Container.get_disposed_containers_outside_bin(client, "/Valby_Test_8/G1/Disposed")
    return disposed_containers


async def _test_getting_disposed_containers_async():
    async with (REST.RestClientAsyncHTTPX(config) as client):
        disposed_containers = await API.Container.get_disposed_containers_outside_bin_async(client,
                                                                                            "/Valby_Test_8/G1/Disposed")
    return disposed_containers


def _test_checking_out_disposed_container():
    with (REST.RestClientHTTPX(config) as client):
        container_eid = 'a439866b-0e27-4151-9207-3aa18250e05e'
        action = 'checkout'
        force = True
        location_eid = '8754a8f4-34a5-4bac-8f40-93a7d22d8d42'  # checked out location
        user_id = None
        digest = None
        container = API.Container.update_container_status(client, container_eid, action, force, digest, location_eid,
                                                          user_id)
        print(f"Container {container_eid} checked out to user with id {user_id} and location {location_eid}")


def _test_restoring_checking_out_and_disposing_container():
    with (REST.RestClientHTTPX(config) as client):
        container_eid = 'a439866b-0e27-4151-9207-3aa18250e05e'
        force = False

        # restore
        digest = API.Container.get_container(client, container_eid).data.attributes.digest
        container = API.Container.update_container_status(client, container_eid, 'restore', force, digest)

        # checkout
        digest = API.Container.get_container(client, container_eid).data.attributes.digest
        location_eid = '1e6e33c9-1492-4126-a6a8-c3307a3fda92'
        container = API.Container.update_container_status(client, container_eid, 'checkout', force, digest,
                                                          location_eid)

        # dispose
        digest = API.Container.get_container(client, container_eid).data.attributes.digest
        container = API.Container.update_container_status(client, container_eid, 'dispose', force, digest)

        return ''


def _test_getting_containers_users_have_not_checked_out_yet():
    with (REST.RestClientHTTPX(config) as client):

        # Get orphaned containers per order requestor
        user_container_tracker = {}
        containers = API.Container.get_containers_by_path_status_and_days_since_created(client, "Reagents Chemistry",
                                                                                        "/Valby/G1", "AVAILABLE", 1)
        for container in containers.data:

            orders = API.Inventory.get_order_by_container_name(client, container.attributes.name)
            if len(orders.data) == 0:
                continue

            user_id = orders.data[0].attributes.tags['order.Requestor']
            user = API.User.get_user_by_id(client, user_id)
            email = user.data.attributes.email

            if email not in user_container_tracker:
                user_container_tracker[email] = [container]
            else:
                user_container_tracker[email].append(container)

        # for each user, send an email reminding them to check out the containers received on their behalf
        smtp_server = 'smtp-relay.lundbeck.com'
        with smtplib.SMTP(smtp_server) as s:
            for user in user_container_tracker:
                email = None
                email = MIMEMultipart(
                    'alternative')  # we construct a multipart MIME object. With 'alternative' we supply two alternate versions of the email: plain text and html.
                email['Subject'] = "Container check-out reminder"
                email['Sender'] = "no-reply@lundbeck.com"
                email['To'] = "cahl@lundbeck.com"  # We construct a single string with the recipients.

                html_message = '<h3>Container check-out reminder<br><br></h3><p>You are receiving this email because your containers have been received but you have not checked them out.<br><br>Please check out the containers below, following the documentation in the "Reagent Check Out" section in the slides <a href="https://hlundbeck.sharepoint.com/:b:/s/GWSBioELNReplacement/EebtXyGYtUVNpn323K8noYIB0Tqi473nKwtxj40HQSrClA?e=4DbE3r">here</a>.</p><table border="1" cellspacing="2" cellpadding="2"><thead><tr><td>Containers</td></tr></thead><tbody>'
                for container in user_container_tracker[user]:
                    container_eid = container.attributes.eid.split(':')[1]
                    container_url = f'https://lundbeck-sandbox.signalsresearch.revvitycloud.eu/inventory/container/{container_eid}'
                    this_row = f'<tr><td><a href="{container_url}">{container.attributes.tags["fields.Barcode"]}</a><br>'
                    html_message = html_message + this_row

                html_message = html_message + '</td></tr></tbody></table>'

                part_html = MIMEText(html_message, 'html')
                email.attach(part_html)  # We add the payload

                s.send_message(email)

        print("got em")


def _test_getting_containers_by_type():
    with (REST.RestClientHTTPX(config) as client):
        containers = API.Container.get_containers_by_type(client, 'Cell Cryotube')
        for container in containers.data:
            print(
                f'Found container {container.attributes.name} as eid {container.attributes.eid[10:-4]} {container.attributes.eid}')


def _test_update_container():
    with (REST.RestClientHTTPX(config) as client):
        for container_match in API.Container.get_containers_by_type(client, 'Cell Cryotube').data:
            print(f'Found container {container_match.attributes.name} as eid {container_match.attributes.eid[10:-4]}')
            container = API.Container.get_container(client, container_match.attributes.eid[10:-4])
            fields = [('Inventory Security', 'MolScreen')]
            updated_container = API.Container.update_container(client, container.data.id,
                                                               container.data.attributes.digest, fields)
            print(updated_container.model_dump())


def _test_update_location():
    def get_all_child_locations(_client, location_path: str):
        for _location in API.Inventory.get_inventory_location_children_by_path(_client, location_path, 'location').data:
            yield from get_all_child_locations(client, location_path + '/' + _location.attributes.name)
            yield _location

    with REST.RestClientHTTPX(config) as client:
        for child_location in get_all_child_locations(client, "/Valby/G2/K032"):
            location = API.Inventory.get_inventory_location_by_eid(client, child_location.id)
            location_type = API.Inventory.get_inventory_types_by_name(client, 'location',
                                                                      location.data.attributes.typeName)[0]
            field_map = location_type.get_field_map()
            updated_location = API.Inventory.update_inventory_location(client, location.data.id, location.data.attributes.digest,
                                                    [('Inventory Security', 'MolScreen')],
                                                    field_map)
            print(updated_location.data.attributes.name)           

_test_update_location()
