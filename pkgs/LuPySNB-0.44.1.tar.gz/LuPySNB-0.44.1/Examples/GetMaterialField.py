import asyncio
import sys
from pathlib import Path

# Use the checkout when this example is run as a script, even if LuPySNB is
# also installed in the active virtual environment.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from LuPySNB import API
import LuPySNB.REST as REST
import APIKey

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers, auto_expand=True, next_limit=15)


library_name = "Biosample Containers"
asset_id = "SNB_BSC-13"


def _main():
    with REST.RestClientHTTPX(config) as client:
        # 1. Resolve the asset ID into a material instance.
        material_instance = API.MaterialLibrary.get_asset(client, library_name, asset_id)
        material_library_type = material_instance.data.attributes.fields[
            "Material Library Type"
        ].value
        print(f"Material library type: {material_library_type}")

        # 2. Extract the instance EID and retrieve the same instance by EID.
        instance_eid = material_instance.data.attributes.eid
        material_instance_from_eid = API.MaterialLibrary.get_material(client, instance_eid)

        print(API.MaterialLibrary.get_material_field_values(
            client, material_instance_from_eid, "Animal Batch.Species"))

async def _main_async():
    async with REST.RestClientAsyncHTTPX(config) as client:
        # 1. Resolve the asset ID into a material instance.
        material_instance = await API.MaterialLibrary.get_asset_async(client, library_name, asset_id)
        material_library_type = material_instance.data.attributes.fields[
            "Material Library Type"
        ].value
        print(f"Async material library type: {material_library_type}")

        # 2. Extract the instance EID and retrieve the same instance by EID.
        instance_eid = material_instance.data.attributes.eid
        material_instance_from_eid = await API.MaterialLibrary.get_material_async(client, instance_eid)


        print(await API.MaterialLibrary.get_material_field_values_async(
            client, material_instance_from_eid, "Animal Batch"))

        print(await API.MaterialLibrary.get_material_field_values_async(
                    client, material_instance_from_eid, "Matrix"))

        print(await API.MaterialLibrary.get_material_field_values_async(
                            client, material_instance_from_eid, "Animal Batch.Strain attribute"))


_main()
asyncio.run(_main_async())
