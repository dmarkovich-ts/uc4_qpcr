from LuPySNB import API, REST
from LuPySNB.model.DTOs.Query import QueryMatch, QueryDateRange, QueryExists, QueryIn, AndQueryTerm, Query
from LuPySNB.model.responses.EntityDescriptorList import EntityDescriptorList, EntityDescriptorListFromQuery
import APIKey

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers, auto_expand=True, next_limit=4)

query = Query(query=AndQueryTerm.create(
        [QueryIn[str].create('fields.Domain', ['Chemistry'], 'keyword', 'text', 'tags'),
         QueryMatch[str].create('type', 'experiment', 'keyword', as_type='text'),
         QueryDateRange.create('stateAt', '2023-09-30', '2024-12-31')]))

with REST.RestClientHTTPX(config) as client:
    resp = client.invoke_rest_post('entities/search?source=SN', query, EntityDescriptorListFromQuery, True)
    print(resp)
