from LuPySNB import API, REST
import APIKey
from LuPySNB.API.Entity import EntityType, EntityOption
from datetime import datetime

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers, auto_expand=True, next_limit=100)

client = REST.RestClientHTTPX(config)

exp = API.get_entity_by_id(client, 'experiment:5c95429b-8b5b-4793-8ef3-46bd104d9689')

print(exp.data.relationships['pdf'])

user = API.get_user_by_id(client, exp.data.relationships['owner'].data.id )

print(user.data.attributes.alias)


