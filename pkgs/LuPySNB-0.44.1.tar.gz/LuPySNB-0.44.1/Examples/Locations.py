from LuPySNB import API, REST
import APIKey

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)

def create_cryoboxes():
    with REST.RestClientRequests(config) as client:
        rack_type = API.Inventory.get_inventory_types_by_name(client, "location", "Rack")[0]
        shelf_type = API.Inventory.get_inventory_types_by_name(client, "location", "Shelf")[0]
        cryo_box_type = API.Inventory.get_inventory_types_by_name(client, "location", "Cryobox")[0]
        mol_screen_freezer_id = "725a1e91-079e-4d8e-9765-973bcd66cabf"

        box_no = 0
        for rack_name in ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N"]:
            rack_id = API.Inventory.create_inventory_location(client, f"{rack_name}", None, None, None,
                                                              mol_screen_freezer_id, rack_type.id,
                                                              {"Inventory Security": "Default"},
                                                              rack_type.get_field_map()).data.id
            for shelf_no in range(1, 12):
                box_no += 1
                shelf_id = API.Inventory.create_inventory_location(client, f"Shelf {shelf_no}", None, None, None,
                                                                   rack_id, shelf_type.id,
                                                                   {"Inventory Security": "Default"},
                                                                   shelf_type.get_field_map()).data.id

                box_id = API.Inventory.create_inventory_location(client, f"Cryobox {box_no}", f"CB{box_no:05d}", 9, 9,
                                                                 shelf_id, cryo_box_type.id,
                                                                 {"Inventory Security": "Default"}, cryo_box_type.get_field_map())
                print(f"Created Cryobox {box_no} with ID {box_id.data.id} and barcode {box_id.data.attributes.barcode } in Shelf {shelf_id} of Rack {rack_id}")
    pass

def get_location_by_name():
    with REST.RestClientRequests(config) as client:
        location = API.Inventory.get_inventory_location_by_path(client, "/Valby/G1/R1/K001/S02")
        return location.data

b = get_location_by_name()
c = b.get_path()

print(c)