from LuPySNB import API, REST
import APIKey


headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)
client = REST.RestClientHTTPX(config)

eid = 'ado-4:f8d3d640-3b0f-4ff2-960e-afd7a753e10e'

response = API.Entity.close_entity(client, eid, 'A well conducted experiment')
print(response)

response = API.Entity.reopen_entity(client, eid, 'Something went wrong')
print(response)
