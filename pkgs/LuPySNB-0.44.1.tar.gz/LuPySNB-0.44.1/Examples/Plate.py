import asyncio

from LuPySNB import API, REST
from LuPySNB.model.DTOs.PlateContainer import PlateContainer
from LuPySNB.model.requests.PlateUpdateRequest import PlateUpdateRequest
import APIKey

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers, auto_expand=True, next_limit=15)


def _main():
    with REST.RestClientHTTPX(config) as client:
        plate_container = API.Plate.get_plate_container(client, 'plateContainer:c0da965b-79f6-45a0-bb42-ca5881d27383')

        parents = [item for item in plate_container.included if item.attributes.type == 'experiment']
        print(parents[0].id if len(parents) == 1 else 'No parent experiment found')

        annotation_layers_map = plate_container.get_annotation_layer_map()
        print(annotation_layers_map)

        plates = API.Plate.get_plates_from_plate_container(client, 'plateContainer:c0da965b-79f6-45a0-bb42-ca5881d27383')
        print (plates)
        digest = plates.digest

        for plate in plates.data:
            print(f'Found plate {plate.attributes.name} as eid {plate.attributes.eid}')

            for annotation_layer_name in annotation_layers_map.keys():
                match annotation_layer_name:
                    case 'SampleConc':
                        plate_update_request = PlateUpdateRequest.create(name=plate.attributes.name,
                                                                         annotations_layers_map=annotation_layers_map,
                                                                         annotation_layers=[(annotation_layer_name,
                                                                                             [('A1', (9, 'molar'))])])
                    case 'Channel 1':
                        probe_name = 'SNB:PR-3'
                        probe_id = API.MaterialLibrary.get_asset(client, 'LU Primers', probe_name).data.id
                        plate_update_request = PlateUpdateRequest.create(name=plate.attributes.name,
                                                                         annotations_layers_map=annotation_layers_map,
                                                                         annotation_layers=[(annotation_layer_name,
                                                                                             [('A1', ('asset', probe_id, probe_name))])])
                    case 'Well Format':
                        plate_update_request = PlateUpdateRequest.create(name=plate.attributes.name,
                                                                         annotations_layers_map=annotation_layers_map,
                                                                         annotation_layers=[(annotation_layer_name,
                                                                                             [('A1', "Standard")])])
                    case 'Replicate':
                        plate_update_request = PlateUpdateRequest.create(name=plate.attributes.name,
                                                                         annotations_layers_map=annotation_layers_map,
                                                                         annotation_layers=[(annotation_layer_name,
                                                                                             [('A1', 42)])])
                    case 'Reference':
                        plate_update_request = PlateUpdateRequest.create(name=plate.attributes.name,
                                                                         annotations_layers_map=annotation_layers_map,
                                                                         annotation_layers=[(annotation_layer_name,
                                                                                             [('A1', 'Just a reference')])])
                    case _:
                        plate_update_request = None

                if plate_update_request:
                    updated_plate = API.Plate.update_plate(client, 'plateContainer:c0da965b-79f6-45a0-bb42-ca5881d27383',
                                                           plate.attributes.name, plate_update_request, digest=digest)
                    print(updated_plate)
                    digest = updated_plate.digest

_main()

