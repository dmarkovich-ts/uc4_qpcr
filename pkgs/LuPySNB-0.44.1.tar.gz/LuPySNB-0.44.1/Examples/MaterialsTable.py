from LuPySNB import API, REST
import APIKey
import asyncio

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)

experiment_name = 'SNB:EXP-76'
materials_table_name = 'Compounds-4'
materials_library_name = 'Lu Compounds'
cell_key = 'a0ca61cd-d45d-4a72-a10f-38843d3d8485'

def _main():
    with REST.RestClientRequests(config) as client:
        experiment_eid = API.Experiment.get_experiment_id_by_name(client, experiment_name, False)


    # create a materials table
    with REST.RestClientRequests(config) as client:
        res = API.create_materials_table(client, materials_library_name, experiment_eid, materials_table_name)
        print(res)
        materials_table_id = res.data.id

    # add a single row to a materials table
    material_id = 'AF12345-1'
    cells = [{"key": cell_key, "value": True}]
    with REST.RestClientRequests(config) as client:
        res = API.add_materials_table_row(client, materials_table_id, material_id)
        print(res)

    # add multiple rows to a materials table
    material_ids = ['AF12346-1', 'AF12347-1']
    cells = [[{"key": cell_key, "value": False}], [{"key": cell_key, "value": True}]]
    with REST.RestClientRequests(config) as client:
        res = API.add_multiple_materials_table_row(client, materials_table_id, material_ids, cells)
        print(res)

    with REST.RestClientRequests(config) as client:
        materials_table_eid = API.get_experiment_materials_table_id_by_name(client, experiment_eid, materials_table_name)
        res = API.get_materials_table_data(client, materials_table_eid)
        print('Here is the materials table data:')
        for row in res.data:
            for cell in row.attributes.cells:
                print(cell.content)

    # register materials in table

    with REST.RestClientRequests(config) as client:
        experiment_eid = API.Experiment.get_experiment_id_by_name(client, experiment_name, False)
        materials_table_eid = API.get_experiment_materials_table_id_by_name(client, experiment_eid, materials_table_name)
        materials_table_data = API.get_materials_table_data(client, materials_table_eid)

        for row in materials_table_data.data:
            if not row.attributes.materialId:
                print(API.register_material(client, materials_table_eid, row.id))


async def _main_async():
    experiment_name = 'SNB:EXP-133'
    materials_table_name = 'Materials Table'

    async with REST.RestClientAsyncHTTPX (config) as client:
        experiment_eid = await API.Experiment.get_experiment_id_by_name_async(client, experiment_name, False)
        materials_table_eid = await API.get_experiment_materials_table_id_by_name_async(client, experiment_eid,
                                                                                        materials_table_name)
        materials_table_data = await API.get_materials_table_data_async(client, materials_table_eid)

        for row in materials_table_data.data:
            if not row.attributes.materialId:
                print(await API.register_material_async(client, materials_table_eid, row.id))

#asyncio.run(_main_async())
_main()