import asyncio

from LuPySNB import API, REST
import APIKey

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers, auto_expand=True, next_limit=15)


def _main():
    with REST.RestClientHTTPX(config) as client:
        asset = API.MaterialLibrary.get_asset(client, 'Lu Cell Lines', 'SNB:CL-8')
        print(asset)
        print(f'Found asset {asset.data.attributes.name} as eid {asset.data.attributes.eid}')

        assets = API.MaterialLibrary.get_assets_by_name(client, '655f4d8b26ca2b5be0b63dd4',
            ['00905-09585', '00902-09588', '00904-09587', '00903-09586', '00883-09484', '00883-09483', '00883-09482',
             '00883-09480', '00883-09478', '00883-09272', '00883-09271', '00841-09250', '00841-09249', '00841-09143',
             '00841-08851', '00841-08724', '00841-08723', '00841-08722', '00841-08721', '00841-08712', '00841-08543',
             '00813-08706', '00813-08705', '00813-08704', '00813-08655', '00813-08654', '00813-08653', '00813-08652',
             '00813-08651', '00813-08650', '00813-08649', '00813-08648', '00813-08174', '00143-02472', '00143-02471',
             '00143-02470', '00143-02469', '00021-01105', '00021-01104', '00021-01103'])

        print(len(assets.data))

        batch = API.MaterialLibrary.get_batch(client, 'Lu Cell Lines', 'SNB:CL-8-0001')
        print(batch)
        print(f'Found batch {batch.data.attributes.name} as eid {batch.data.attributes.eid}')

        batch_list = API.MaterialLibrary.get_batches(client, 'Lu Cell Lines', 'SNB:CL-8')
        print('Found batches:')
        for b in batch_list.data:
            print(f'{b.attributes.name} as eid {b.attributes.eid}')


async def _main_async():
    async with REST.RestClientAsyncHTTPX(config) as client:
        asset = await API.MaterialLibrary.get_asset_async(client, 'Lu Cell Lines', 'SNB:CL-8')
        print(asset)
        print(f'Found asset {asset.data.attributes.name} as eid {asset.data.attributes.eid}')

        assets = await API.MaterialLibrary.get_assets_by_name_async(client, '655f4d8b26ca2b5be0b63dd4',
                                                        ['00905-09585', '00902-09588', '00904-09587', '00903-09586',
                                                         '00883-09484', '00883-09483', '00883-09482',
                                                         '00883-09480', '00883-09478', '00883-09272', '00883-09271',
                                                         '00841-09250', '00841-09249', '00841-09143',
                                                         '00841-08851', '00841-08724', '00841-08723', '00841-08722',
                                                         '00841-08721', '00841-08712', '00841-08543',
                                                         '00813-08706', '00813-08705', '00813-08704', '00813-08655',
                                                         '00813-08654', '00813-08653', '00813-08652',
                                                         '00813-08651', '00813-08650', '00813-08649', '00813-08648',
                                                         '00813-08174', '00143-02472', '00143-02471',
                                                         '00143-02470', '00143-02469', '00021-01105', '00021-01104',
                                                         '00021-01103'])

        print(len(assets.data))

        batch = await API.MaterialLibrary.get_batch_async(client, 'Lu Cell Lines', 'SNB:CL-8-0001')
        print(batch)
        print(f'Found batch {batch.data.attributes.name} as eid {batch.data.attributes.eid}')

        batch_list = await API.MaterialLibrary.get_batches_async(client, 'Lu Cell Lines', 'SNB:CL-8')
        print('Found batches:')
        for b in batch_list.data:
            print(f'{b.attributes.name} as eid {b.attributes.eid}')

_main()
asyncio.run(_main_async())
