from LuPySNB import API, REST
import APIKey
from LuPySNB.model.requests.MaterialAssetRequest import MaterialAssetRequest
import time

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)
client = REST.RestClientHTTPX(config)

cell_line_lib = API.MaterialLibrary.get_material_library_by_name(client, 'Lu Cell Lines')
print(cell_line_lib)

protocols = API.get_entities_by_name(client, 'Dummy protocol', '9', False)
protocol = protocols.data[0].attributes

request = MaterialAssetRequest.create(None, 'Salva-Batch-4', [], [('Cell Line Name', 'Test from API With Dup 2'), ('Species', 'Human'), ('Vendor', 'Charles River Laboratories'), ('Protocol', (protocol.eid, protocol.name, protocol.type))],
                               cell_line_lib.get_material_library_asset_field_map(),
                               [('Assay Ready', 'Yes'), ('Passage No.', "1")], cell_line_lib.get_material_library_batch_field_map())
print(request)
#print(API.create_asset(client, 'Lu Cell Lines', request))
start_time = time.perf_counter()
for i in range(0, 2):
    print(API.create_asset(client, 'Lu Cell Lines', request))
end_time = time.perf_counter()
print(f'Time spent: {end_time - start_time}')
duplicates = API.unique_check_asset(client, 'Lu Cell Lines', request).data
print(f'Found {len(duplicates)} duplicates:')
for dup in duplicates:
    print(dup.id)

