import asyncio

from LuPySNB import API, REST
import APIKey
from LuPySNB.model.requests.MaterialBatchRequest import MaterialBatchRequest

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)


def _main():
    with REST.RestClientHTTPX(config) as client:
        cell_line_lib = API.MaterialLibrary.get_material_library_by_name(client, 'Lu Cell Lines')

        request = MaterialBatchRequest.create(None,  [('Assay Ready', 'Yes'), ('Passage No.', "42")],
                                                 cell_line_lib.get_material_library_batch_field_map())
        print(request)
        print(API.create_batch(client, 'Lu Cell Lines', 'SNB:CL-8', request))


async def _main_async():
    async with REST.RestClientAsyncHTTPX(config) as client:
        cell_line_lib = await API.MaterialLibrary.get_material_library_by_name_async(client, 'Lu Cell Lines')

        request = MaterialBatchRequest.create(None, [('Assay Ready', 'Yes'), ('Passage No.', "42")],
                                              cell_line_lib.get_material_library_batch_field_map())
        print(request)
        print(await API.create_batch_async(client, 'Lu Cell Lines', 'SNB:CL-8', request))


_main()
asyncio.run(_main_async())
