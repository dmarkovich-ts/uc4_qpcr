import asyncio

from LuPySNB import API, REST
import APIKey
from httpx import Response, Request
from requests import Response as RequestsResponse
import time


headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

# disclaimer: this is a simple example of how to use event hooks to log request and response times
# there could probably be implications regarding thread safety etc. with this specific approach

# Dictionary to store request timestamps
request_times = {}


#
# httpx sync
#

def log_request_time(r: Request):
    # Store the timestamp when request is sent
    request_times[id(r)] = time.time()
    print(f"Request sent: {r.url}")

def print_status_code(r: Response):
    # Print the status code of the response
    print(f"Response status code: {r.status_code}")

def log_response_time(r: Response):
    # Get the request object associated with this response
    req_id = id(r.request)
    if req_id in request_times:
        elapsed = time.time() - request_times[req_id]
        print(f"Response received: {r.url} - Time: {elapsed:.4f}s")
        # Clean up to prevent memory leaks
        del request_times[req_id]
    else:
        print(f"Response received: {r.url} - No timing data")

config_httpx = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers,
    request_event_hooks=[log_request_time],
    response_event_hooks=[log_response_time, print_status_code])

#
# httpx async
#

async def log_request_time_async(r: Request):
    request_times[id(r)] = time.time()
    print(f"Async request sent: {r.url}")

async def print_status_code_async(r: Response):
        print(f"Response status code: {r.status_code}")

async def log_response_time_async(r: Response):
    req_id = id(r.request)
    if req_id in request_times:
        elapsed = time.time() - request_times[req_id]
        print(f"Async response received: {r.url} - Time: {elapsed:.4f}s")
        del request_times[req_id]

async_config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers,
    request_event_hooks=[log_request_time_async],
    response_event_hooks=[log_response_time_async, print_status_code_async])

#
# requests
#
# note, requests only supports response event hooks, not request event hooks

def print_status_code_requests(r: RequestsResponse, *args, **kwargs):
    # Print the status code of the response
    print(f"Response status code: {r.status_code}")

config_requests = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers,
    response_event_hooks=[print_status_code_requests])


#
# Main functions
#

def _main_httpx_sync():
    # Create experiment in Signals
    with REST.RestClientHTTPX(config_httpx) as client:
        r1 = API.Experiment.create_experiment(client, {
            'description': 'Antibody batch data sheet',
            'department': 'Production',
            'Project': 'LU016 - 725 - TTBK1/2'}, 'Medicinal Chemistry', 'ALGJ')

        print(r1)

def _main_requests():
    # Create experiment in Signals
    with REST.RestClientRequests(config_requests) as client:
        r1 = API.Experiment.create_experiment(client, {
            'description': 'Antibody batch data sheet',
            'department': 'Production',
            'Project': 'LU016 - 725 - TTBK1/2'}, 'Medicinal Chemistry', 'ALGJ')

        print(r1)


async def _main_httpx_async():
    # Create experiment in Signals
    async with REST.RestClientAsyncHTTPX(async_config) as client:
        r1 = await API.Experiment.create_experiment_async(client, {
            'description': 'Antibody batch data sheet',
            'department': 'Production',
            'Project': 'LU016 - 725 - TTBK1/2'
        }, 'Medicinal Chemistry', 'ALGJ')

    print(r1)


_main_httpx_sync()
_main_requests()
asyncio.run(_main_httpx_async())