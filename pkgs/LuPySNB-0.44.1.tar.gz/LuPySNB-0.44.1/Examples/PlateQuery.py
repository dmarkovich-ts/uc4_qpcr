import json
from LuPySNB import API, REST
import APIKey

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers, auto_expand=True, next_limit=15)

plate_container_eid = 'plateContainer:84e2fbfc-ca02-43a3-a63d-496c4fb93aa6'

def _main():
    with REST.RestClientHTTPX(config) as client:
        plate_container = API.Plate.get_plate_container(client, plate_container_eid)
        parents = [item for item in plate_container.included if item.attributes.type == 'experiment']
        print(f'Parent experiment: {parents[0].id if len(parents) == 1 else "No parent experiment found"}')

        plate_map = {}
        instrument_method = None
        plates = API.Plate.get_plates_from_plate_container(client, plate_container_eid)
        object_cache = {}
        for plate in plates.data:
            print(f'Found plate {plate.attributes.name} as eid {plate.attributes.eid}')

            for annotation_layer in plate.attributes.annotationLayers:
                print(f'Processing layer: {annotation_layer.name}')
                if annotation_layer.dataType == 'ATTRIBUTE':
                    if annotation_layer.name == 'Instrument':
                        instrument_method = annotation_layer.value
                else:
                    for well in annotation_layer.wells or []:
                        if well and well.content:
                            if not well.wellId in plate_map:
                                plate_map[well.wellId] = {}

                            if not well.content.value in object_cache:
                                object_cache[well.content.value] = API.get_material(client, well.content.value)

                            if annotation_layer.name == "Sample":
                                sample = object_cache[well.content.value]
                                sample_name = ':'.join(list(map(lambda x: sample.data.attributes.fields[x].display_value, ['Biosample Container Name','Animal Batch'])))
                                plate_map[well.wellId]['sample_name'] = sample_name

                            elif annotation_layer.name.startswith('Channel'):
                                plate_map[well.wellId][annotation_layer.name] = {}
                                gene = object_cache[well.content.value]
                                plate_map[well.wellId][annotation_layer.name]['gene_name'] = gene.data.attributes.fields['Gene Name'].display_value
                                plate_map[well.wellId][annotation_layer.name]['fluorophore'] = gene.data.attributes.fields['Fluorophore (with quenchers)'].display_value

        print(f'Instrument method: {instrument_method}')
        print(json.dumps(plate_map, indent=4))
_main()

