import asyncio

import APIKey
from LuPySNB import API, REST

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers, auto_expand=True, next_limit=15)


def test_moving_containers_between_cupboards():
    with (REST.RestClientHTTPX(config) as client):
        child_locations = API.Inventory.get_inventory_location_children_by_path(client,
                                                                                "/Valby/G1/R1/R010",
                                                                                'location')
        # for each location, get the path name, get all containers and their coordinates
        for location in child_locations.data:
            old_location_details = API.Inventory.get_inventory_location_by_eid(client, location.id)
            old_location_path = API.Inventory.get_location_path_from_location_response(old_location_details)
            new_location_path = old_location_path.replace("/Valby/G1/R1/R010/", "/Valby/G1/R1/R011/")
            new_location_details = API.Inventory.get_inventory_location_by_path(client, new_location_path)
            child_containers = API.Inventory.get_inventory_location_children_by_path(client, old_location_path,
                                                                                     'container')

            if len(child_containers.data) == 0:
                print(f"No containers found in {old_location_path}")
                continue

            for container in child_containers.data:
                container_details = API.Container.get_container(client, container.id)
                coordinateX = container_details.data.attributes.coordinateX
                coordinateY = container_details.data.attributes.coordinateY
                digest = container_details.data.attributes.digest

                container_updated = API.Container.update_container_status(client,
                                                                          container_eid=container_details.data.id,
                                                                          action='checkout',
                                                                          force=False,
                                                                          digest=digest,
                                                                          location_eid=new_location_details.data.id,
                                                                          coordinate_x=coordinateX,
                                                                          coordinate_y=coordinateY)

                print(
                    f"Container {container_updated.data.attributes.barcode} moved from {old_location_path} to {new_location_path}, coordinates: {coordinateX}, {coordinateY}")
                print("---")
        pass


def test_getting_child_locations():
    def get_all_child_locations(_client, location_path: str):
        for _location in API.Inventory.get_inventory_location_children_by_path(_client, location_path, 'location').data:
            yield from get_all_child_locations(client, location_path + '/' + _location.attributes.name)
            yield _location

    with REST.RestClientHTTPX(config) as client:
        for child_location in get_all_child_locations(client, "/Valby/G2/K032"):
            location = API.Inventory.get_inventory_location_by_eid(client, child_location.id)
            location_type = API.Inventory.get_inventory_types_by_name(client, 'location', location.data.attributes.typeName)[0]
            field_map = location_type.get_field_map()

            print(field_map)
            exit(0)

test_getting_child_locations()
#test_moving_containers_between_cupboards()
