import asyncio

from LuPySNB import API, REST
import APIKey
from LuPySNB.API.Entity import EntityType, EntityOption
from datetime import datetime

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers, auto_expand=True, next_limit=100)

plate_barcode = "P0983347"


def _main_1():
    with REST.RestClientHTTPX(config) as client:
        return API.ADT.get_experiment_containing_adt_entry(client, 'Fulfillment Plates', 'Barcode',
                                                           plate_barcode, 'text')


def _main_2():
    with REST.RestClientHTTPX(config) as client:
        return API.ADT.get_experiment_containing_adt_entry(client, 'Fulfillment Plates', 'Barcode',
                                                           plate_barcode, 'text')


async def _main_async():
    async with REST.RestClientAsyncHTTPX(config) as client:
        adts = await API.ADT.get_adt_containing_adt_entry_by_template_async(client, 'Fulfillment Plates', 'Barcode',
                                                                            plate_barcode, 'text', 'experiment:25eb005b-add1-4773-8978-5fd57957f322')
        for adt in adts.data:
            table = await API.ADT.get_adt_data_async(client, adt.id)
            print(table)
            for row in table.data:
                print('Test', row.attributes.method, row.attributes.is_header)
                if row.attributes.is_header:
                    for cell in row.attributes.cells:
                        print('Cell', cell.key, cell.type, cell.name, cell.content.value if cell.content else None)


print(_main_1())
print(_main_2())
print(asyncio.run(_main_async()))
