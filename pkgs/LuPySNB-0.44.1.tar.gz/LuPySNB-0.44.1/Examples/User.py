from LuPySNB import API, REST
import APIKey
import asyncio
import random
import string

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)

first_names = [
    "Giggles", "Snickers", "Bubbles", "Chuckles", "Wacky", "Zany", "Goofy", "Silly", "Quirky", "Jolly"
]

last_names = [
    "McGiggle", "Snickerbottom", "Bubblepants", "Chucklesworth", "Wackadoodle", "Zanyman", "Goofington", "Sillybean", "Quirkmeister", "Jollykins"
]


random_chars = ''.join(random.choices(string.ascii_lowercase, k=4))
name1 = {"first_name": random.choice(first_names), "last_name": random.choice(last_names), "alias": f'test-{random_chars}'}
random_chars = ''.join(random.choices(string.ascii_lowercase, k=4))
name2 = {"first_name": random.choice(first_names), "last_name": random.choice(last_names), "alias": f'test-{random_chars}'}


def test_create_user(name):
    with REST.RestClientRequests(config) as client:
        user = API.User.create_user(client, name['alias'], name['first_name'], name['last_name'], API.LundbeckOrganization.lundbecksandbox)
        return user

async def test_create_user_async(name):
    async with (REST.RestClientAsyncHTTPX(config) as client):
        user = await API.User.create_user_async(client, name['alias'], name['first_name'], name['last_name'], API.LundbeckOrganization.lundbecksandbox)
        return user

def test_getting_users():
    with REST.RestClientRequests(config) as client:
        user = API.User.get_users(client)
        return user

async def test_getting_users_async():
    async with (REST.RestClientAsyncHTTPX(config) as client):
        user = await API.User.get_users_async(client)
        return user

def test_getting_user_by_initials(name):
    with REST.RestClientRequests(config) as client:
        user = API.User.get_users_by_alias(client, name['alias'])
        return user

async def test_getting_user_by_initials_async(name):
    async with (REST.RestClientAsyncHTTPX(config) as client):
        user = await API.User.get_users_by_alias_async(client, name['alias'])
        return user

print('Synchronous tests:')

print(f'Creating user with name: {name1}')
print(test_create_user(name1))
print('Getting users:')
print(test_getting_users())
print('Getting user by initials:')
print(test_getting_user_by_initials(name1))

print('\nAsynchronous tests:')

print(f'Creating user with name: {name2}')
print(asyncio.run(test_create_user_async(name2)))
print('Getting users:')
print(asyncio.run(test_getting_users_async()))
print('Getting user by initials:')
print(asyncio.run(test_getting_user_by_initials_async(name2)))

print('\nTests complete.\n')