from LuPySNB import API, REST
import APIKey
from datetime import datetime
import pytz


headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)
client = REST.RestClientHTTPX(config)

# Get experiment eid
experiment_eid = API.Experiment.get_experiment_id_by_name(client, 'STSS-0242', False)
print(experiment_eid)

# Insert rows in Product Identification Table
prodIdADTEid = API.ADT.get_experiment_adt_id_by_name(client, experiment_eid, 'Product Identification')
print(prodIdADTEid)
print(API.ADT.insert_adt_rows_by_col_name(client, prodIdADTEid, [
        [
            ('HLu ID', 'AH12345'),
            ('Batch ID/Alias', 'A1234QP'),
            ('Product Name', 'The drug to cure all known diseases'),
            ('Project Association', 'Some project'),
            ('Link', ('XKCD', 'https://xckd.com')),
            ('Created By', 'ALGH'),
            ('Created On', datetime.now(pytz.timezone('Europe/Copenhagen')).isoformat()),
            ('Site', ('Evotec', 'Aptuit', 'Neurofit'))
        ]
    ]
))

resp = API.ADT.get_adt_data(client, prodIdADTEid)
for row_count, row in enumerate(resp.data):
    print(f"row {row_count}")
    for cell in row.attributes.cells:
        print(cell.name, cell.content.value)


prodIdADTEid = API.ADT.get_experiment_adt_id_by_name(client, experiment_eid, 'SamplingTable')
print(prodIdADTEid)
print(API.ADT.insert_adt_rows_by_col_name(client, prodIdADTEid, [
        [
            ('Create Task?', False)
        ]
    ]
))


resp = API.ADT.get_adt_data(client, prodIdADTEid)
for row_count, row in enumerate(resp.data):
    print(f"row {row_count}")
    for cell in row.attributes.cells:
        print(cell.name, cell.content.value)
