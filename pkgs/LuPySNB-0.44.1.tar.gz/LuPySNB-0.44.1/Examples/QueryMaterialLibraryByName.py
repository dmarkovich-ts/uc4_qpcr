import asyncio

from LuPySNB import API, REST
import APIKey

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)


def _main():
    with REST.RestClientHTTPX(config) as client:
        r = API.MaterialLibrary.get_material_libraries(client)

        for lib in r.data:
            print(lib.attributes.name)

        animal_lib = API.MaterialLibrary.get_material_library_by_name(client, 'Lu Cell Lines')
        print(animal_lib)
        print(animal_lib.get_material_library_asset_field_map())
        print(animal_lib.get_material_library_batch_field_map())

        asset = API.MaterialLibrary.get_assets_by_name(client, animal_lib.id, ['SNB:CL-1'])
        print(asset)


async def _main_async():
    async with REST.RestClientAsyncHTTPX(config) as client:
        r = await API.MaterialLibrary.get_material_libraries_async(client)

        for lib in r.data:
            print(lib.attributes.name)

        animal_lib = await API.MaterialLibrary.get_material_library_by_name_async(client, 'Lu Cell Lines')
        print(animal_lib)
        print(animal_lib.get_material_library_asset_field_map())
        print(animal_lib.get_material_library_batch_field_map())

        asset = await API.MaterialLibrary.get_assets_by_name_async(client, animal_lib.id, ['SNB:CL-1'])
        print(asset)


_main()
asyncio.run(_main_async())
