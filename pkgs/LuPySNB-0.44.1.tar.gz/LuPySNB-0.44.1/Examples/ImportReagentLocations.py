import math

from LuPySNB import API, REST
import APIKey
import pandas as pd

from LuPySNB.model.responses.ErrorList import ErrorList

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)

df = pd.read_csv('C:\\Users\\cahl\\PycharmProjects\\LuPySNB\\Examples\\Resources\\location_export.csv')

# get the location types I will be using, so I can get their mapping
location_types = {}
with REST.RestClientRequests(config) as client:
    location_types['Bin'] = API.Inventory.get_inventory_types_by_name(client, "location", "Bin")[0]
    location_types['Site'] = API.Inventory.get_inventory_types_by_name(client, "location", "Site")[0]
    location_types['Building'] = API.Inventory.get_inventory_types_by_name(client, "location", "Building")[0]
    location_types['Room'] = API.Inventory.get_inventory_types_by_name(client, "location", "Room")[0]
    location_types['Cupboard'] = API.Inventory.get_inventory_types_by_name(client, "location", "Cupboard")[0]
    location_types['Shelf without Grid'] = \
    API.Inventory.get_inventory_types_by_name(client, "location", "Shelf without Grid")[0]
    location_types['Shelf with Grid'] = \
    API.Inventory.get_inventory_types_by_name(client, "location", "Shelf with Grid")[0]
    print("done")

    # loop through each record
    location_cache = {}
    for index, record in df.iterrows():

        # replace nans with Nones
        fields = record.to_dict()
        for k, v in fields.items():
            if isinstance(v, float) and math.isnan(v):
                fields[k] = None

        # get each field from the record
        # get fields that are parameters to the create inv location function
        print(index)
        location_path = fields['Location']
        print(f"Location Path: {location_path}")

        # name
        name = location_path.split('/')[-1]
        print(f"Name: {name}")

        # barcode
        # add a suffix to the root location name (e.g. "Valby_Test") and barcode fields to avoid duplicates and grid location collisions
        barcode = fields['Barcode']
        if isinstance(barcode, str):  # adding suffix while testing
            barcode = barcode
        print(f"Barcode: {barcode}")

        # rows
        rows = fields['Rows']
        print(f"Rows: {rows}")

        # columns
        columns = fields['Columns']
        print(f"Columns: {columns}")

        # parent_id
        parent_path = '/' + '/'.join(location_path.split('/')[1:-1])
        if parent_path == '/':
            parent_path = None
        print(f"Parent Path: {parent_path}")
        parent_id = None
        if parent_path is not None:
            if not parent_path in location_cache:
                location_cache[parent_path] = API.Inventory.get_inventory_location_by_path(client, parent_path)
            parent_id = location_cache[parent_path].data.id

        print(f"Parent ID: {parent_id}")

        # location_type_id
        location_type = fields['Location Type']
        print(f"Location Type: {location_type}")
        location_type_id = location_types[location_type].id
        print(f"Location Type ID: {location_type_id}")

        # field map
        field_map = location_types[location_type].get_field_map()

        final_dict = {}
        for k, v in fields.items():
            if k in field_map:
                final_dict[k] = v
        final_dict.pop('Barcode')

        if 'Temperature' in final_dict:
            final_dict['Temperature'] = (final_dict['Temperature'],str(final_dict['Temperature']) + ' °C') #degrees from oracle -> csv not handled well

        created_location = API.Inventory.create_inventory_location(client,name,barcode,rows,columns,parent_id,location_type_id,final_dict,field_map)

        if isinstance(created_location, ErrorList):
            print(f"Error creating location: {created_location}")
            continue

        ancestor_names = None
        path= ''
        ancestor_names = [v['name'] for v in created_location.data.attributes.ancestors]
        if len(ancestor_names) > 0:
            ancestor_names.reverse()
            path = '/'.join(ancestor_names)
            path = '/' + path

        path = path + '/' + created_location.data.attributes.name

        location_cache[path] = created_location

        print('---')