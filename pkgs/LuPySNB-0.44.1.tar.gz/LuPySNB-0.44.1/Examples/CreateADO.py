import asyncio

from LuPySNB import API, REST
import APIKey

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)

ado_type ='BioRails Experiment'
template_id = 'ado-4:7733a09f-14d9-456a-8619-2524756867e7'
attributes = {
    'description': 'This is a description',
    'created by': 'ALGJ',
}



def _main():
    # Create experiment in Signals
    with REST.RestClientHTTPX(config) as client:
        r1 = API.Experiment.create_ado(client, ado_type, template_id, attributes)
        print(r1.data)


async def _main_async():
    # Create experiment in Signals
    async with REST.RestClientAsyncHTTPX(config) as client:
        r1 = await API.Experiment.create_ado_async(client, ado_type, template_id, attributes)
        print(r1.data)



_main()
asyncio.run(_main_async())