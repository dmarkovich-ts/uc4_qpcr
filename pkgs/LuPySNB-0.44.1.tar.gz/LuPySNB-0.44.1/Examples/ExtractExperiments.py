from typing import Dict, Any
from LuPySNB import API, REST
import APIKey
from LuPySNB.API.Entity import EntityType, EntityOption
from datetime import datetime
import pandas as pd
import openpyxl
from LuPySNB.model.responses.EntityDescriptor import EntityDescriptor


def to_dict(entity_desc: EntityDescriptor) -> Dict[str, Any]:
    """
    Converts an EntityDescriptor to a dictionary.
    """

    entity_dict = {
        'id': entity_desc.attributes.id,
        'eid': entity_desc.attributes.eid,
        'type': entity_desc.attributes.type,
        'name': entity_desc.attributes.name,
        'description': entity_desc.attributes.description,
        'created': entity_desc.attributes.createdAt.isoformat() if entity_desc.attributes.createdAt else None,
        'modified': entity_desc.attributes.modifiedAt.isoformat() if entity_desc.attributes.modifiedAt else None,
    }

    for field_name, field_value in entity_desc.attributes.fields.items():
        if field_value.value is not None:
            entity_dict[field_name] = field_value.value
        elif field_value.values is not None:
            entity_dict[field_name] = ', '.join(field_value.values)
        else:
            entity_dict[field_name] = None

    return entity_dict


headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers, auto_expand=True, next_limit=100)

client = REST.RestClientHTTPX(config)

res = API.get_entities(client,
                       include_types=[EntityType.experiment],
                       entity_options=[EntityOption.nontemplate],
                       start_date=datetime(2025, 1, 1))

experiments = dict(map(lambda x: (x.id, to_dict(x)), res.data))
adts = {}

for experiment in res.data:
    adt_ids = API.get_experiment_adt_ids(client, experiment.attributes.eid)
    if adt_ids:
        for adt_id in adt_ids:
            adt = API.get_adt_data(client, adt_id)
            adt_name = adt.name()
            print(adt_name)
            for row in adt.data:
                row_dict = dict(map(lambda x: (x.name, x.content.value if x.content else None), row.attributes.cells)) if row.attributes.cells else {}
                row_dict['experiment_id'] = experiment.attributes.eid
                row_dict['adt_id'] = adt_id
                if adt_name not in adts:
                    adts[adt_name] = {}
                adts[adt_name][row.id] = row_dict

with pd.ExcelWriter('C:\\Dev\\experiments.xlsx',
                    engine='openpyxl') as writer:
    pd.DataFrame.from_dict(experiments, orient='index').to_excel(writer, sheet_name='Experiments', index=False)
    for adt_name, adt_data in adts.items():
        try:
            pd.DataFrame.from_dict(adt_data, orient='index').to_excel(writer, sheet_name=adt_name.replace('@', 'At'),
                                                                      index=True)
        except Exception as e:
            print(f'Error writing ADT {adt_name} to Excel: {e}')

print(f'Fetched {len(res.data)} experiments and ADOs')
