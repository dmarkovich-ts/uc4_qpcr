import asyncio
from datetime import datetime
from LuPySNB.model.DTOs import Query as Q
from LuPySNB import API, REST, EntityDescriptorListFromQuery
import APIKey

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)

# note, this date query is for dates in fields (in_object=tags)

start_date = datetime(2010, 1, 5)
end_date = datetime(2010, 1, 6)
ado = 4 # admin defined object

q = []
q.append(Q.QueryMatch[bool].create(field="isTemplate", value=False))
q.append(Q.QueryMatch[str].create(field="type", value=ado, mode="keyword"))
q.append(Q.QueryDateRange[str].create(field="fields.Created On", from_value=start_date.strftime('%Y-%m-%dT00:00:00.000Z'), to_value=end_date.strftime('%Y-%m-%dT00:00:00.000Z'), in_object="tags", as_type="date"))
query = Q.Query(query=Q.AndQueryTerm.create(q))

def _main():
    with REST.RestClientHTTPX(config) as client:
        r = client.invoke_rest_post('entities/search?source=SN', query, EntityDescriptorListFromQuery, True)
        print(f"Found {r.meta.total} entities")


async def _main_async():
   async with REST.RestClientAsyncHTTPX(config) as client:
       r = await client.invoke_rest_post_async('entities/search?source=SN', query, EntityDescriptorListFromQuery, True)
       print(f"Found {r.meta.total} entities")


_main()
asyncio.run(_main_async())
