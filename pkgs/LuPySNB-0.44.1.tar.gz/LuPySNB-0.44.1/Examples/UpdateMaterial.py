import asyncio

from LuPySNB import API, REST
import APIKey
from LuPySNB.model.requests.UpdateMaterialPropertiesRequest import UpdateMaterialPropertiesRequest
from LuPySNB.model.requests.MaterialAssetRequest import MaterialAssetRequest

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)


def _main():
    with REST.RestClientHTTPX(config) as client:
        cell_membrane_lib = API.MaterialLibrary.get_material_library_by_name(client, 'Lu Cell Lines')
        material = API.MaterialLibrary.get_asset(client, 'Lu Cell Lines', 'SNB:CL-8')
        request = UpdateMaterialPropertiesRequest.create([('Morphology', 'Flat')],
                                                         cell_membrane_lib.get_material_library_asset_field_map())
        print(request)
        print(API.update_material_properties(client, material.data.attributes.eid, request))


async def _main_async():
    async with REST.RestClientAsyncHTTPX(config) as client:
        cell_membrane_lib = await API.MaterialLibrary.get_material_library_by_name_async(client, 'Lu Cell Lines')
        material = await API.MaterialLibrary.get_asset_async(client, 'Lu Cell Lines', 'SNB:CL-8')
        request = UpdateMaterialPropertiesRequest.create([('Morphology', 'Round')],
                                                         cell_membrane_lib.get_material_library_asset_field_map())
        print(request)
        print(await API.update_material_properties_async(client, material.data.attributes.eid, request))


_main()
asyncio.run(_main_async())