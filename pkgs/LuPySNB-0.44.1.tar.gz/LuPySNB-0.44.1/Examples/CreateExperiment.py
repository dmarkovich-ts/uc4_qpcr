import asyncio

from LuPySNB import API, REST
import APIKey

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)


def _main():
    # Create experiment in Signals
    with REST.RestClientHTTPX(config) as client:
        r1 = API.Experiment.create_experiment(client, {
            'description': 'Antibody batch data sheet',
            'HLu ID': 'AH12345',
            'Batch Date': None,
            'Project': 'Some project'}, 'Antibody Batch Data Sheet', 'STSS')

        print(r1.data)


async def _main_async():
    # Create experiment in Signals
    async with REST.RestClientAsyncHTTPX(config) as client:
        r1 = await API.Experiment.create_experiment_async(client, {
            'description': 'Antibody batch data sheet',
            'HLu ID': 'AH12345',
            'Batch Date': None,
            'Project': 'Some project'}, 'Antibody Batch Data Sheet', 'STSS')

    print(r1.data)


_main()
asyncio.run(_main_async())