from LuPySNB import API, REST, get_entity_id_by_name
import APIKey
from pprint import pprint

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)

with REST.RestClientHTTPX(config) as client:
    table_name = 'tick@lab: Batch Data'
    experiment_template = "experiment:599b5c34-e5f1-4d1a-8726-0f954fc4fa11"

    # Search for grid template and leave out grids that are not system grids and have parents
    table_template = get_entity_id_by_name(client, table_name, "grid", True, is_system=True, has_no_parent=True)

    # Create grid in Signals
    r1 = API.Entity.create_entity(client, table_template, experiment_template, {"name": table_name})

    pprint(r1)
