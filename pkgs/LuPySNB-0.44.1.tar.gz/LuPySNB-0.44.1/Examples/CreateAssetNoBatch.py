import base64
from LuPySNB import API, REST
import APIKey
from LuPySNB.model.requests.MaterialAssetRequest import MaterialAssetRequest

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)

with REST.RestClientRequests(config) as client:
    with open(".\\Resources\\Issues.png", "rb") as image_file:
        imageData = base64.b64encode(image_file.read())

    cell_membrane_lib = API.MaterialLibrary.get_material_library_by_name(client, 'Lu Cell Membranes')
    print(cell_membrane_lib)
    request = MaterialAssetRequest.create(None, None, [], [('Cell Membrane Name', 'Test from API'),
                                                           ('Species', 'Human'),
                                                           ('File Attachment', ('example.png', imageData))],
                                   cell_membrane_lib.get_material_library_asset_field_map(), None, None)

    print(request)
    print(API.create_asset(client, 'Lu Cell Membranes', request))
