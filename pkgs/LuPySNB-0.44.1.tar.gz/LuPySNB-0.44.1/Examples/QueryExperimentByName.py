from LuPySNB import API, REST
from LuPySNB.model.responses.EntityDescriptorList import EntityDescriptorList
import APIKey
import asyncio

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers, auto_expand=True, next_limit=4)


exp_name = 'SNB:EXP-478'

async def _main_async():
    async with REST.RestClientAsyncHTTPX(config) as client:
        # prints eid
        experiment_eid = await API.Experiment.get_experiment_id_by_name_async(client, exp_name, False)
        print(experiment_eid)

        # get full experiment description
        print(await API.Entity.get_entity_by_id_async(client, experiment_eid))

        # get experiment child entities based on filter with query - use POST style paging
        for child in (await API.Entity.get_child_entities_by_parent_id_async(client, experiment_eid, ['excel', 'pdf', 'uploadedResource', 'viewonly', 'presentation', 'text'])).data:
            print(child.attributes.type + ':' + child.attributes.name)

        # get experiment child entities with children endpoint - use GET style paging
        for child in (await client.invoke_rest_get_async(f"entities/{experiment_eid}/children", EntityDescriptorList, True)).data:
            print(child.attributes.type + ':' + child.attributes.name)


def _main():
    with REST.RestClientHTTPX(config) as client:

        # prints eid
        experiment_eid = API.Experiment.get_experiment_id_by_name(client, exp_name, False)
        print(experiment_eid)

        # get full experiment description
        print(API.Entity.get_entity_by_id(client, experiment_eid))

        # get experiment child entities with query - use POST style paging
        for child in API.Entity.get_child_entities_by_parent_id(client, experiment_eid).data:
            print(child.attributes.type + ':' + child.attributes.name)

        # get experiment child entities with children endpoint - use GET style paging
        for child in client.invoke_rest_get(f"entities/{experiment_eid}/children", EntityDescriptorList, True).data:
            print(child.attributes.type + ':' + child.attributes.name)


_main()
asyncio.run(_main_async())
