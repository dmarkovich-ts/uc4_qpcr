import asyncio

from LuPySNB import RestClientAsyncHTTPX
from LuPySNB.REST.RestClientHTTPX import RestClientHTTPX
from LuPySNB.REST.RestConfig import RestConfig
from LuPySNB.API.Worksheet import get_experiment_worksheet_ids_by_name, update_worksheet, \
    get_experiment_worksheet_ids_by_name_async, update_worksheet_async
import APIKey

headers = {'Accept': 'application/vnd.api+json',
           'Content-Type': 'application/vnd.api+json',
           'x-api-key': APIKey.api_key}

apiConfig = RestConfig(base_url=APIKey.base_url,
                       headers=headers)


def _main():
    with RestClientHTTPX(apiConfig) as client:
        # Get the Id of the worksheet of interest
        ws_eid = get_experiment_worksheet_ids_by_name(client, '9f504b6d-f066-47c8-8cc8-0e5eaf717cb8', 'Ab Data Sheet')

        # Update a few fields with values
        ws = update_worksheet(client, ws_eid[0], [('LuNo', 'PQ47112'),
                                                  ('ProdName', 'Kurt''s New Fantastic Antibody'),
                                                  ('Location', 'My very own private shelf')])
        print(ws)

        # Get the Id of the worksheet of interest
        ws_eid = get_experiment_worksheet_ids_by_name(client, '9f504b6d-f066-47c8-8cc8-0e5eaf717cb8', 'Test ALGH')

        # Update a few fields with values
        ws = update_worksheet(client, ws_eid[0], [('Coffee mugs in office', int(345)),
                                                  ('Plants need water', True),
                                                  ('Link', ('Danmarks Radio', 'https://www.dr.dk'))])
        print(ws)


async def _main_async():
    async with RestClientAsyncHTTPX(apiConfig) as client:
        # Get the Id of the worksheet of interest
        ws_eid = await get_experiment_worksheet_ids_by_name_async(client,
                                                            '9f504b6d-f066-47c8-8cc8-0e5eaf717cb8', 'Ab Data Sheet')

        # Update a few fields with values
        ws = await update_worksheet_async(client, ws_eid[0], [('LuNo', 'PQ47112'),
                                                              ('ProdName', 'Kurt''s New Fantastic Antibody'),
                                                              ('Location', 'My very own private shelf')])
        print(ws)

        # Get the Id of the worksheet of interest
        ws_eid = await get_experiment_worksheet_ids_by_name_async(client, '9f504b6d-f066-47c8-8cc8-0e5eaf717cb8', 'Test ALGH')

        # Update a few fields with values
        ws = await update_worksheet_async(client, ws_eid[0], [('Coffee mugs in office', int(385)),
                                                              ('Plants need water', True),
                                                              ('Link', ('Danmarks Radio', 'https://www.dr.dk'))])
        print(ws)


_main()
asyncio.run(_main_async())