base_url = "https://lundbeck-sandbox.signalsresearch.revvitycloud.eu/api/rest/v1.0"
api_key = "YOUR_API_KEY"
