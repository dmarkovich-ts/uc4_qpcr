import io
from io import BytesIO
import APIKey
from LuPySNB import API, REST

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)
client = REST.RestClientHTTPX(config)

# case 1
#filename = 'lorem_ipsum.txt'
#entity_type = 'text'

# case 2
filename = 'Eventyr.docx'
entity_type = 'viewonly'


with open(f"./Resources/{filename}", 'br') as f:
    buffer = f.read()

experiment_name = 'SNB:EXP-231'

eid = API.Experiment.get_experiment_id_by_name(client, experiment_name, False)
r = API.add_file_attachment(client, eid, filename, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', BytesIO(buffer))
attachment_eid = r.data.id
print("Attached: " + attachment_eid)

# Find the attachment by name
search_attachment_eid = API.Entity.get_child_entity_id_by_name(client, filename, entity_type, experiment_name, 'experiment')
print("Found: " + search_attachment_eid)

# Get the attachment
file = API.get_file_attachment(client, search_attachment_eid)
print("Downloaded: " + file.filename)

# API.get_entity_by_id(client, search_attachment_eid)
# Clean up
r = API.delete_entity(client, attachment_eid)
print("Deleted: " + attachment_eid)
