import asyncio

from LuPySNB import API, REST
import APIKey
from LuPySNB.model.requests.MaterialAssetRequest import MaterialAssetRequest, MaterialAssetRequestList
import time

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)


chunk_size = 10
material_lib_name = 'LU Cell Lines for Test'
protocol_name = 'Dummy protocol'

def _main():
    with REST.RestClientHTTPX(config) as client:
        cell_line_lib = API.MaterialLibrary.get_material_library_by_name(client, material_lib_name)
        print(cell_line_lib)

        protocol = API.get_entities_by_name(client, protocol_name, '1', False).data[0].attributes

        request = MaterialAssetRequest.create(None, 'Batch-1', [], [('Cell Line Name', 'Test from API'), ('Species', 'Homo sapiens'), ('Vendor', 'Charles River Laboratories'), ('Protocol', (protocol.eid, protocol.name, protocol.type))],
                                       cell_line_lib.get_material_library_asset_field_map(),
                                       [('Assay Ready', 'Yes'), ('Passage No.', "1")], cell_line_lib.get_material_library_batch_field_map())


        requests = []
        for i in range(0, chunk_size):
            requests.append(request)

        start_time = time.perf_counter()
        first_report = API.create_asset_bulk(client, material_lib_name, 'TREAT_AS_UNIQUE', MaterialAssetRequestList(requests))
        next_report = API.get_bulk_create_report(client, first_report.data.id)
        while next_report.data.attributes.status == 'IMPORTING':
            time.sleep(0.5)
            next_report = API.get_bulk_create_report(client, first_report.data.id)
            curr_time = time.perf_counter()
            print(f'{curr_time - start_time}: {next_report.data.attributes.status}')

        print(f'Succeeded: {next_report.data.attributes.report.succeeded}')

async def _main_async():
    async with REST.RestClientAsyncHTTPX(config) as client:
        cell_line_lib = await API.MaterialLibrary.get_material_library_by_name_async(client, material_lib_name)
        print(cell_line_lib)

        protocol = (await API.get_entities_by_name_async(client, protocol_name, '1', False)).data[0].attributes

        request = MaterialAssetRequest.create(None, 'Batch-1', [],
                                              [('Cell Line Name', 'Test from API'), ('Species', 'Homo sapiens'),
                                               ('Vendor', 'Charles River Laboratories'),
                                               ('Protocol', (protocol.eid, protocol.name, protocol.type))],
                                              cell_line_lib.get_material_library_asset_field_map(),
                                              [('Assay Ready', 'Yes'), ('Passage No.', "1")],
                                              cell_line_lib.get_material_library_batch_field_map())

        requests = []
        for i in range(0, chunk_size):
            requests.append(request)

        start_time = time.perf_counter()
        first_report = await API.create_asset_bulk_async(client, material_lib_name, 'TREAT_AS_UNIQUE', MaterialAssetRequestList(requests))
        next_report = await API.get_bulk_create_report_async(client, first_report.data.id)
        while next_report.data.attributes.status == 'IMPORTING':
            await asyncio.sleep(0.5)
            next_report = await API.get_bulk_create_report_async(client, first_report.data.id)
            curr_time = time.perf_counter()
            print(f'{curr_time - start_time}: {next_report.data.attributes.status}')

        print(f'Succeeded: {next_report.data.attributes.report.succeeded}')

_main()
asyncio.run(_main_async())
