from LuPySNB import API, REST
import APIKey
from datetime import datetime
import pytz


headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)
client = REST.RestClientHTTPX(config)

experiment_eid = API.Experiment.get_experiment_id_by_name(client, 'SNB:EXP-77', False)
print(experiment_eid)

files_overview = API.ADT.get_experiment_adt_id_by_name(client, experiment_eid, 'HLU - Files Overview')
print(files_overview)

rows = [
    [('File Path', 'C:/path/to/file1'), ('File Name', 'file1.txt'), ('File Type', 'Results'), ('Equipment', 'Ionworks'), ('Comment', 'Test file 1')],
    [('File Path', 'C:/path/to/file2'), ('File Name', 'file2.txt'), ('File Type', 'Results'), ('Equipment', 'Ionworks'), ('Comment', 'Test file 2')],
    [('File Path', 'C:/path/to/file3'), ('File Name', 'file3.txt'), ('File Type', 'Results'), ('Equipment', 'Ionworks'), ('Comment', 'Test file 3')]
]

result = API.ADT.insert_bulk_adt_rows_by_col_name(client, files_overview, rows)

for row in result.data:
    cells = row.attributes.cells
    headers = [cell.name for cell in cells]
    values = [cell.content.value for cell in cells]
    print(dict(zip(headers, values)))

