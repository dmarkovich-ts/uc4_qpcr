import asyncio

from LuPySNB import API, REST
from LuPySNB.model.DTOs.HierarchicalOptions import HierarchicalOptions
from LuPySNB.model.requests.AttributeOptionsUpdateRequest import AttributeOptionsUpdateRequest
import APIKey

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)


def _main():
    with REST.RestClientHTTPX(config) as client:
        attribute_eid = API.get_attribute_id_by_name(client, 'STSS_Test')

        # Print current state
        print(API.get_attribute_details(client, attribute_eid))

        # Clear all options
        print(API.update_attribute_options(client, AttributeOptionsUpdateRequest.create_hierarchical(attribute_eid, [])))

        # Fill options
        print(API.update_attribute_options(client, AttributeOptionsUpdateRequest.create_hierarchical(attribute_eid,
                                           [HierarchicalOptions.create("Yes", ["Good", "Acceptable\u00AE"]),
                                            HierarchicalOptions.create("No", ["Ugly", "Really\u2212Awful"])])))


async def _main_async():
    async with REST.RestClientAsyncHTTPX(config) as client:
        attribute_eid = await API.get_attribute_id_by_name_async(client, 'STSS_Test')

        # Print current state
        print(await API.get_attribute_details_async(client, attribute_eid))

        # Clear all options
        print(
            await API.update_attribute_options_async(client, AttributeOptionsUpdateRequest.create_hierarchical(attribute_eid, [])))

        # Fill options
        print(
            await API.update_attribute_options_async(client, AttributeOptionsUpdateRequest.create_hierarchical(attribute_eid,
                                 [
                                     HierarchicalOptions.create("Yes", ["Good", "Acceptable\u00AE"]),
                                     HierarchicalOptions.create("No", ["Ugly", "Really\u2212Awful"])])))

_main()
asyncio.run((_main_async()))
