import zipfile
import os
from LuPySNB import API, REST
import APIKey
import time


lib_name = 'CRO Reagents Test'

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers)

os.chdir("Resources")
zipfile.ZipFile('cro upload.zip', mode='w').write("summary.sdf")

with REST.RestClientHTTPX(config) as client:
    material_lib = API.MaterialLibrary.get_material_library_by_name(client, lib_name)
    print(material_lib)

    with open("cro upload.zip", 'br') as f:
        zip_buffer = f.read()

    start_time = time.perf_counter()
    first_report = API.create_asset_bulk_sdf(client, lib_name, 'TREAT_AS_UNIQUE', zip_buffer)
    print(first_report)
    next_report = API.get_bulk_create_report(client, first_report.data.id)
    while next_report.data.attributes.status == 'IMPORTING':
        time.sleep(0.5)
        next_report = API.get_bulk_create_report(client, first_report.data.id)
        curr_time = time.perf_counter()
        print(f'{curr_time - start_time}: {next_report.data.attributes.status}')

    print(f'Succeeded: {next_report.data.attributes.report.succeeded}')
