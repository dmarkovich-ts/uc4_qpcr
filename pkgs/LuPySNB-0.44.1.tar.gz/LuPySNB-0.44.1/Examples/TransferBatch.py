from LuPySNB import API, REST
import APIKey
from LuPySNB.model.requests.UpdateMaterialPropertiesRequest import UpdateMaterialPropertiesRequest

headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers, auto_expand=True, next_limit=15)


with REST.RestClientHTTPX(config) as client:
    old_asset = API.MaterialLibrary.get_asset(client, 'Lu Compounds', 'AH12345')
    old_batch = old_asset.data.relationships.batches.data[0]
    print(old_batch)

    new_asset = API.MaterialLibrary.get_asset(client, 'Lu Compounds', 'AH12344')

    print(API.MaterialLibrary.get_batch(client, 'Lu Compounds', 'AH12345-1'))

    print(new_asset)

    print(API.Entity.delete_entity(client, old_asset.data.attributes.eid))
    #print(API.MaterialLibrary.transfer_batch(client, old_batch.id, new_asset.data.attributes.assetId))

    #lib = API.MaterialLibrary.get_material_library_by_name(client, 'Lu Compounds')
    #request = UpdateMaterialPropertiesRequest.create([('Name', '5-89')], lib.get_material_library_asset_field_map())
    #print(request)




