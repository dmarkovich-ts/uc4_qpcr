from LuPySNB import API, REST
import APIKey


headers = {
    "x-api-key": APIKey.api_key,
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json"
}

child_eid = "grid:dc4cc9d7-745e-45ba-adb8-86a44ce796b4"

config = REST.RestConfig(
    base_url=APIKey.base_url,
    headers=headers, auto_expand=True, next_limit=100)

client = REST.RestClientHTTPX(config)

ancestors = API.get_ancestors_by_child_id(client, child_eid)

print(ancestors)

parent_experiment = API.get_parent_experiment_by_child_id(client, child_eid)

print(parent_experiment)



