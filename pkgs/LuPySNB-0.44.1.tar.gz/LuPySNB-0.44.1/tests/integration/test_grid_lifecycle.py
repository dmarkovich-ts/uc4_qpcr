import os
import uuid
from datetime import date

import pytest

from LuPySNB import API
from LuPySNB.API.Entity import (
    create_entity,
    delete_entity,
    get_entity_by_id,
    get_entity_id_by_name,
)
from LuPySNB.model.responses.ErrorList import ErrorList

from tests.integration.constants import DEFAULT_GRID_TEMPLATE_NAME, DEFAULT_PARENT_EXPERIMENT_ID


pytestmark = pytest.mark.integration


def _created_entity_id(create_response):
    """Extract the created entity id from the SDK response."""
    print("[_created_entity_id] Extracting created entity id from create response")

    if hasattr(create_response, "data"):
        if hasattr(create_response.data, "id"):
            print(f"[_created_entity_id] Found id on response data: {create_response.data.id!r}")
            return create_response.data.id
        if hasattr(create_response.data, "attributes") and hasattr(create_response.data.attributes, "id"):
            print(
                "[_created_entity_id] Found id on response data attributes: "
                f"{create_response.data.attributes.id!r}"
            )
            return create_response.data.attributes.id

    raise AssertionError(f"Could not find created entity id in response: {create_response!r}")


def test_live_create_grid_then_cleanup(live_rest_client):
    print("[test_live_create_grid_then_cleanup] Starting grid lifecycle integration test")

    grid_template_name = os.getenv(
        "LUPYSNB_TEST_GRID_TEMPLATE_NAME",
        DEFAULT_GRID_TEMPLATE_NAME,
    )
    parent_experiment_id = os.getenv(
        "LUPYSNB_TEST_PARENT_EXPERIMENT_ID",
        DEFAULT_PARENT_EXPERIMENT_ID,
    )
    print(
        "[test_live_create_grid_then_cleanup] Using grid template "
        f"{grid_template_name!r} and parent experiment {parent_experiment_id!r}"
    )

    test_name = f"pytest-do-not-use-{date.today().isoformat()}-{uuid.uuid4()}"
    print(f"[test_live_create_grid_then_cleanup] Temporary grid name: {test_name!r}")
    created_entity_id = None

    try:
        print("[test_live_create_grid_then_cleanup] Looking up grid template id")
        grid_template_id = get_entity_id_by_name(
            live_rest_client,
            grid_template_name,
            "grid",
            True,
            is_system=True,
            has_no_parent=True,
        )
        print(f"[test_live_create_grid_then_cleanup] Grid template lookup returned: {grid_template_id!r}")

        assert grid_template_id is not None, f"No grid template found with name: {grid_template_name}"
        assert not isinstance(grid_template_id, ErrorList), grid_template_id

        print("[test_live_create_grid_then_cleanup] Creating temporary grid")
        create_response = create_entity(
            live_rest_client,
            template_id=grid_template_id,
            ancestor_id=parent_experiment_id,
            attributes={
                "name": test_name,
            },
        )
        print(
            "[test_live_create_grid_then_cleanup] Create response type: "
            f"{type(create_response).__name__}"
        )

        assert not isinstance(create_response, ErrorList), create_response

        created_entity_id = _created_entity_id(create_response)
        print(f"[test_live_create_grid_then_cleanup] Created temporary grid: {created_entity_id!r}")

        print(f"[test_live_create_grid_then_cleanup] Reading created grid entity {created_entity_id!r}")
        read_response = get_entity_by_id(live_rest_client, created_entity_id)
        print(
            "[test_live_create_grid_then_cleanup] Read response type: "
            f"{type(read_response).__name__}"
        )

        assert not isinstance(read_response, ErrorList), read_response
        assert hasattr(read_response, "data")

        print(f"[test_live_create_grid_then_cleanup] Reading ADT data for created grid {created_entity_id!r}")
        adt_data = API.ADT.get_adt_data(
            live_rest_client,
            created_entity_id,
        )
        print(
            "[test_live_create_grid_then_cleanup] ADT data response type: "
            f"{type(adt_data).__name__}"
        )

        assert not isinstance(adt_data, ErrorList), adt_data
        assert hasattr(adt_data, "data")
        print("[test_live_create_grid_then_cleanup] Created grid can be read and has ADT data")


    finally:
        if created_entity_id is not None:
            print(f"[test_live_create_grid_then_cleanup] Cleaning up temporary grid {created_entity_id!r}")
            delete_response = delete_entity(live_rest_client, created_entity_id)
            print(
                "[test_live_create_grid_then_cleanup] Delete response type: "
                f"{type(delete_response).__name__ if delete_response is not None else 'None'}"
            )
            assert delete_response is None or not isinstance(delete_response, ErrorList), delete_response
            print("[test_live_create_grid_then_cleanup] Cleanup completed")
        else:
            print("[test_live_create_grid_then_cleanup] No temporary grid was created; skipping cleanup")

