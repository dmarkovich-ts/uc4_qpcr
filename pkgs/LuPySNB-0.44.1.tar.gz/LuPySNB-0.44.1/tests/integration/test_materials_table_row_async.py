import os

import pytest

from LuPySNB.API.MaterialLibrary import add_materials_table_row_async
from LuPySNB.API.MaterialsTable import (
    delete_materials_table_row_async,
    get_experiment_materials_table_id_by_name,
    get_materials_table_data,
)
from LuPySNB import API
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.MaterialsTable import MaterialsTable, MaterialsTableRow

from tests.integration.constants import (
    DEFAULT_EXPERIMENT_NAME,
    DEFAULT_MATERIALS_TABLE_NAME,
)


pytestmark = pytest.mark.integration


@pytest.fixture
def live_materials_table_eid(live_rest_client):
    experiment_name = os.getenv(
        "LUPYSNB_TEST_EXPERIMENT_NAME",
        DEFAULT_EXPERIMENT_NAME,
    )
    materials_table_name = os.getenv(
        "LUPYSNB_TEST_MATERIALS_TABLE_NAME",
        DEFAULT_MATERIALS_TABLE_NAME,
    )

    experiment_eid = API.Experiment.get_experiment_id_by_name(
        live_rest_client, experiment_name, False
    )
    assert experiment_eid is not None
    assert not isinstance(experiment_eid, ErrorList), experiment_eid

    materials_table_eid = get_experiment_materials_table_id_by_name(
        live_rest_client, experiment_eid, materials_table_name
    )
    assert materials_table_eid is not None
    assert not isinstance(materials_table_eid, ErrorList), materials_table_eid

    return materials_table_eid


@pytest.fixture
def live_material_id(live_rest_client, live_materials_table_eid):
    """Get a material ID from an existing row in the materials table."""
    table = get_materials_table_data(live_rest_client, live_materials_table_eid)
    assert not isinstance(table, ErrorList), table
    assert isinstance(table, MaterialsTable)
    assert len(table.data) > 0, "Materials table has no rows; cannot determine a material ID for testing"

    material_id = table.data[0].attributes.materialId
    assert material_id is not None, "First row has no materialId"
    print(f"Using existing material ID: {material_id!r}")
    return material_id


@pytest.mark.asyncio
async def test_live_add_materials_table_row_async(
    live_async_rest_client, live_materials_table_eid, live_material_id
):
    """Test that add_materials_table_row_async can add a row to a live materials table.

    This test creates a row in the sandbox materials table and deletes it afterwards
    in a finally block.
    """
    print(
        f"Adding row async: materials_table={live_materials_table_eid!r}, "
        f"material_id={live_material_id!r}"
    )

    created_row_id = None
    try:
        result = await add_materials_table_row_async(
            live_async_rest_client,
            live_materials_table_eid,
            live_material_id,
        )

        print(f"Add row result type: {type(result).__name__}")

        assert not isinstance(result, ErrorList), result
        assert isinstance(result, MaterialsTableRow)
        assert result.data.id
        created_row_id = result.data.id
        assert result.data.attributes.materialId == live_material_id
        print(f"Successfully added row with id={created_row_id!r}")

    finally:
        if created_row_id is not None:
            print(f"Cleaning up: deleting row {created_row_id!r}")
            delete_result = await delete_materials_table_row_async(
                live_async_rest_client, live_materials_table_eid, created_row_id
            )
            assert delete_result is None or not isinstance(delete_result, ErrorList), delete_result
            print("Cleanup completed")
        else:
            print("No row was created; skipping cleanup")
