import os

import pytest

from LuPySNB.API.Entity import get_entity_id_by_name
from LuPySNB.model.responses.ErrorList import ErrorList

from tests.integration.constants import DEFAULT_GRID_TEMPLATE_NAME


pytestmark = pytest.mark.integration


def test_live_can_find_grid_template(live_rest_client):
    print("[test_live_can_find_grid_template] Starting grid template lookup integration test")

    grid_template_name = os.getenv(
        "LUPYSNB_TEST_GRID_TEMPLATE_NAME",
        DEFAULT_GRID_TEMPLATE_NAME,
    )
    print(f"[test_live_can_find_grid_template] Looking up system grid template {grid_template_name!r}")

    grid_template_id = get_entity_id_by_name(
        live_rest_client,
        grid_template_name,
        "grid",
        True,
        is_system=True,
        has_no_parent=True,
    )
    print(f"[test_live_can_find_grid_template] Grid template lookup returned: {grid_template_id!r}")

    assert grid_template_id is not None, f"No grid template found with name: {grid_template_name}"
    assert not isinstance(grid_template_id, ErrorList), grid_template_id
    print("[test_live_can_find_grid_template] Grid template lookup checks completed successfully")

