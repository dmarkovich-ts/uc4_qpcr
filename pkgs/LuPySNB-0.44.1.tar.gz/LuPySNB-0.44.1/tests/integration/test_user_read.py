import pytest

from LuPySNB.API import User
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.UserResponse import UserResponse, UserResponseList


pytestmark = pytest.mark.integration


@pytest.fixture
def live_users(live_rest_client):
    print("Listing enabled users from the live API")

    users = User.get_users(live_rest_client)

    assert not isinstance(users, ErrorList), users
    assert isinstance(users, UserResponseList)
    assert users.data

    print(f"Found {len(users.data)} enabled users")

    return users


def test_live_can_list_enabled_users(live_users):
    first_user = live_users.data[0]

    print(f"Checking first returned user: id={first_user.id!r}")

    assert first_user.id
    assert first_user.attributes


def test_live_can_read_user_by_id(live_rest_client, live_users):
    user_id = live_users.data[0].id

    print(f"Reading user by id: {user_id!r}")

    user = User.get_user_by_id(live_rest_client, user_id)

    assert not isinstance(user, ErrorList), user
    assert isinstance(user, UserResponse)
    assert user.data.id == user_id
    assert user.data.attributes

    print(f"Read user successfully: id={user.data.id!r}")


def test_live_can_filter_users_by_alias(live_rest_client, live_users):
    user_with_alias = next(
        (
            user
            for user in live_users.data
            if getattr(user.attributes, "alias", None)
        ),
        None,
    )

    if user_with_alias is None:
        pytest.skip("No enabled users with an alias found in the live sandbox")

    alias = user_with_alias.attributes.alias

    print(f"Filtering users by alias: {alias!r}")

    matches = User.get_users_by_alias(live_rest_client, alias)

    assert not isinstance(matches, ErrorList), matches
    assert matches
    assert all(match.attributes.alias.lower() == alias.lower() for match in matches)
    assert any(match.id == user_with_alias.id for match in matches)

    print(f"Found {len(matches)} user(s) with alias {alias!r}")

