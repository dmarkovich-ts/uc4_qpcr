import os

import pytest

from LuPySNB import API
from LuPySNB.API.Entity import get_entity_by_id
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.GetEntityResponse import GetEntityResponse

from tests.integration.constants import DEFAULT_EXPERIMENT_NAME


pytestmark = pytest.mark.integration


def test_live_can_find_and_read_experiment(live_rest_client):
    print("[test_live_can_find_and_read_experiment] Starting experiment lookup/read integration test")

    experiment_name = os.getenv(
        "LUPYSNB_TEST_EXPERIMENT_NAME",
        DEFAULT_EXPERIMENT_NAME,
    )
    print(f"[test_live_can_find_and_read_experiment] Looking up experiment {experiment_name!r}")

    experiment_eid = API.Experiment.get_experiment_id_by_name(
        live_rest_client,
        experiment_name,
        False,
    )
    print(f"[test_live_can_find_and_read_experiment] Experiment lookup returned: {experiment_eid!r}")

    assert experiment_eid is not None, f"No experiment found with name: {experiment_name}"
    assert not isinstance(experiment_eid, ErrorList), experiment_eid
    assert experiment_eid.startswith("experiment:")

    print(f"[test_live_can_find_and_read_experiment] Reading experiment entity {experiment_eid!r}")
    experiment = get_entity_by_id(live_rest_client, experiment_eid)
    print(
        "[test_live_can_find_and_read_experiment] Experiment read response type: "
        f"{type(experiment).__name__}"
    )

    assert not isinstance(experiment, ErrorList), experiment
    assert isinstance(experiment, GetEntityResponse)

    print("[test_live_can_find_and_read_experiment] Verifying experiment id, name, type, and fields")
    assert experiment.data.id == experiment_eid
    assert experiment.data.attributes.name == experiment_name
    assert experiment.data.attributes.type == "experiment"
    assert experiment.data.attributes.fields
    print("[test_live_can_find_and_read_experiment] Experiment read checks completed successfully")

