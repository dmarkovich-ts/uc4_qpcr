import os

import pytest

from LuPySNB import API
from LuPySNB.API.Worksheet import (
    get_experiment_worksheet_ids_by_name,
    get_worksheet,
    get_worksheet_fields_definition,
)
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.Worksheet import Worksheet as WorksheetResponse

from tests.integration.constants import (
    DEFAULT_EXPERIMENT_NAME,
    DEFAULT_WORKSHEET_ID,
    DEFAULT_WORKSHEET_NAME,
)


pytestmark = pytest.mark.integration


@pytest.fixture
def live_worksheet_name():
    return os.getenv(
        "LUPYSNB_TEST_WORKSHEET_NAME",
        DEFAULT_WORKSHEET_NAME,
    )


@pytest.fixture
def expected_worksheet_id():
    return os.getenv(
        "LUPYSNB_TEST_WORKSHEET_ID",
        DEFAULT_WORKSHEET_ID,
    )


@pytest.fixture
def live_experiment_eid(live_rest_client):
    experiment_name = os.getenv(
        "LUPYSNB_TEST_EXPERIMENT_NAME",
        DEFAULT_EXPERIMENT_NAME,
    )

    print(f"Finding experiment by name: {experiment_name!r}")

    experiment_eid = API.Experiment.get_experiment_id_by_name(
        live_rest_client,
        experiment_name,
        False,
    )

    assert experiment_eid is not None, f"No experiment found with name: {experiment_name}"
    assert not isinstance(experiment_eid, ErrorList), experiment_eid
    assert experiment_eid.startswith("experiment:")

    print(f"Resolved experiment {experiment_name!r} to id={experiment_eid!r}")

    return experiment_eid


@pytest.fixture
def live_worksheet_eid(
    live_rest_client,
    live_worksheet_name,
    expected_worksheet_id,
    live_experiment_eid,
):
    print(
        "Finding worksheet by name under experiment: "
        f"worksheet={live_worksheet_name!r}, experiment_id={live_experiment_eid!r}"
    )

    worksheet_ids = get_experiment_worksheet_ids_by_name(
        live_rest_client,
        live_experiment_eid,
        live_worksheet_name,
    )

    assert not isinstance(worksheet_ids, ErrorList), worksheet_ids
    assert worksheet_ids, f"No worksheet named {live_worksheet_name!r} found under experiment {live_experiment_eid!r}"
    assert all(worksheet_id.startswith("worksheet:") for worksheet_id in worksheet_ids)
    assert expected_worksheet_id in worksheet_ids, (
        f"Expected worksheet {expected_worksheet_id!r} was not found under "
        f"experiment {live_experiment_eid!r}. Found: {worksheet_ids!r}"
    )

    print(f"Found expected worksheet id: {expected_worksheet_id!r}")

    return expected_worksheet_id


def test_live_can_find_worksheet_by_name_under_experiment(live_worksheet_eid, expected_worksheet_id):
    print(f"Checking worksheet id shape: {live_worksheet_eid!r}")

    assert live_worksheet_eid == expected_worksheet_id
    assert live_worksheet_eid.startswith("worksheet:")


def test_live_can_read_worksheet(live_rest_client, live_worksheet_eid):
    print(f"Reading worksheet id={live_worksheet_eid!r}")

    worksheet = get_worksheet(
        live_rest_client,
        live_worksheet_eid,
    )

    assert not isinstance(worksheet, ErrorList), worksheet
    assert isinstance(worksheet, WorksheetResponse)
    assert worksheet.data
    assert worksheet.data.id == live_worksheet_eid
    assert worksheet.included is not None

    print(f"Read worksheet successfully: id={live_worksheet_eid!r}")


def test_live_can_read_worksheet_field_definitions(live_rest_client, live_worksheet_eid):
    print(f"Reading worksheet field definitions for id={live_worksheet_eid!r}")

    field_definitions = get_worksheet_fields_definition(
        live_rest_client,
        live_worksheet_eid,
    )

    assert isinstance(field_definitions, list)
    assert field_definitions

    for field_definition in field_definitions:
        assert field_definition.key
        assert field_definition.title
        assert field_definition.type

    print(f"Found {len(field_definitions)} worksheet field definition(s)")

