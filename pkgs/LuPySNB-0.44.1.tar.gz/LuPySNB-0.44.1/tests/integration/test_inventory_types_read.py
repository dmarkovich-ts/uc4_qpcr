import pytest

from LuPySNB.API import Container, Inventory
from LuPySNB.model.responses.ContainerTypeResponse import ContainerTypeResponseList
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.InventoryTypeResponse import InventoryTypeResponseList


pytestmark = pytest.mark.integration


def test_live_can_read_container_type_metadata(live_rest_client):
    print("Listing container types from the live API")

    container_types = Container.get_container_types(live_rest_client)

    assert not isinstance(container_types, ErrorList), container_types
    assert isinstance(container_types, ContainerTypeResponseList)
    assert container_types.data

    print(f"Found {len(container_types.data)} container types")

    first_type = container_types.data[0]

    print(
        "Using first container type: "
        f"id={first_type.id!r}, name={first_type.attributes.name!r}"
    )

    assert first_type.id
    assert first_type.attributes
    assert first_type.attributes.name

    print("Resolving the same container type by name and by id")

    by_name = Container.get_container_type_by_name(
        live_rest_client,
        first_type.attributes.name,
    )
    by_id = Container.get_container_type_by_id(
        live_rest_client,
        first_type.id,
    )

    assert by_name.id == first_type.id
    assert by_id.id == first_type.id

    print(f"Reading field map for container type id={first_type.id!r}")

    field_map = Container.get_container_type_field_map_by_id(
        live_rest_client,
        first_type.id,
    )

    assert isinstance(field_map, dict)

    print(f"Field map has {len(field_map)} field(s)")


def test_live_can_list_location_inventory_types(live_rest_client):
    print("Listing location inventory types from the live API")

    location_types = Inventory.get_inventory_types(
        live_rest_client,
        "location",
    )

    assert not isinstance(location_types, ErrorList), location_types
    assert isinstance(location_types, InventoryTypeResponseList)
    assert location_types.data

    first_type = location_types.data[0]

    print(
        "Checking first location inventory type: "
        f"id={first_type.id!r}, name={first_type.attributes.name!r}"
    )

    assert first_type.id
    assert first_type.attributes
    assert first_type.attributes.name
