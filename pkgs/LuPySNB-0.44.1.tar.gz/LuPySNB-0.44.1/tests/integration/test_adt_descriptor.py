import os

import pytest

from LuPySNB import API
from LuPySNB.model.responses.ADTDescriptor import ADTDescriptor
from LuPySNB.model.responses.ErrorList import ErrorList

from tests.integration.constants import DEFAULT_ADT_NAME, DEFAULT_EXPERIMENT_NAME


pytestmark = pytest.mark.integration


@pytest.fixture
def live_adt_eid(live_rest_client):
    print("[live_adt_eid] Resolving live ADT/grid id for descriptor tests")

    experiment_name = os.getenv(
        "LUPYSNB_TEST_EXPERIMENT_NAME",
        DEFAULT_EXPERIMENT_NAME,
    )
    adt_name = os.getenv(
        "LUPYSNB_TEST_ADT_NAME",
        DEFAULT_ADT_NAME,
    )
    print(f"[live_adt_eid] Looking up experiment {experiment_name!r}")

    experiment_eid = API.Experiment.get_experiment_id_by_name(
        live_rest_client,
        experiment_name,
        False,
    )
    print(f"[live_adt_eid] Experiment lookup returned: {experiment_eid!r}")

    assert experiment_eid is not None, f"No experiment found with name: {experiment_name}"
    assert not isinstance(experiment_eid, ErrorList), experiment_eid

    print(f"[live_adt_eid] Looking up ADT/grid {adt_name!r} under {experiment_eid!r}")
    adt_eid = API.ADT.get_experiment_adt_id_by_name(
        live_rest_client,
        experiment_eid,
        adt_name,
    )
    print(f"[live_adt_eid] ADT/grid lookup returned: {adt_eid!r}")

    assert adt_eid is not None, f"No ADT/grid named {adt_name!r} found under experiment {experiment_name!r}"
    assert not isinstance(adt_eid, ErrorList), adt_eid

    print(f"[live_adt_eid] Using ADT/grid id {adt_eid!r}")
    return adt_eid


def test_live_can_read_adt_descriptor(live_rest_client, live_adt_eid):
    print(f"[test_live_can_read_adt_descriptor] Reading descriptor for ADT/grid {live_adt_eid!r}")
    adt_descriptor = API.ADT.get_experiment_adt_cols(
        live_rest_client,
        live_adt_eid,
    )
    print(
        "[test_live_can_read_adt_descriptor] Descriptor response type: "
        f"{type(adt_descriptor).__name__}"
    )

    assert not isinstance(adt_descriptor, ErrorList), adt_descriptor
    assert isinstance(adt_descriptor, ADTDescriptor)

    print("[test_live_can_read_adt_descriptor] Verifying descriptor links, data, and attributes")
    assert adt_descriptor.links is not None
    assert adt_descriptor.data is not None
    assert adt_descriptor.data.attributes is not None
    print("[test_live_can_read_adt_descriptor] Descriptor shape checks completed successfully")


def test_live_adt_descriptor_has_columns(live_rest_client, live_adt_eid):
    print(f"[test_live_adt_descriptor_has_columns] Reading descriptor for ADT/grid {live_adt_eid!r}")
    adt_descriptor = API.ADT.get_experiment_adt_cols(
        live_rest_client,
        live_adt_eid,
    )
    print(
        "[test_live_adt_descriptor_has_columns] Descriptor response type: "
        f"{type(adt_descriptor).__name__}"
    )

    assert not isinstance(adt_descriptor, ErrorList), adt_descriptor
    assert isinstance(adt_descriptor, ADTDescriptor)

    columns = adt_descriptor.data.attributes.columns
    print(f"[test_live_adt_descriptor_has_columns] Found {len(columns) if columns else 0} columns")

    assert columns

    first_column = columns[0]
    print(
        "[test_live_adt_descriptor_has_columns] Verifying first column fields: "
        f"key={first_column.key!r}, title={first_column.title!r}, type={first_column.type!r}"
    )

    assert first_column.key
    assert first_column.title
    assert first_column.type
    print("[test_live_adt_descriptor_has_columns] Column field checks completed successfully")

