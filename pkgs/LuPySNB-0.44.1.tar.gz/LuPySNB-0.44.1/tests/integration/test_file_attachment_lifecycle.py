import os
import uuid
from datetime import date
from io import BytesIO

import pytest

from LuPySNB.API.Entity import (
    create_entity,
    delete_entity,
    get_entity_id_by_name,
)
from LuPySNB.API.FileAttachment import (
    add_file_attachment,
    get_file_attachment,
    update_file_attachment,
)
from LuPySNB.model.responses.Attachment import Attachment
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.File import File

from tests.integration.constants import (
    DEFAULT_GRID_TEMPLATE_NAME,
    DEFAULT_PARENT_EXPERIMENT_ID,
)


pytestmark = pytest.mark.integration


def _created_entity_id(create_response):
    """Extract the created entity id from the SDK response."""
    if hasattr(create_response, "data"):
        if hasattr(create_response.data, "id"):
            return create_response.data.id
        if hasattr(create_response.data, "attributes") and hasattr(create_response.data.attributes, "id"):
            return create_response.data.attributes.id

    raise AssertionError(f"Could not find created entity id in response: {create_response!r}")


def _assert_downloaded_file_contains(downloaded_file, file_name, expected_content):
    assert not isinstance(downloaded_file, ErrorList), downloaded_file
    assert isinstance(downloaded_file, File)
    assert downloaded_file.filename == file_name
    assert downloaded_file.mime_type
    assert downloaded_file.content

    expected_text = expected_content.decode("utf-8").strip()
    downloaded_text = downloaded_file.content.decode("utf-8", errors="replace")

    assert expected_text in downloaded_text


def test_live_can_add_download_update_file_attachment_then_cleanup(live_rest_client):
    grid_template_name = os.getenv(
        "LUPYSNB_TEST_GRID_TEMPLATE_NAME",
        DEFAULT_GRID_TEMPLATE_NAME,
    )
    parent_experiment_id = os.getenv(
        "LUPYSNB_TEST_PARENT_EXPERIMENT_ID",
        DEFAULT_PARENT_EXPERIMENT_ID,
    )

    test_name = f"pytest-attachment-lifecycle-{date.today().isoformat()}-{uuid.uuid4()}"
    file_name = f"pytest-attachment-{uuid.uuid4()}.txt"
    upload_mime_type = "text/plain"
    initial_content = f"initial attachment content {uuid.uuid4()}\n".encode("utf-8")
    replacement_content = f"replacement attachment content {uuid.uuid4()}\n".encode("utf-8")

    created_grid_id = None

    try:
        print(f"Finding grid template by name: {grid_template_name!r}")

        grid_template_id = get_entity_id_by_name(
            live_rest_client,
            grid_template_name,
            "grid",
            True,
            is_system=True,
            has_no_parent=True,
        )

        assert grid_template_id is not None, f"No grid template found with name: {grid_template_name}"
        assert not isinstance(grid_template_id, ErrorList), grid_template_id

        print(f"Resolved grid template {grid_template_name!r} to id={grid_template_id!r}")
        print(
            "Creating temporary grid for attachment lifecycle test: "
            f"name={test_name!r}, parent_experiment_id={parent_experiment_id!r}"
        )

        create_response = create_entity(
            live_rest_client,
            template_id=grid_template_id,
            ancestor_id=parent_experiment_id,
            attributes={
                "name": test_name,
            },
        )

        assert not isinstance(create_response, ErrorList), create_response
        created_grid_id = _created_entity_id(create_response)

        print(f"Created temporary grid: id={created_grid_id!r}")
        print(
            "Adding file attachment: "
            f"parent_id={created_grid_id!r}, filename={file_name!r}, upload_mime_type={upload_mime_type!r}"
        )

        add_response = add_file_attachment(
            live_rest_client,
            created_grid_id,
            file_name,
            upload_mime_type,
            BytesIO(initial_content),
        )

        assert not isinstance(add_response, ErrorList), add_response
        assert isinstance(add_response, Attachment)
        assert add_response.data.id
        assert add_response.data.type

        attachment_id = add_response.data.id

        print(f"Added file attachment: id={attachment_id!r}, type={add_response.data.type!r}")
        print(f"Downloading initial attachment: id={attachment_id!r}")

        initial_file = get_file_attachment(live_rest_client, attachment_id)

        _assert_downloaded_file_contains(
            initial_file,
            file_name,
            initial_content,
        )

        print(
            "Downloaded initial attachment successfully: "
            f"filename={initial_file.filename!r}, "
            f"mime_type={initial_file.mime_type!r}, "
            f"bytes={len(initial_file.content)}"
        )
        print(f"Updating attachment content: id={attachment_id!r}")

        update_response = update_file_attachment(
            live_rest_client,
            attachment_id,
            upload_mime_type,
            BytesIO(replacement_content),
        )

        assert not isinstance(update_response, ErrorList), update_response
        assert isinstance(update_response, Attachment)
        assert update_response.data.id == attachment_id

        print(f"Updated attachment successfully: id={update_response.data.id!r}")
        print(f"Downloading updated attachment: id={attachment_id!r}")

        updated_file = get_file_attachment(live_rest_client, attachment_id)

        _assert_downloaded_file_contains(
            updated_file,
            file_name,
            replacement_content,
        )

        print(
            "Verified updated attachment content: "
            f"filename={updated_file.filename!r}, "
            f"mime_type={updated_file.mime_type!r}, "
            f"bytes={len(updated_file.content)}"
        )

    finally:
        if created_grid_id is not None:
            print(f"Deleting temporary grid: id={created_grid_id!r}")

            delete_response = delete_entity(live_rest_client, created_grid_id)

            assert delete_response is None or not isinstance(delete_response, ErrorList), delete_response

            print(f"Deleted temporary grid: id={created_grid_id!r}")

