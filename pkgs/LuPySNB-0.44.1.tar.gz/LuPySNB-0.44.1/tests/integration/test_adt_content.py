import os

import pytest

from LuPySNB import API
from LuPySNB.model.responses.ADTContent import ADTContent
from LuPySNB.model.responses.ErrorList import ErrorList

from tests.integration.constants import DEFAULT_ADT_NAME, DEFAULT_EXPERIMENT_NAME


pytestmark = pytest.mark.integration


def test_live_can_read_adt_content(live_rest_client):
    print("[test_live_can_read_adt_content] Starting ADT content read integration test")
    experiment_name = os.getenv(
        "LUPYSNB_TEST_EXPERIMENT_NAME",
        DEFAULT_EXPERIMENT_NAME,
    )
    adt_name = os.getenv(
        "LUPYSNB_TEST_ADT_NAME",
        DEFAULT_ADT_NAME,
    )

    print(
        "[test_live_can_read_adt_content] Looking up experiment "
        f"{experiment_name!r} and ADT/grid {adt_name!r}"
    )

    experiment_eid = API.Experiment.get_experiment_id_by_name(
        live_rest_client,
        experiment_name,
        False,
    )

    print(f"[test_live_can_read_adt_content] Experiment lookup returned: {experiment_eid!r}")

    assert experiment_eid is not None, f"No experiment found with name: {experiment_name}"
    assert not isinstance(experiment_eid, ErrorList), experiment_eid

    print(
        "[test_live_can_read_adt_content] Looking up ADT/grid id under experiment "
        f"{experiment_eid!r}"
    )

    adt_eid = API.ADT.get_experiment_adt_id_by_name(
        live_rest_client,
        experiment_eid,
        adt_name,
    )

    print(f"[test_live_can_read_adt_content] ADT/grid lookup returned: {adt_eid!r}")

    assert adt_eid is not None, f"No ADT/grid named {adt_name!r} found under experiment {experiment_name!r}"
    assert not isinstance(adt_eid, ErrorList), adt_eid

    print(f"[test_live_can_read_adt_content] Reading ADT content for {adt_eid!r}")

    adt_content = API.ADT.get_adt_data(
        live_rest_client,
        adt_eid,
    )

    assert not isinstance(adt_content, ErrorList), adt_content
    assert isinstance(adt_content, ADTContent)

    print("[test_live_can_read_adt_content] Verifying links, data list, and included list")
    assert adt_content.links is not None
    assert isinstance(adt_content.data, list)
    assert isinstance(adt_content.included, list)
    print("[test_live_can_read_adt_content] ADT content read checks completed successfully")

def test_live_adt_content_has_digest(live_rest_client):
    print("[test_live_adt_content_has_digest] Starting ADT content digest integration test")
    experiment_name = os.getenv(
        "LUPYSNB_TEST_EXPERIMENT_NAME",
        DEFAULT_EXPERIMENT_NAME,
    )
    adt_name = os.getenv(
        "LUPYSNB_TEST_ADT_NAME",
        DEFAULT_ADT_NAME,
    )

    print(
        "[test_live_adt_content_has_digest] Looking up experiment "
        f"{experiment_name!r} and ADT/grid {adt_name!r}"
    )

    experiment_eid = API.Experiment.get_experiment_id_by_name(
        live_rest_client,
        experiment_name,
        False,
    )
    print(f"[test_live_adt_content_has_digest] Experiment lookup returned: {experiment_eid!r}")

    assert experiment_eid is not None, f"No experiment found with name: {experiment_name}"
    assert not isinstance(experiment_eid, ErrorList), experiment_eid

    print(
        "[test_live_adt_content_has_digest] Looking up ADT/grid id under experiment "
        f"{experiment_eid!r}"
    )
    adt_eid = API.ADT.get_experiment_adt_id_by_name(
        live_rest_client,
        experiment_eid,
        adt_name,
    )
    print(f"[test_live_adt_content_has_digest] ADT/grid lookup returned: {adt_eid!r}")

    assert adt_eid is not None, f"No ADT/grid named {adt_name!r} found under experiment {experiment_name!r}"
    assert not isinstance(adt_eid, ErrorList), adt_eid

    print(f"[test_live_adt_content_has_digest] Reading ADT content for {adt_eid!r}")
    adt_content = API.ADT.get_adt_data(
        live_rest_client,
        adt_eid,
    )
    print(
        "[test_live_adt_content_has_digest] ADT content response type: "
        f"{type(adt_content).__name__}"
    )

    assert not isinstance(adt_content, ErrorList), adt_content
    assert isinstance(adt_content, ADTContent)

    print("[test_live_adt_content_has_digest] Verifying digest exists and is a string")
    assert adt_content.digest is not None
    assert isinstance(adt_content.digest, str)
    print(
        "[test_live_adt_content_has_digest] ADT digest check completed successfully; "
        f"digest length={len(adt_content.digest)}"
    )
