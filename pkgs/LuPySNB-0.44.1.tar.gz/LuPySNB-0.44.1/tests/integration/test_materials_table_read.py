import os

import pytest

from LuPySNB import API
from LuPySNB.API.MaterialsTable import (
    get_experiment_materials_table_id_by_name,
    get_materials_table_data,
)
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.MaterialsTable import MaterialsTable

from tests.integration.constants import (
    DEFAULT_EXPERIMENT_NAME,
    DEFAULT_MATERIALS_TABLE_NAME,
)


pytestmark = pytest.mark.integration

@pytest.fixture
def live_materials_table_experiment_eid(live_rest_client):
    experiment_name = os.getenv(
        "LUPYSNB_TEST_EXPERIMENT_NAME",
        DEFAULT_EXPERIMENT_NAME,
    )

    print(f"Finding experiment by name: {experiment_name!r}")

    experiment_eid = API.Experiment.get_experiment_id_by_name(
        live_rest_client,
        experiment_name,
        False,
    )

    assert experiment_eid is not None, f"No experiment found with name: {experiment_name}"
    assert not isinstance(experiment_eid, ErrorList), experiment_eid
    assert experiment_eid.startswith("experiment:")

    print(f"Resolved experiment {experiment_name!r} to id={experiment_eid!r}")

    return experiment_eid

@pytest.fixture
def live_materials_table_name():
    return os.getenv(
        "LUPYSNB_TEST_MATERIALS_TABLE_NAME",
        DEFAULT_MATERIALS_TABLE_NAME,
    )

@pytest.fixture
def live_materials_table_eid(
    live_rest_client,
    live_materials_table_experiment_eid,
    live_materials_table_name,
):
    print(
        "Finding materials table by name under experiment: "
        f"materials_table={live_materials_table_name!r}, "
        f"experiment_id={live_materials_table_experiment_eid!r}"
    )

    materials_table_eid = get_experiment_materials_table_id_by_name(
        live_rest_client,
        live_materials_table_experiment_eid,
        live_materials_table_name,
    )

    assert not isinstance(materials_table_eid, ErrorList), materials_table_eid
    assert materials_table_eid is not None, (
        f"No materials table named {live_materials_table_name!r} found under "
        f"experiment {live_materials_table_experiment_eid!r}"
    )
    assert materials_table_eid.startswith("materialsTable:")

    print(f"Resolved materials table {live_materials_table_name!r} to id={materials_table_eid!r}")

    return materials_table_eid


def test_live_can_find_materials_table_by_name_under_experiment(live_materials_table_eid):
    assert live_materials_table_eid.startswith("materialsTable:")


def test_live_can_read_materials_table_data(live_rest_client, live_materials_table_eid):
    print(f"Reading materials table data for id={live_materials_table_eid!r}")

    materials_table = get_materials_table_data(
        live_rest_client,
        live_materials_table_eid,
    )

    assert not isinstance(materials_table, ErrorList), materials_table
    assert isinstance(materials_table, MaterialsTable)
    assert materials_table.links is not None
    assert isinstance(materials_table.data, list)

    for row in materials_table.data:
        assert row.id
        assert row.type
        assert row.attributes
        assert row.attributes.id
        assert isinstance(row.attributes.cells, list)

    print(f"Read {len(materials_table.data)} materials table row(s)")

