DEFAULT_BASE_URL = "https://lundbeck-sandbox.signalsresearch.revvitycloud.eu/api/rest/v1.0/"
DEFAULT_AUTH_HEADER_NAME = "x-api-key"

DEFAULT_GRID_TEMPLATE_NAME = "tick@lab: Batch Data"
DEFAULT_PARENT_EXPERIMENT_ID = "experiment:7ebd00cc-17db-431e-9945-caa5cf7228e3"

DEFAULT_WORKSHEET_NAME = "HLU - Sample Analysis Worksheet"
DEFAULT_WORKSHEET_ID = "worksheet:cbf439cb-003b-4dca-a1bf-b70ee3b833eb"
DEFAULT_EXPERIMENT_NAME = "SNB:EXP-130"
DEFAULT_ADT_NAME = "tick@lab: Batch Data"
DEFAULT_MATERIALS_TABLE_NAME = "Materials Table-1"

DEFAULT_ATTRIBUTE_NAME = "Area of Work"
