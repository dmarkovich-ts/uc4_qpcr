import pytest

from LuPySNB.API.Entity import EntityType, get_entities
from LuPySNB.model.responses.EntityDescriptorList import EntityDescriptorList
from LuPySNB.model.responses.ErrorList import ErrorList


pytestmark = pytest.mark.integration


def test_live_can_list_untrashed_experiments(live_rest_client):
    entities = get_entities(
        live_rest_client,
        include_types=[EntityType.experiment],
    )

    assert not isinstance(entities, ErrorList), entities
    assert isinstance(entities, EntityDescriptorList)

    assert entities.links is not None
    assert entities.data

    first_entity = entities.data[0]

    assert first_entity.id.startswith("experiment:")
    assert first_entity.attributes.eid.startswith("experiment:")
    assert first_entity.attributes.name
    assert first_entity.attributes.type == "experiment"
