import os

import pytest
import pytest_asyncio

from LuPySNB.REST.RestClientAsyncHTTPX import RestClientAsyncHTTPX
from LuPySNB.REST.RestClientHTTPX import RestClientHTTPX
from LuPySNB.REST.RestConfig import RestConfig

from tests.integration.constants import DEFAULT_BASE_URL, DEFAULT_AUTH_HEADER_NAME


PLACEHOLDER_VALUES = {"your-api-key"}


def missing_live_api_config():
    required = [
        "LUPYSNB_API_KEY",
    ]
    return [name for name in required if not os.getenv(name) or os.getenv(name) in PLACEHOLDER_VALUES]


@pytest.fixture
def live_rest_client():
    """Create a real REST client for Lundbeck Signals integration tests.

    Required:
    - LUPYSNB_API_KEY

    Optional overrides:
    - LUPYSNB_BASE_URL
    - LUPYSNB_AUTH_HEADER_NAME
    - LUPYSNB_VERIFY_SSL
    """
    missing = missing_live_api_config()
    if missing:
        pytest.skip(f"Live API config missing: {', '.join(missing)}")

    api_key = os.environ["LUPYSNB_API_KEY"]

    base_url = os.getenv("LUPYSNB_BASE_URL", DEFAULT_BASE_URL)
    auth_header_name = os.getenv("LUPYSNB_AUTH_HEADER_NAME", DEFAULT_AUTH_HEADER_NAME)
    verify_ssl = os.getenv("LUPYSNB_VERIFY_SSL", "true").lower() != "false"

    headers = {
        auth_header_name: api_key,
        "Content-Type": "application/vnd.api+json",
        "Accept": "application/vnd.api+json",
    }

    config = RestConfig(
        base_url=base_url.rstrip("/"),
        headers=headers,
        request_verify=verify_ssl,
        request_timeout=30,
        auto_expand=False,
        raise_on_signals_error=False,
    )

    with RestClientHTTPX(config) as client:
        yield client


@pytest_asyncio.fixture
async def live_async_rest_client():
    """Create a real async REST client for Lundbeck Signals integration tests."""
    missing = missing_live_api_config()
    if missing:
        pytest.skip(f"Live API config missing: {', '.join(missing)}")

    api_key = os.environ["LUPYSNB_API_KEY"]

    base_url = os.getenv("LUPYSNB_BASE_URL", DEFAULT_BASE_URL)
    auth_header_name = os.getenv("LUPYSNB_AUTH_HEADER_NAME", DEFAULT_AUTH_HEADER_NAME)
    verify_ssl = os.getenv("LUPYSNB_VERIFY_SSL", "true").lower() != "false"

    headers = {
        auth_header_name: api_key,
        "Content-Type": "application/vnd.api+json",
        "Accept": "application/vnd.api+json",
    }

    config = RestConfig(
        base_url=base_url.rstrip("/"),
        headers=headers,
        request_verify=verify_ssl,
        request_timeout=30,
        auto_expand=False,
        raise_on_signals_error=False,
    )

    async with RestClientAsyncHTTPX(config) as client:
        yield client
