import os

import pytest

from LuPySNB.API import Attribute
from LuPySNB.model.responses.AttributeDetailDescriptor import AttributeDetailDescriptor
from LuPySNB.model.responses.ErrorList import ErrorList

from tests.integration.constants import DEFAULT_ATTRIBUTE_NAME


pytestmark = pytest.mark.integration


@pytest.fixture
def live_attribute_name():
    return os.getenv(
        "LUPYSNB_TEST_ATTRIBUTE_NAME",
        DEFAULT_ATTRIBUTE_NAME,
    )


def test_live_can_find_attribute_by_name(live_rest_client, live_attribute_name):
    print(f"Finding attribute by name: {live_attribute_name!r}")

    attributes = Attribute.get_attribute_by_name(
        live_rest_client,
        live_attribute_name,
    )

    assert not isinstance(attributes, ErrorList), attributes
    assert attributes

    for attribute in attributes:
        assert attribute.name == live_attribute_name
        assert attribute.eid

    print(f"Found {len(attributes)} attribute(s) named {live_attribute_name!r}")


def test_live_can_read_attribute_details(live_rest_client, live_attribute_name):
    print(f"Resolving attribute id by name: {live_attribute_name!r}")

    attribute_id = Attribute.get_attribute_id_by_name(
        live_rest_client,
        live_attribute_name,
    )

    assert attribute_id is not None, f"No attribute found with name: {live_attribute_name}"

    print(f"Reading attribute details for id={attribute_id!r}")

    attribute_details = Attribute.get_attribute_details(
        live_rest_client,
        attribute_id,
    )

    assert not isinstance(attribute_details, ErrorList), attribute_details
    assert isinstance(attribute_details, AttributeDetailDescriptor)
    assert attribute_details.data

    print(f"Read attribute details successfully for id={attribute_id!r}")
