import os
import uuid
from datetime import date

import pytest

from LuPySNB import API
from LuPySNB.API.Entity import (
    create_entity,
    delete_entity,
    get_entity_id_by_name,
)
from LuPySNB.model.responses.ADTContent import ADTContent
from LuPySNB.model.responses.ADTDescriptor import ADTDescriptor
from LuPySNB.model.responses.ADTRow import ADTRow
from LuPySNB.model.responses.ErrorList import ErrorList

from tests.integration.constants import (
    DEFAULT_GRID_TEMPLATE_NAME,
    DEFAULT_PARENT_EXPERIMENT_ID,
)


pytestmark = pytest.mark.integration


def _created_entity_id(create_response):
    print("[_created_entity_id] Extracting created entity id from create response")

    if hasattr(create_response, "data"):
        if hasattr(create_response.data, "id"):
            print(f"[_created_entity_id] Found id on response data: {create_response.data.id!r}")
            return create_response.data.id
        if hasattr(create_response.data, "attributes") and hasattr(create_response.data.attributes, "id"):
            print(
                "[_created_entity_id] Found id on response data attributes: "
                f"{create_response.data.attributes.id!r}"
            )
            return create_response.data.attributes.id

    raise AssertionError(f"Could not find created entity id in response: {create_response!r}")


def _first_writable_text_column(adt_descriptor):
    print("[_first_writable_text_column] Searching descriptor for writable text/string column")
    columns = adt_descriptor.data.attributes.columns

    for index, column in enumerate(columns):
        print(
            "[_first_writable_text_column] Inspecting column "
            f"#{index}: key={column.key!r}, type={column.type!r}, method={column.method!r}"
        )
        if column.method not in ("header", None):
            print(f"[_first_writable_text_column] Skipping {column.key!r}: method is not writable header/None")
            continue

        if column.type in ("text", "string"):
            print(f"[_first_writable_text_column] Selected writable column {column.key!r}")
            return column

    print("[_first_writable_text_column] No writable text/string column found; skipping test")
    pytest.skip("No writable text/string ADT column found for row lifecycle test")


def test_live_can_insert_adt_row_then_cleanup_grid(live_rest_client):
    print("[test_live_can_insert_adt_row_then_cleanup_grid] Starting ADT row lifecycle integration test")

    grid_template_name = os.getenv(
        "LUPYSNB_TEST_GRID_TEMPLATE_NAME",
        DEFAULT_GRID_TEMPLATE_NAME,
    )
    parent_experiment_id = os.getenv(
        "LUPYSNB_TEST_PARENT_EXPERIMENT_ID",
        DEFAULT_PARENT_EXPERIMENT_ID,
    )
    print(
        "[test_live_can_insert_adt_row_then_cleanup_grid] Using grid template "
        f"{grid_template_name!r} and parent experiment {parent_experiment_id!r}"
    )

    test_name = f"pytest-row-lifecycle-{date.today().isoformat()}-{uuid.uuid4()}"
    print(f"[test_live_can_insert_adt_row_then_cleanup_grid] Temporary grid name: {test_name!r}")
    created_grid_id = None

    try:
        print("[test_live_can_insert_adt_row_then_cleanup_grid] Looking up grid template id")
        grid_template_id = get_entity_id_by_name(
            live_rest_client,
            grid_template_name,
            "grid",
            True,
            is_system=True,
            has_no_parent=True,
        )
        print(
            "[test_live_can_insert_adt_row_then_cleanup_grid] Grid template lookup returned: "
            f"{grid_template_id!r}"
        )

        assert grid_template_id is not None, f"No grid template found with name: {grid_template_name}"
        assert not isinstance(grid_template_id, ErrorList), grid_template_id

        print("[test_live_can_insert_adt_row_then_cleanup_grid] Creating temporary grid")
        create_response = create_entity(
            live_rest_client,
            template_id=grid_template_id,
            ancestor_id=parent_experiment_id,
            attributes={
                "name": test_name,
            },
        )
        print(
            "[test_live_can_insert_adt_row_then_cleanup_grid] Create response type: "
            f"{type(create_response).__name__}"
        )

        assert not isinstance(create_response, ErrorList), create_response
        created_grid_id = _created_entity_id(create_response)
        print(f"[test_live_can_insert_adt_row_then_cleanup_grid] Created temporary grid: {created_grid_id!r}")

        print("[test_live_can_insert_adt_row_then_cleanup_grid] Reading ADT descriptor for temporary grid")
        descriptor = API.ADT.get_experiment_adt_cols(
            live_rest_client,
            created_grid_id,
        )
        print(
            "[test_live_can_insert_adt_row_then_cleanup_grid] Descriptor response type: "
            f"{type(descriptor).__name__}"
        )

        assert not isinstance(descriptor, ErrorList), descriptor
        assert isinstance(descriptor, ADTDescriptor)

        writable_column = _first_writable_text_column(descriptor)
        row_value = f"pytest-row-{uuid.uuid4()}"
        print(
            "[test_live_can_insert_adt_row_then_cleanup_grid] Inserting ADT row with "
            f"column={writable_column.key!r}, type={writable_column.type!r}, value={row_value!r}"
        )

        insert_response = API.ADT.insert_adt_row_by_col_ids(
            live_rest_client,
            created_grid_id,
            [
                (
                    writable_column.key,
                    writable_column.type,
                    row_value,
                )
            ],
        )
        print(
            "[test_live_can_insert_adt_row_then_cleanup_grid] Insert row response type: "
            f"{type(insert_response).__name__}"
        )

        assert not isinstance(insert_response, ErrorList), insert_response
        assert isinstance(insert_response, ADTRow)

        print("[test_live_can_insert_adt_row_then_cleanup_grid] Reading ADT content after insert")
        content = API.ADT.get_adt_data(
            live_rest_client,
            created_grid_id,
        )
        print(
            "[test_live_can_insert_adt_row_then_cleanup_grid] Content response type: "
            f"{type(content).__name__}; row count={len(content.data) if hasattr(content, 'data') and content.data else 0}"
        )

        assert not isinstance(content, ErrorList), content
        assert isinstance(content, ADTContent)
        assert content.data

        inserted_values = [
            cell.content.value
            for row in content.data
            for cell in (row.attributes.cells or [])
            if cell.key == writable_column.key and cell.content is not None
        ]
        assert row_value in inserted_values, (
            f"Inserted value {row_value!r} not found in column {writable_column.key!r}; "
            f"found: {inserted_values!r}"
        )
        print("[test_live_can_insert_adt_row_then_cleanup_grid] Inserted row is visible in ADT content")

    finally:
        if created_grid_id is not None:
            print(f"[test_live_can_insert_adt_row_then_cleanup_grid] Cleaning up temporary grid {created_grid_id!r}")
            delete_response = delete_entity(live_rest_client, created_grid_id)
            assert delete_response is None or not isinstance(delete_response, ErrorList), delete_response
            print("[test_live_can_insert_adt_row_then_cleanup_grid] Cleanup completed")
        else:
            print("[test_live_can_insert_adt_row_then_cleanup_grid] No temporary grid was created; skipping cleanup")

