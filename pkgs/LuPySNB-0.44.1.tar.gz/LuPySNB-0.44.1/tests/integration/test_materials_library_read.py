import pytest

from LuPySNB.API import MaterialLibrary
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.MaterialLibraryList import MaterialLibraryList


pytestmark = pytest.mark.integration


@pytest.fixture
def live_material_libraries(live_rest_client):
    print("Listing material libraries from the live API")

    libraries = MaterialLibrary.get_material_libraries(live_rest_client)

    assert not isinstance(libraries, ErrorList), libraries
    assert isinstance(libraries, MaterialLibraryList)
    assert libraries.data

    print(f"Found {len(libraries.data)} material libraries")

    return libraries


def test_live_can_list_material_libraries(live_material_libraries):
    first_library = live_material_libraries.data[0]

    print(
        "Checking first material library: "
        f"id={first_library.id!r}, name={first_library.attributes.name!r}"
    )

    assert first_library.id
    assert first_library.attributes
    assert first_library.attributes.name


def test_live_can_find_material_library_by_name(live_rest_client, live_material_libraries):
    first_library = live_material_libraries.data[0]
    library_name = first_library.attributes.name

    print(f"Finding material library by name: {library_name!r}")

    library = MaterialLibrary.get_material_library_by_name(
        live_rest_client,
        library_name,
    )

    assert not isinstance(library, ErrorList), library
    assert library is not None
    assert library.id == first_library.id
    assert library.attributes.name == library_name

    print(f"Resolved material library {library_name!r} to id={library.id!r}")

