import os

import pytest

from LuPySNB import API
from LuPySNB.model.responses.ADTDescriptor import ADTDescriptor
from LuPySNB.model.responses.ErrorList import ErrorList

from tests.integration.constants import DEFAULT_ADT_NAME, DEFAULT_EXPERIMENT_NAME


pytestmark = pytest.mark.integration


@pytest.fixture
def live_adt_descriptor(live_rest_client):
    print("[live_adt_descriptor] Resolving live ADT descriptor for invariant tests")

    experiment_name = os.getenv(
        "LUPYSNB_TEST_EXPERIMENT_NAME",
        DEFAULT_EXPERIMENT_NAME,
    )
    adt_name = os.getenv(
        "LUPYSNB_TEST_ADT_NAME",
        DEFAULT_ADT_NAME,
    )
    print(f"[live_adt_descriptor] Looking up experiment {experiment_name!r}")

    experiment_eid = API.Experiment.get_experiment_id_by_name(
        live_rest_client,
        experiment_name,
        False,
    )
    print(f"[live_adt_descriptor] Experiment lookup returned: {experiment_eid!r}")

    assert experiment_eid is not None, f"No experiment found with name: {experiment_name}"
    assert not isinstance(experiment_eid, ErrorList), experiment_eid

    print(f"[live_adt_descriptor] Looking up ADT/grid {adt_name!r} under {experiment_eid!r}")
    adt_eid = API.ADT.get_experiment_adt_id_by_name(
        live_rest_client,
        experiment_eid,
        adt_name,
    )
    print(f"[live_adt_descriptor] ADT/grid lookup returned: {adt_eid!r}")

    assert adt_eid is not None, f"No ADT/grid named {adt_name!r} found under experiment {experiment_name!r}"
    assert not isinstance(adt_eid, ErrorList), adt_eid

    print(f"[live_adt_descriptor] Reading descriptor for ADT/grid {adt_eid!r}")
    descriptor = API.ADT.get_experiment_adt_cols(
        live_rest_client,
        adt_eid,
    )
    print(f"[live_adt_descriptor] Descriptor response type: {type(descriptor).__name__}")

    assert not isinstance(descriptor, ErrorList), descriptor
    assert isinstance(descriptor, ADTDescriptor)

    print("[live_adt_descriptor] Descriptor resolved successfully")
    return descriptor


def test_live_adt_descriptor_column_keys_are_unique(live_adt_descriptor):
    print("[test_live_adt_descriptor_column_keys_are_unique] Checking descriptor column key uniqueness")
    columns = live_adt_descriptor.data.attributes.columns
    print(
        "[test_live_adt_descriptor_column_keys_are_unique] Column count: "
        f"{len(columns) if columns else 0}"
    )

    assert columns

    keys = [column.key for column in columns]
    print(f"[test_live_adt_descriptor_column_keys_are_unique] Column keys: {keys!r}")

    assert all(keys)
    assert len(keys) == len(set(keys))
    print("[test_live_adt_descriptor_column_keys_are_unique] Column keys are present and unique")


def test_live_adt_descriptor_columns_have_required_fields(live_adt_descriptor):
    print("[test_live_adt_descriptor_columns_have_required_fields] Checking required fields on every column")
    columns = live_adt_descriptor.data.attributes.columns
    print(
        "[test_live_adt_descriptor_columns_have_required_fields] Column count: "
        f"{len(columns) if columns else 0}"
    )

    assert columns

    for index, column in enumerate(columns):
        print(
            "[test_live_adt_descriptor_columns_have_required_fields] Verifying column "
            f"#{index}: key={column.key!r}, title={column.title!r}, type={column.type!r}"
        )
        assert column.key
        assert column.title
        assert column.type

    print("[test_live_adt_descriptor_columns_have_required_fields] All columns have required fields")

