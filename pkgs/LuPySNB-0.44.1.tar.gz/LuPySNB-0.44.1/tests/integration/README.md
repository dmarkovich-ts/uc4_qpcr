# Integration Tests

These tests call the real Lundbeck Signals sandbox API. They require a valid API key.

## Required environment variable

```bash
export LUPYSNB_API_KEY="your-api-key"
```

Optional overrides are defined in `constants.py`.

## Files

### `constants.py`

Contains default values such as:

- base URL
- auth header name
- grid template name
- parent experiment ID
- experiment name
- ADT/grid name

### `conftest.py`

**How do tests connect to the live Signals API?**

Creates the shared `live_rest_client` pytest fixture. It:

- checks that `LUPYSNB_API_KEY` is set
- rejects placeholder
- builds the REST client used by all integration tests

### `test_find_grid_template.py`

**Can the SDK find a grid template by name?**

Tests that the configured grid template, for example `tick@lab: Batch Data`, can be found in the live sandbox.

This is a small read-only smoke test.

### `test_grid_lifecycle.py`

**Can the SDK create, read, use, and clean up a grid?**

Tests the full grid lifecycle:

1. find the grid template
2. create a new test grid
3. read the created grid
4. read ADT data from the grid
5. delete the grid again

This test creates real data, but cleans it up in a `finally` block.

### `test_adt_content.py`

**Can the SDK read ADT/grid data and parse it as `ADTContent`?**

Tests that an existing ADT/grid can be read from a known experiment and parsed into the SDK response model.

It also checks that the `ADTContent.digest` computed property works.

### `test_adt_descriptor.py`

**Can the SDK read ADT/grid column metadata and parse it as `ADTDescriptor`?**

Tests that an existing ADT/grid descriptor can be read from the live sandbox.

It checks that the descriptor:

- parses as `ADTDescriptor`
- contains response data
- contains column definitions
- exposes useful column fields such as `key`, `title`, and `type`

### `test_experiment_read.py`

**Can the SDK find and read an experiment?**

Finds a configured experiment by name, reads it back by entity ID, and verifies that the response:

- parses as `GetEntityResponse`
- has the expected experiment ID
- has the expected name
- has type `experiment`
- contains fields

This is a read-only smoke test.

### `test_adt_row_lifecycle.py`

**Can the SDK insert an ADT/grid row into a newly created grid?**

Tests a fuller ADT row lifecycle:

1. find the configured grid template
2. create a temporary grid under the configured parent experiment
3. read the grid descriptor
4. find a writable text/string column
5. insert a row
6. read ADT content back
7. delete the temporary grid in a `finally` block

This test creates real sandbox data, but cleans it up afterwards.

### `test_adt_descriptor_invariants.py`

**Does the live ADT/grid descriptor look internally consistent?**

Checks descriptor invariants for the configured ADT/grid:

- column keys are present
- column keys are unique
- every column has a key, title, and type

This is a read-only smoke test.

### `test_materials_library_read.py`

**Can the SDK list and resolve material libraries?**

Tests read-only material library APIs by:

- listing material libraries
- selecting the first returned library
- finding that same library by name

### `test_user_read.py`

**Can the SDK list and read users?**

Tests read-only user APIs by:

- listing enabled users
- reading one returned user by ID
- filtering users by alias when at least one enabled user has an alias

### `test_inventory_types_read.py`

**Can the SDK read inventory/container type metadata?**

Tests read-only inventory metadata APIs in two areas:

1. Container type metadata:
   - list container types
   - resolve a returned container type by name
   - resolve the same container type by ID
   - read its field map

2. Location type metadata:
   - list location inventory types
   - verify that at least one returned location type has an ID and name

### `test_worksheet_read.py`

**Can the SDK find and read a worksheet?**

Tests that the configured worksheet can be found under the configured experiment and read from the live sandbox.

It checks that the worksheet:

- is found by name under the experiment
- has the expected worksheet ID
- parses as `Worksheet`
- contains response data
- exposes field definitions with `key`, `title`, and `type`

This is a read-only smoke test.

### `test_attribute_read.py`

**Can the SDK find and read attribute metadata?**

- find attributes by name
- read details for the first matching attribute

### `test_materials_table_read.py`

**Can the SDK find and read a materials table?**

Tests that the configured materials table can be found under the configured experiment and parsed as `MaterialsTable`.

The configured table must have a materials library set.

### `test_file_attachment_lifecycle.py`

**Can the SDK add, download, and update a file attachment?**

Creates a temporary grid, attaches in-memory text content, downloads it, updates the attachment, verifies the exported content, and deletes the grid.

This test creates real sandbox data, but cleans it up afterwards.

### `test_entity_query.py`

**Can the SDK query untrashed experiments?**

`untrashed` is a default value - doesn't need to set.

Tests that the entity query API can list untrashed experiments and parse the response as `EntityDescriptorList`

Verifies that returned list contains at least 1 experiment with:
- Name
- ID
- Type

## Running the tests

From the repository root:

```bash
uv run pytest tests/integration
```

Or from inside `tests/integration`:

```bash
uv run pytest .
```

To run only integration tests by marker:

```bash
uv run pytest -m integration
```

use `-s` to print statements to stdout.

## Notes

- Read-only tests use existing sandbox data.
- Mutation tests create their own test data and clean up afterwards.
