from datetime import datetime

import pytest

from LuPySNB.model.DTOs.FieldDefinition import FieldDefinition
from LuPySNB.model.DTOs.HierarchicalOptions import HierarchicalOptions
from LuPySNB.model.DTOs.MaterialLibraryDescriptor import LibraryField
from LuPySNB.model.DTOs.Plate import Plate
from LuPySNB.model.DTOs.PlateContainer import PlateContainer
from LuPySNB.model.exceptions.LuPySNBArgumentException import LuPySNBArgumentException
from LuPySNB.model.requests.ADTAddRowRequest import ADTAddRowRequest
from LuPySNB.model.requests.ADTBulkAddRowRequest import ADTBulkAddRowRequest
from LuPySNB.model.requests.ADTBulkUpdateRowRequest import ADTBulkUpdateRowRequest
from LuPySNB.model.requests.AttributeOptionsUpdateRequest import AttributeOptionsUpdateRequest
from LuPySNB.model.requests.ContainerAmountUpdateRequest import ContainerAmountUpdateRequest
from LuPySNB.model.requests.ContainerStatusUpdateRequest import ContainerStatusUpdateRequest
from LuPySNB.model.requests.ContainerUpdateRequest import ContainerUpdateRequest
from LuPySNB.model.requests.CreateADORequest import CreateADORequest
from LuPySNB.model.requests.CreateContainerRequest import CreateContainerRequest
from LuPySNB.model.requests.CreateEntityRequest import CreateEntityRequest
from LuPySNB.model.requests.CreateExperimentRequest import CreateExperimentRequest
from LuPySNB.model.requests.CreateInventoryLocationRequest import CreateInventoryLocationRequest
from LuPySNB.model.requests.EntityReview import EntityReview
from LuPySNB.model.requests.Layout import NewPageRequest, PutEntityOnPageRequest
from LuPySNB.model.requests.MaterialAssetRequest import MaterialAssetRequest
from LuPySNB.model.requests.MaterialBatchRequest import MaterialBatchRequest
from LuPySNB.model.requests.MaterialsTableRequest import (
    MaterialsTableAddMultipleRowRequest,
    MaterialsTableAddRowRequest,
)
from LuPySNB.model.requests.PlateUpdateRequest import PlateUpdateRequest
from LuPySNB.model.requests.TransferBatchRequest import TransferBatchRequest
from LuPySNB.model.requests.UpdateEntityRequest import UpdateEntityRequest
from LuPySNB.model.requests.UpdateInventoryLocationRequest import UpdateInventoryLocationRequest
from LuPySNB.model.requests.UpdateMaterialPropertiesRequest import UpdateMaterialPropertiesRequest
from LuPySNB.model.requests.UserRequest import CreateUser, LundbeckOrganization
from LuPySNB.model.requests.WorkssheetUpdateRequest import WorksheetUpdateRequest


def field_map():
    return {"Status": FieldDefinition(key="field:status", title="Status", type="text")}


def library_field(field_id="field:1", data_type="TEXT"):
    return LibraryField(
        id=field_id,
        name="Field",
        dataType=data_type,
        mandatory=False,
        hidden=False,
        definedBy="user",
    )


def test_adt_add_row_request_maps_cells():
    request = ADTAddRowRequest.create([("column:1", "text", "value")])

    cell = request.data.attributes.cells[0]
    assert request.data.type == "adtRow"
    assert cell.key == "column:1"
    assert cell.content.value == "value"


def test_adt_bulk_add_request_maps_rows():
    request = ADTBulkAddRowRequest.create(
        [[("column:1", "text", "first")], [("column:1", "text", "second")]]
    )

    assert [row.attributes.action for row in request.data] == ["create", "create"]
    assert request.data[1].attributes.cells[0].content.value == "second"


def test_adt_bulk_update_request_keeps_row_ids():
    request = ADTBulkUpdateRowRequest.create(
        [("row:1", [("column:1", "integer", 2)])]
    )

    assert request.data[0].id == "row:1"
    assert request.data[0].attributes.action == "update"
    assert request.data[0].attributes.cells[0].content.value == 2


def test_attribute_options_request_creates_flat_options():
    request = AttributeOptionsUpdateRequest.create_flat("attribute:1", ["A", "B"])

    assert request.data.id == "attribute:1"
    assert request.data.attributes.options == ["A", "B"]
    assert request.data.attributes.hierarchicalOptions is None


def test_attribute_options_request_creates_hierarchical_options():
    option = HierarchicalOptions.create("Parent", ["Child"])

    request = AttributeOptionsUpdateRequest.create_hierarchical("attribute:1", [option])

    assert request.data.attributes.hierarchicalOptions == [option]
    assert request.data.attributes.options is None


def test_container_amount_request_sets_amount():
    request = ContainerAmountUpdateRequest.create("2.5 g")

    assert request.data.attributes.amount == "2.5 g"


def test_container_status_request_sets_location_owner_and_coordinates():
    request = ContainerStatusUpdateRequest.create("location:1", 2, 3, "user:1")

    attributes = request.data.attributes
    assert attributes.location.id == "location:1"
    assert attributes.owner.userId == "user:1"
    assert attributes.coordinateX == 2
    assert attributes.coordinateY == 3


def test_container_update_request_maps_named_fields():
    request = ContainerUpdateRequest.create([("Status", "AVAILABLE")], field_map())

    field = request.data.attributes.fields[0]
    assert field.id == "field:status"
    assert field.content.value == "AVAILABLE"


def test_create_ado_request_has_template_and_no_ancestors():
    request = CreateADORequest.create("My ADO", "ado:template", {"Name": "ADO 1"})

    assert request.data.type == "ado"
    assert request.data.meta.adoTypeName == "My ADO"
    assert request.data.relationships.ancestors.data == []
    assert request.data.relationships.template.data.id == "ado:template"


def test_create_container_request_maps_core_values():
    request = CreateContainerRequest.create(
        "containerType:1",
        4.5,
        "location:1",
        2,
        3,
        "ABC",
        "asset:1",
        [("Status", "AVAILABLE")],
        field_map(),
        "mg",
    )

    attributes = request.data.attributes
    assert attributes.typeId == "containerType:1"
    assert attributes.amount == 4.5
    assert attributes.unit == "mg"
    assert attributes.location.id == "location:1"
    assert attributes.contents[0].entityId == "asset:1"
    assert attributes.fields[0].id == "field:status"


def test_create_entity_request_uses_template_type():
    request = CreateEntityRequest.create("experiment:template", "journal:1", {"Name": "Exp"})

    assert request.data.type == "experiment"
    assert request.data.relationships.template.data.id == "experiment:template"
    assert request.data.relationships.ancestors.data[0].id == "journal:1"


def test_create_entity_request_can_create_entity_without_template():
    request = CreateEntityRequest.create(None, None, {"libraryName": "Reagents"}, "materialsTable")

    assert request.data.type == "materialsTable"
    assert request.data.relationships.ancestors.data == []
    assert request.data.relationships.template is None


def test_create_experiment_request_with_notebook():
    request = CreateExperimentRequest.create("experiment:template", "journal:1", {"Name": "Exp"})

    assert request.data.type == "experiment"
    assert request.data.relationships.ancestors.data[0].type == "journal"
    assert request.data.relationships.template.data.id == "experiment:template"


def test_create_experiment_request_without_notebook():
    request = CreateExperimentRequest.create("experiment:template", None, {})

    assert request.data.relationships.ancestors.data == []


def test_create_inventory_location_request_creates_grid():
    request = CreateInventoryLocationRequest.create(
        "location:parent",
        "Shelf",
        "BARCODE",
        4,
        6,
        "locationType:1",
        {"Status": "ACTIVE"},
        field_map(),
    )

    attributes = request.data.attributes
    assert attributes.ancestors == [{"id": "location:parent"}]
    assert attributes.isGrid is True
    assert attributes.rows == 4
    assert attributes.columns == 6
    assert attributes.fields[0].content.value == "ACTIVE"


def test_create_inventory_location_request_without_grid():
    request = CreateInventoryLocationRequest.create(
        None, "Room", None, None, None, "locationType:1", {}, {}
    )

    assert request.data.attributes.ancestors == []
    assert request.data.attributes.isGrid is False


def test_entity_review_request_sets_reason():
    request = EntityReview.create("Ready for review")

    assert request.data.attributes.reason == "Ready for review"


def test_new_page_request_sets_name_and_index():
    request = NewPageRequest.create("Results", 2)

    assert request.data.type == "layoutPage"
    assert request.data.attributes.name == "Results"
    assert request.data.attributes.index == 2


def test_put_entity_on_page_request_sets_page_and_index():
    request = PutEntityOnPageRequest.create("page:1", 3)

    assert request.data.type == "layoutLocation"
    assert request.data.attributes.pageId == "page:1"
    assert request.data.attributes.index == 3


def test_material_batch_request_returns_none_without_field_data():
    assert MaterialBatchRequest.create("batch:1", None, None) is None


def test_material_batch_request_maps_fields():
    request = MaterialBatchRequest.create(
        "batch:1", [("Batch field", "B-1")], {"Batch field": library_field()}
    )

    assert request.data.id == "batch:1"
    assert request.data.attributes.fields[0].id == "field:1"
    assert request.data.attributes.fields[0].value == "B-1"


def test_material_asset_request_maps_asset_and_batch():
    request = MaterialAssetRequest.create(
        "asset:1",
        "batch:1",
        ["Synonym"],
        [("Asset field", "A-1")],
        {"Asset field": library_field("asset-field")},
        [("Batch field", "B-1")],
        {"Batch field": library_field("batch-field")},
    )

    assert request.data.id == "asset:1"
    assert request.data.attributes.synonyms == ["Synonym"]
    assert request.data.attributes.fields[0].id == "asset-field"
    assert request.data.relationships.batch.data.id == "batch:1"


def test_materials_table_add_row_request_defaults_to_no_cells():
    request = MaterialsTableAddRowRequest.create("asset:1")

    assert request.data.attributes.materialId == "asset:1"
    assert request.data.attributes.cells == []


def test_materials_table_add_row_request_maps_cells():
    request = MaterialsTableAddRowRequest.create(
        "asset:1", [{"key": "column:1", "value": "A"}]
    )

    cell = request.data.attributes.cells[0]
    assert cell.key == "column:1"
    assert cell.content.value == "A"


def test_materials_table_multiple_row_request_maps_each_row():
    request = MaterialsTableAddMultipleRowRequest.create(
        ["asset:1", "asset:2"],
        [[{"key": "column:1", "value": "A"}], []],
    )

    assert [row.attributes.materialId for row in request.data] == ["asset:1", "asset:2"]
    assert request.data[0].attributes.cells[0].content.value == "A"
    assert request.data[1].attributes.cells == []


def test_materials_table_multiple_row_request_requires_matching_cells():
    with pytest.raises(ValueError, match="must match"):
        MaterialsTableAddMultipleRowRequest.create(["asset:1", "asset:2"], [[]])


def annotation_layer(data_type="TEXT", annotation_class="other"):
    return PlateContainer.AnnotationLayerDefinition.Attributes.AnnotationLayer(
        id="layer:1",
        name="Result",
        dataType=data_type,
        annotationClass=annotation_class,
        isPredefined=False,
    )


def test_plate_well_content_creates_text_value():
    content = Plate.Attributes.AnnotationLayer.Well.WellContent.create("TEXT", "other", "Positive")

    assert content.type == "TEXT"
    assert content.value == "Positive"


def test_plate_well_content_creates_integer_value():
    content = Plate.Attributes.AnnotationLayer.Well.WellContent.create("INTEGER", "replicate", 2)

    assert content.type == "INTEGER"
    assert content.value == 2


def test_plate_well_content_creates_concentration_value():
    content = Plate.Attributes.AnnotationLayer.Well.WellContent.create(
        "INTEGER", "concentration", (10, "mM")
    )

    assert content.value == "10 mM"


def test_plate_well_content_creates_link_value():
    content = Plate.Attributes.AnnotationLayer.Well.WellContent.create(
        "LINK", "other", ("asset", "asset:1", "Asset 1")
    )

    assert content.type == "asset"
    assert content.value == "asset:1"
    assert content.user == "Asset 1"


def test_plate_update_request_maps_annotation_layers():
    layer = annotation_layer()

    request = PlateUpdateRequest.create(
        "plate-1", {"Result": layer}, [("Result", [("A1", "Positive")])]
    )

    result_layer = request.data.attributes.annotationLayers[0]
    assert request.data.id == "plate-1"
    assert result_layer.id == "layer:1"
    assert result_layer.wells[0].wellId == "A1"
    assert result_layer.wells[0].content.value == "Positive"


def test_plate_update_request_rejects_unknown_layer():
    with pytest.raises(LuPySNBArgumentException, match="Missing annotation layer"):
        PlateUpdateRequest.create("plate-1", {}, [("Missing", [])])


def test_transfer_batch_request_sets_asset_id():
    request = TransferBatchRequest.create("asset:1")

    assert request.data.attributes.assetId == "asset:1"


def test_update_entity_request_maps_each_attribute_set():
    request = UpdateEntityRequest.create([{"name": "Name", "value": "A"}, {"name": "Status", "value": "B"}])

    assert [item.attributes["name"] for item in request.data] == ["Name", "Status"]


def test_update_inventory_location_request_maps_fields():
    request = UpdateInventoryLocationRequest.create([("Status", "ACTIVE")], field_map())

    assert request.data.attributes.fields[0].id == "field:status"
    assert request.data.attributes.fields[0].content.value == "ACTIVE"


def test_update_material_properties_request_maps_names_and_values():
    request = UpdateMaterialPropertiesRequest.create(
        [("CAS", "50-00-0")], {"CAS": library_field("field:cas")}
    )

    assert request.data[0].attributes.name == "CAS"
    assert request.data[0].attributes.value == "50-00-0"


def test_create_user_normalizes_alias_and_builds_email():
    request = CreateUser.create(
        "abc", "Ada", "Lovelace", LundbeckOrganization.lundbeck
    )

    attributes = request.data.attributes
    assert attributes.alias == "ABC"
    assert attributes.emailAddress == "abc@lundbeck.com"
    assert attributes.organization == "lundbeck"
    assert attributes.country == "Denmark"


def test_create_user_rejects_unknown_organization():
    with pytest.raises(ValueError, match="Organization must be one of"):
        CreateUser.create("abc", "Ada", "Lovelace", "other")


def test_worksheet_update_request_maps_fields():
    request = WorksheetUpdateRequest.create(
        "worksheet:1", [("field:1", "datetime", datetime(2026, 1, 1))]
    )

    assert request.data.id == "worksheet:1"
    assert request.data.attributes.fields[0].key == "field:1"
    assert request.data.attributes.fields[0].content.value == datetime(2026, 1, 1)
