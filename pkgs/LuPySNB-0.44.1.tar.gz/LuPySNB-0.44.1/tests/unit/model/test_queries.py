import pytest

from LuPySNB.model.DTOs.Query import (
    AndQueryTerm,
    NotQueryTerm,
    OrQueryTerm,
    Query,
    QueryChild,
    QueryDateRange,
    QueryExists,
    QueryIn,
    QueryMatch,
    QueryParent,
    QueryPrefix,
    QueryRange,
)


def dumped(value):
    return value.model_dump(by_alias=True, exclude_none=True)


@pytest.mark.parametrize(
    "term,expected_key,expected_value",
    [
        (QueryMatch.create("name", "A", "keyword", "text", "tags"), "$match", "A"),
        (QueryPrefix.create("name", "A"), "$prefix", "A"),
        (QueryIn.create("name", ["A", "B"]), "$in", ["A", "B"]),
        (QueryRange.create("amount", 1, 10), "$range", None),
    ],
)
def test_query_expression_serialization(term, expected_key, expected_value):
    result = dumped(term)

    assert expected_key in result
    if expected_value is not None:
        inner = result[expected_key]
        assert inner.get("value", inner.get("values")) == expected_value


def test_query_match_serializes_alias_fields():
    result = dumped(QueryMatch.create("field", "value", "keyword", "text", "tags"))

    assert result == {
        "$match": {
            "field": "field",
            "mode": "keyword",
            "as": "text",
            "in": "tags",
            "value": "value",
        }
    }


def test_query_date_range_uses_default_timezone():
    result = dumped(QueryDateRange.create("modifiedAt", "now-1d", "now"))

    assert result["$range"]["from"] == "now-1d"
    assert result["$range"]["to"] == "now"
    assert result["$range"]["timezone"] == "Europe/Copenhagen"


def test_query_exists_serializes_field():
    assert dumped(QueryExists.create("fields.Path")) == {"$exists": {"field": "fields.Path"}}


def test_query_child_wraps_term():
    term = QueryChild.create(QueryMatch.create("eid", "child:1"))

    assert dumped(term) == {"$child": {"$match": {"field": "eid", "value": "child:1"}}}


def test_query_parent_wraps_term():
    term = QueryParent.create(QueryMatch.create("eid", "parent:1"))

    assert dumped(term) == {"$parent": {"$match": {"field": "eid", "value": "parent:1"}}}


@pytest.mark.parametrize(
    "factory,key",
    [(NotQueryTerm.create, "$not"), (AndQueryTerm.create, "$and"), (OrQueryTerm.create, "$or")],
)
def test_query_boolean_terms_wrap_lists(factory, key):
    term = factory([QueryMatch.create("type", "experiment")])

    assert dumped(term) == {key: [{"$match": {"field": "type", "value": "experiment"}}]}


def test_query_serializes_complete_request():
    query = Query(query=AndQueryTerm.create([QueryMatch.create("name", "Experiment 1")]))

    assert dumped(query) == {
        "query": {"$and": [{"$match": {"field": "name", "value": "Experiment 1"}}]}
    }
