from types import SimpleNamespace

from LuPySNB.model.responses.APIPaginatedQueryResponse import APIPaginatedQueryResponse
from LuPySNB.model.responses.APIPaginatedResponse import APIPaginatedResponse
from LuPySNB.model.responses.APIResponse import APIResponse
from LuPySNB.model.responses.Error import Error
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.PlateResponse import PlateResponse


def test_api_response_has_no_next_link():
    assert APIResponse().next_link() is None


def test_paginated_response_returns_next_link():
    response = APIPaginatedResponse[int](
        links=APIPaginatedResponse.Links(self="page-1", next="page-2"),
        data=[1],
    )

    assert response.next_link() == "page-2"


def test_paginated_response_extends_data_and_links():
    first = APIPaginatedResponse[int](
        links=APIPaginatedResponse.Links(self="page-1", next="page-2"), data=[1]
    )
    second = APIPaginatedResponse[int](
        links=APIPaginatedResponse.Links(self="page-2"), data=[2]
    )

    first.extend(second)

    assert first.data == [1, 2]
    assert first.links.self == "page-2"


def test_paginated_query_response_builds_next_offset():
    response = APIPaginatedQueryResponse[int](
        links=APIPaginatedQueryResponse.Links(self="/search?page[limit]=2&page[offset]=0"),
        meta=APIPaginatedQueryResponse.Meta(count=2, total=5),
        data=[1, 2],
    )

    assert response.next_link() == "/search?page[limit]=2&page[offset]=2"


def test_paginated_query_response_stops_at_total():
    response = APIPaginatedQueryResponse[int](
        links=APIPaginatedQueryResponse.Links(self="/search?page[offset]=0"),
        meta=APIPaginatedQueryResponse.Meta(count=2, total=2),
        data=[1, 2],
    )

    assert response.next_link() is None


def test_error_string_with_title_and_detail():
    error = Error(status=400, code="bad_request", title="Bad request", detail="Invalid value")

    assert str(error) == "400 bad_request: Bad request - Invalid value"


def test_error_string_with_detail_only():
    error = Error(status=400, code="bad_request", detail="Invalid value")

    assert str(error) == "400 bad_request: Invalid value"


def test_error_list_string_numbers_each_error():
    errors = ErrorList(errors=[Error(status=400, code="one"), Error(status=404, code="two")])

    assert str(errors) == "LuPySNB ErrorList:\n0: 400 one\n1: 404 two"


def test_plate_response_digest_returns_plate_container_digest():
    entity = SimpleNamespace(
        type="entity",
        attributes=SimpleNamespace(type="plateContainer", digest="digest-1"),
    )
    response = PlateResponse.model_construct(included=[entity])

    assert response.digest == "digest-1"


def test_plate_response_digest_returns_none_without_entity():
    response = PlateResponse.model_construct(included=[])

    assert response.digest is None
