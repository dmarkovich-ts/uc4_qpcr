from datetime import datetime

import pytest

from LuPySNB.model.DTOs.FieldValue import (
    ExternalLinkFieldValue,
    FieldValue,
    LinkFieldValue,
    MultiselectFieldValues,
    NullFieldValue,
    SimpleFieldValue,
    UnitFieldValue,
)
from LuPySNB.model.DTOs.MaterialFieldValue import (
    ExternalReferenceValue,
    FileAttachmentValue,
    InternalReferenceValue,
    MaterialFieldValue,
)
from LuPySNB.model.exceptions.LuPySNBInternalException import LuPySNBInternalException


def test_field_value_creates_null_value():
    value = FieldValue.create_value("text", None)

    assert isinstance(value, NullFieldValue)
    assert str(value) == ""


@pytest.mark.parametrize("field_type,input_value", [("number", 1.5), ("integer", 2)])
def test_field_value_creates_numeric_value(field_type, input_value):
    value = FieldValue.create_value(field_type, input_value)

    assert value.value == input_value
    assert str(value) == str(input_value)


@pytest.mark.parametrize("field_type", ["text", "variableMeasure", "autotextList"])
def test_field_value_converts_text_types_to_string(field_type):
    value = FieldValue.create_value(field_type, 123)

    assert value.value == "123"


def test_field_value_creates_datetime_value():
    timestamp = datetime(2026, 1, 2, 3, 4)

    value = FieldValue.create_value("datetime", timestamp)

    assert value.value == timestamp


def test_field_value_creates_boolean_value():
    value = FieldValue.create_value("boolean", True)

    assert value.value is True


def test_field_value_creates_link_value():
    value = FieldValue.create_value("link", ("experiment", "Experiment 1", "experiment:1"))

    assert isinstance(value, LinkFieldValue)
    assert str(value) == "Experiment 1"


def test_field_value_creates_external_link_value():
    value = FieldValue.create_value("externalLink", ("Open", "https://example.test"))

    assert isinstance(value, ExternalLinkFieldValue)
    assert value.user == "Open"
    assert str(value) == "https://example.test"


def test_field_value_creates_single_attribute_value():
    value = FieldValue.create_value("attributeList", "Option A")

    assert isinstance(value, SimpleFieldValue)
    assert value.value == "Option A"


def test_field_value_creates_multiple_attribute_values():
    value = FieldValue.create_value("attributeList", ("A", "B"))

    assert isinstance(value, MultiselectFieldValues)
    assert str(value) == "A, B"


def test_field_value_creates_multi_select_value():
    value = FieldValue.create_value("multiSelectList", ["A", "B"])

    assert value.values == ["A", "B"]


def test_field_value_creates_unit_value():
    value = FieldValue.create_value("unit", (2.5, "2.5 mg"))

    assert isinstance(value, UnitFieldValue)
    assert value.value == 2.5
    assert str(value) == "2.5 mg"


@pytest.mark.parametrize(
    "field_type,input_value",
    [
        ("number", "1"),
        ("date", 1),
        ("boolean", "true"),
        ("link", ("only", "two")),
        ("externalLink", ("only-one",)),
        ("attributeList", ["not", "a tuple"]),
        ("multiSelectList", "not-a-list"),
        ("unit", "2 mg"),
        ("unknown", "value"),
    ],
)
def test_field_value_rejects_invalid_input(field_type, input_value):
    with pytest.raises(LuPySNBInternalException):
        FieldValue.create_value(field_type, input_value)


@pytest.mark.parametrize(
    "field_type,input_value",
    [("TEXT", "abc"), ("ATTRIBUTE", "A"), ("INTEGER", 1), ("DECIMAL", 1.5)],
)
def test_material_field_value_returns_simple_values(field_type, input_value):
    assert MaterialFieldValue.create_value(field_type, input_value) == input_value


def test_material_field_value_accepts_attribute_lists():
    assert MaterialFieldValue.create_value("ATTRIBUTE", ["A"]) == ["A"]


def test_material_field_value_creates_datetime():
    timestamp = datetime(2026, 1, 1)

    assert MaterialFieldValue.create_value("DATETIME", timestamp) == timestamp


def test_material_field_value_creates_internal_reference():
    value = MaterialFieldValue.create_value("LINK", ("asset:1", "Asset 1", "asset"))

    assert isinstance(value, InternalReferenceValue)
    assert value.display_value == "Asset 1"


def test_material_field_value_creates_external_reference():
    value = MaterialFieldValue.create_value("EXTERNAL_LINK", ("https://example.test", "Example"))

    assert isinstance(value, ExternalReferenceValue)
    assert value.display_value == "Example"


def test_material_field_value_creates_file_attachment():
    value = MaterialFieldValue.create_value("ATTACHED_FILE", ("report.pdf", "YmFzZTY0"))

    assert isinstance(value, FileAttachmentValue)
    assert value.display_value == "report.pdf"


@pytest.mark.parametrize(
    "field_type,input_value",
    [
        ("TEXT", object()),
        ("DATETIME", "2026-01-01"),
        ("LINK", ("too", "short")),
        ("EXTERNAL_LINK", ("too", "long", "tuple")),
        ("ATTACHED_FILE", "report.pdf"),
        ("UNKNOWN", "value"),
    ],
)
def test_material_field_value_rejects_invalid_input(field_type, input_value):
    with pytest.raises(LuPySNBInternalException):
        MaterialFieldValue.create_value(field_type, input_value)
