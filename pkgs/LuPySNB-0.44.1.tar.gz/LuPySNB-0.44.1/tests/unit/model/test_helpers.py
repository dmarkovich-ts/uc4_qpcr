from types import SimpleNamespace

from LuPySNB.model.DTOs.EntityRelationshipNode import get_entity_type_from_eid
from LuPySNB.model.DTOs.HierarchicalOptions import HierarchicalOptions
from LuPySNB.model.DTOs.InventoryLocation import InventoryLocation
from LuPySNB.model.DTOs.InventoryTypeDefinition import InventoryTypeDefinition
from LuPySNB.model.DTOs.MaterialLibraryDescriptor import MaterialLibraryDescriptor
from LuPySNB.model.DTOs.PlateContainer import PlateContainer


def test_get_entity_type_from_regular_eid():
    assert get_entity_type_from_eid("experiment:123") == "experiment"


def test_get_entity_type_removes_suffix():
    assert get_entity_type_from_eid("asset-batch:123") == "asset"


def test_hierarchical_options_create():
    options = HierarchicalOptions.create("Parent", ["A", "B"])

    assert options.parentValue == "Parent"
    assert options.options == ["A", "B"]


def test_inventory_location_get_path_reverses_ancestors():
    location = InventoryLocation.model_construct(
        attributes=SimpleNamespace(
            ancestors=[{"name": "Child"}, {"name": "Root"}],
            name="Leaf",
        )
    )

    assert location.get_path() == "/Root/Child/Leaf"


def test_inventory_type_definition_builds_field_map():
    field = SimpleNamespace(
        definition=SimpleNamespace(key="field-key", title="Status", type="text")
    )
    inventory_type = InventoryTypeDefinition.model_construct(
        attributes=SimpleNamespace(fields=[field])
    )

    result = inventory_type.get_field_map()

    assert result["Status"].key == "field-key"
    assert result["Status"].type == "text"


def test_material_library_descriptor_builds_asset_field_map():
    field = SimpleNamespace(name="CAS", id="field:1")
    descriptor = MaterialLibraryDescriptor.model_construct(
        attributes=SimpleNamespace(assets=SimpleNamespace(fields=[field]))
    )

    assert descriptor.get_material_library_asset_field_map() == {"CAS": field}


def test_material_library_descriptor_builds_batch_field_map():
    field = SimpleNamespace(name="Batch number", id="field:2")
    descriptor = MaterialLibraryDescriptor.model_construct(
        attributes=SimpleNamespace(batches=SimpleNamespace(fields=[field]))
    )

    assert descriptor.get_material_library_batch_field_map() == {"Batch number": field}


def test_plate_container_builds_annotation_layer_map():
    layer = PlateContainer.AnnotationLayerDefinition.Attributes.AnnotationLayer(
        id="layer:1",
        name="Concentration",
        dataType="number",
        annotationClass="custom",
        isPredefined=False,
    )
    definition = PlateContainer.AnnotationLayerDefinition(
        id="definition:1",
        attributes=PlateContainer.AnnotationLayerDefinition.Attributes(
            id="definition:1",
            type="plate",
            annotationLayers=[layer],
        ),
    )
    container = PlateContainer.model_construct(included=[definition])

    assert container.get_annotation_layer_map() == {"Concentration": layer}
