from importlib import import_module
from io import BytesIO
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import pytest

from LuPySNB.model.exceptions.LuPySNBInternalException import LuPySNBInternalException
from LuPySNB.model.requests.UserRequest import LundbeckOrganization
from LuPySNB.model.responses.Attachment import Attachment
from LuPySNB.model.responses.AttributeDescriptorList import AttributeDescriptorList
from LuPySNB.model.responses.AttributeDetailDescriptor import AttributeDetailDescriptor
from LuPySNB.model.responses.EntityDescriptorList import (
    EntityDescriptorList,
    EntityDescriptorListFromQuery,
)
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.GetEntityResponse import GetEntityResponse
from LuPySNB.model.responses.Layout import Page
from LuPySNB.model.responses.MaterialsTable import MaterialsTableRow
from LuPySNB.model.responses.PlateResponse import PlateResponse
from LuPySNB.model.responses.UserResponse import UserResponse, UserResponseList
from LuPySNB.model.responses.Worksheet import Worksheet as WorksheetResponse

AttributeModule = import_module("LuPySNB.API.Attribute")
FileAttachmentModule = import_module("LuPySNB.API.FileAttachment")
LayoutModule = import_module("LuPySNB.API.Layout")
MaterialsTableModule = import_module("LuPySNB.API.MaterialsTable")
PlateModule = import_module("LuPySNB.API.Plate")
UserModule = import_module("LuPySNB.API.User")
WorksheetModule = import_module("LuPySNB.API.Worksheet")


def entity_list(*items):
    return EntityDescriptorListFromQuery.model_construct(data=list(items))


def test_get_attribute_by_name_calls_attributes_endpoint(client):
    response = AttributeDescriptorList.model_construct(data=[])
    client.invoke_rest_get.return_value = response

    assert AttributeModule.get_attribute_by_name(client, "Status") == []
    client.invoke_rest_get.assert_called_once_with("attributes", AttributeDescriptorList)


def test_update_attribute_options_uses_request_id(client):
    request = SimpleNamespace(data=SimpleNamespace(id="attribute:1"))

    AttributeModule.update_attribute_options(client, request)

    client.invoke_rest_patch.assert_called_once_with(
        "attributes/attribute:1", request, AttributeDetailDescriptor
    )


def test_add_file_attachment_rejects_long_name(client):
    with pytest.raises(LuPySNBInternalException, match="too long"):
        FileAttachmentModule.add_file_attachment(
            client, "experiment:1", "a" * 256, "text/plain", BytesIO(b"data")
        )


def test_add_file_attachment_guesses_mime_type(client):
    content = BytesIO(b"data")

    FileAttachmentModule.add_file_attachment(
        client, "experiment:1", "notes.txt", None, content
    )

    client.invoke_rest_post_file.assert_called_once_with(
        "entities/experiment:1/children/notes.txt?force=true",
        "text/plain",
        content,
        Attachment,
    )


def test_add_file_attachment_quotes_name(client):
    content = BytesIO(b"data")

    FileAttachmentModule.add_file_attachment(
        client, "experiment:1", "my report.txt", "text/plain", content
    )

    assert client.invoke_rest_post_file.call_args.args[0] == (
        "entities/experiment:1/children/my%20report.txt?force=true"
    )


def parent_response(name="Experiment 1", entity_type="experiment"):
    return GetEntityResponse.model_construct(
        data=SimpleNamespace(attributes=SimpleNamespace(name=name, type=entity_type))
    )


def test_replace_file_attachment_updates_existing_file(client):
    content = BytesIO(b"new")
    expected = object()

    with patch.object(FileAttachmentModule, "get_entity_by_id", return_value=parent_response()), patch.object(
        FileAttachmentModule, "get_child_entity_id_by_name", return_value="file:1"
    ), patch.object(FileAttachmentModule, "update_file_attachment", return_value=expected) as update:
        result = FileAttachmentModule.replace_file_attachment(
            client, "experiment:1", "notes.txt", None, content
        )

    assert result is expected
    update.assert_called_once_with(client, "file:1", "text/plain", content)


def test_replace_file_attachment_adds_missing_file(client):
    content = BytesIO(b"new")
    expected = object()

    with patch.object(FileAttachmentModule, "get_entity_by_id", return_value=parent_response()), patch.object(
        FileAttachmentModule, "get_child_entity_id_by_name", return_value=None
    ), patch.object(FileAttachmentModule, "add_file_attachment", return_value=expected) as add:
        result = FileAttachmentModule.replace_file_attachment(
            client, "experiment:1", "notes.bin", None, content
        )

    assert result is expected
    add.assert_called_once_with(
        client, "experiment:1", "notes.bin", "application/octet-stream", content
    )


def test_replace_file_attachment_rejects_missing_parent(client):
    with patch.object(FileAttachmentModule, "get_entity_by_id", return_value=object()):
        with pytest.raises(LuPySNBInternalException, match="No match found"):
            FileAttachmentModule.replace_file_attachment(
                client, "missing:1", "notes.txt", "text/plain", BytesIO()
            )


def test_replace_file_attachment_raises_on_child_lookup_error(client):
    error_list = ErrorList.model_construct(errors=[])

    with patch.object(FileAttachmentModule, "get_entity_by_id", return_value=parent_response()), patch.object(
        FileAttachmentModule, "get_child_entity_id_by_name", return_value=error_list
    ):
        with pytest.raises(LuPySNBInternalException, match="Error retrieving child entity by name"):
            FileAttachmentModule.replace_file_attachment(
                client, "experiment:1", "notes.txt", "text/plain", BytesIO()
            )


@pytest.mark.asyncio
async def test_replace_file_attachment_async_raises_on_child_lookup_error(async_client):
    error_list = ErrorList.model_construct(errors=[])

    with patch.object(
        FileAttachmentModule, "get_entity_by_id_async", AsyncMock(return_value=parent_response())
    ), patch.object(
        FileAttachmentModule, "get_child_entity_id_by_name_async", AsyncMock(return_value=error_list)
    ):
        with pytest.raises(LuPySNBInternalException, match="Error retrieving child entity by name"):
            await FileAttachmentModule.replace_file_attachment_async(
                async_client, "experiment:1", "notes.txt", "text/plain", BytesIO()
            )


def test_create_page_builds_request(client):
    request = object()
    with patch.object(LayoutModule.LayoutRequest.NewPageRequest, "create", return_value=request) as create:
        LayoutModule.create_page(client, "experiment:1", "Results", 2)

    create.assert_called_once_with("Results", 2)
    client.invoke_rest_post.assert_called_once_with(
        "entities/experiment:1/layout/pages?force=true", request, Page
    )


def test_put_entity_on_page_builds_request(client):
    request = object()
    with patch.object(
        LayoutModule.LayoutRequest.PutEntityOnPageRequest, "create", return_value=request
    ) as create:
        LayoutModule.put_entity_on_page(client, "grid:1", "page:1", 3)

    create.assert_called_once_with("page:1", 3)
    client.invoke_rest_put.assert_called_once_with(
        "entities/grid:1/layout/location?force=true", request, Page
    )


def test_materials_table_id_handler_returns_first_eid():
    response = entity_list(
        SimpleNamespace(attributes=SimpleNamespace(eid="materialsTable:1")),
        SimpleNamespace(attributes=SimpleNamespace(eid="materialsTable:2")),
    )

    assert MaterialsTableModule._get_experiment_materials_table_id_by_name_handle_response(
        response
    ) == "materialsTable:1"


def test_materials_table_id_handler_returns_none_for_empty_result():
    assert MaterialsTableModule._get_experiment_materials_table_id_by_name_handle_response(
        entity_list()
    ) is None


def test_get_materials_table_id_uses_child_lookup(client):
    response = entity_list(
        SimpleNamespace(attributes=SimpleNamespace(eid="materialsTable:1"))
    )

    with patch.object(
        MaterialsTableModule, "get_child_entities_by_parent_id", return_value=response
    ) as lookup:
        result = MaterialsTableModule.get_experiment_materials_table_id_by_name(
            client, "experiment:1", "Materials"
        )

    assert result == "materialsTable:1"
    lookup.assert_called_once_with(
        client, "experiment:1", "materialsTable", "Materials"
    )


@pytest.mark.parametrize(
    "digest,endpoint",
    [
        (None, "materialsTable/materialsTable:1/row:1/register?force=true"),
        (
            "digest-1",
            "materialsTable/materialsTable:1/row:1/register?force=false&digest=digest-1",
        ),
    ],
)
def test_register_material_builds_digest_endpoint(digest, endpoint, client):
    MaterialsTableModule.register_material(
        client, "materialsTable:1", "row:1", digest=digest
    )

    client.invoke_rest_post.assert_called_once_with(
        endpoint, None, MaterialsTableRow
    )


@pytest.mark.parametrize(
    "digest,endpoint",
    [
        (None, "plates/plateContainer:1/plates/Plate 1?force=true"),
        (
            "digest-1",
            "plates/plateContainer:1/plates/Plate 1?force=false&digest=digest-1",
        ),
    ],
)
def test_update_plate_builds_digest_endpoint(digest, endpoint, client):
    request = object()

    PlateModule.update_plate(
        client, "plateContainer:1", "Plate 1", request, digest=digest
    )

    client.invoke_rest_patch.assert_called_once_with(
        endpoint, request, PlateResponse
    )


@pytest.mark.parametrize(
    "query_string,enabled,endpoint",
    [
        (None, True, "users/?&enabled=true"),
        ("Ada", False, "users/?q=Ada&enabled=false"),
    ],
)
def test_get_users_builds_query(query_string, enabled, endpoint, client):
    UserModule.get_users(client, query_string=query_string, enabled=enabled)

    client.invoke_rest_get.assert_called_once_with(endpoint, UserResponseList)


def test_get_users_by_alias_is_case_insensitive(monkeypatch, client):
    matching = SimpleNamespace(attributes=SimpleNamespace(alias="ABC"))
    no_alias = SimpleNamespace(attributes=SimpleNamespace(alias=None))
    response = UserResponseList.model_construct(data=[matching, no_alias])
    monkeypatch.setattr(UserModule, "get_users", lambda rest_client: response)

    assert UserModule.get_users_by_alias(client, "abc") == [matching]


def test_get_users_by_alias_passes_error_through(monkeypatch, client):
    error = object()
    monkeypatch.setattr(UserModule, "get_users", lambda rest_client: error)

    assert UserModule.get_users_by_alias(client, "abc") is error


def test_create_user_builds_request(client):
    request = object()
    with patch.object(UserModule.CreateUser, "create", return_value=request) as create:
        UserModule.create_user(
            client,
            "abc",
            "Ada",
            "Lovelace",
            LundbeckOrganization.lundbeck,
            "Denmark",
        )

    create.assert_called_once_with(
        "abc", "Ada", "Lovelace", LundbeckOrganization.lundbeck, "Denmark"
    )
    client.invoke_rest_post.assert_called_once_with("users", request, UserResponse)


def worksheet_children():
    return EntityDescriptorList.model_construct(
        data=[
            SimpleNamespace(
                attributes=SimpleNamespace(
                    type="worksheet", name="Results", eid="worksheet:1"
                )
            ),
            SimpleNamespace(
                attributes=SimpleNamespace(
                    type="grid", name="Results", eid="grid:1"
                )
            ),
        ]
    )


def test_worksheet_id_handler_filters_type_and_name():
    assert WorksheetModule._get_experiment_worksheet_ids_by_name_handle_response(
        worksheet_children(), "Results"
    ) == ["worksheet:1"]


def test_get_experiment_worksheet_ids_uses_pagination(client):
    client.invoke_rest_get.return_value = worksheet_children()

    result = WorksheetModule.get_experiment_worksheet_ids_by_name(
        client, "experiment:1", "Results"
    )

    assert result == ["worksheet:1"]
    client.invoke_rest_get.assert_called_once_with(
        "entities/experiment:1/children", EntityDescriptorList, True
    )


def worksheet_response():
    definition = SimpleNamespace(
        type="worksheetFieldsDefinition",
        attributes=SimpleNamespace(fieldsDefinition=[SimpleNamespace(
            title="Result", key="field:1", type="text"
        )]),
    )
    return WorksheetResponse.model_construct(included=[definition])


def test_get_worksheet_fields_definition_finds_included_definition(monkeypatch, client):
    monkeypatch.setattr(WorksheetModule, "get_worksheet", lambda *args: worksheet_response())

    result = WorksheetModule.get_worksheet_fields_definition(client, "worksheet:1")

    assert result[0].title == "Result"


def test_update_worksheet_maps_field_names(client):
    fields = [SimpleNamespace(title="Result", key="field:1", type="text")]
    request = object()

    with patch.object(
        WorksheetModule, "get_worksheet_fields_definition", return_value=fields
    ), patch.object(
        WorksheetModule.WorksheetUpdateRequest, "create", return_value=request
    ) as create:
        WorksheetModule.update_worksheet(
            client, "worksheet:1", [("Result", "Positive")]
        )

    create.assert_called_once_with(
        "worksheet:1", [("field:1", "text", "Positive")]
    )
    client.invoke_rest_patch.assert_called_once_with(
        "worksheet/worksheet:1?force=true", request, WorksheetResponse
    )


@pytest.mark.asyncio
async def test_replace_file_attachment_async_updates_existing(async_client):
    content = BytesIO(b"new")
    expected = object()

    with patch.object(
        FileAttachmentModule,
        "get_entity_by_id_async",
        AsyncMock(return_value=parent_response()),
    ), patch.object(
        FileAttachmentModule,
        "get_child_entity_id_by_name_async",
        AsyncMock(return_value="file:1"),
    ), patch.object(
        FileAttachmentModule,
        "update_file_attachment_async",
        AsyncMock(return_value=expected),
    ):
        result = await FileAttachmentModule.replace_file_attachment_async(
            async_client, "experiment:1", "notes.txt", None, content
        )

    assert result is expected
