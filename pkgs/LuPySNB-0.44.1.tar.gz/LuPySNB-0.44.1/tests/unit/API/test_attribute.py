from importlib import import_module
from types import SimpleNamespace

from LuPySNB.model.responses.AttributeDescriptorList import (
    AttributeDescriptorList,
)

AttributeModule = import_module("LuPySNB.API.Attribute")


def test_attribute_response_filters_type_and_name():
    matching = SimpleNamespace(
        attributes=SimpleNamespace(
            type="attribute",
            name="Status",
            eid="attribute:1",
        )
    )
    wrong_type = SimpleNamespace(
        attributes=SimpleNamespace(
            type="other",
            name="Status",
            eid="attribute:2",
        )
    )
    response = AttributeDescriptorList.model_construct(
        data=[matching, wrong_type]
    )

    result = AttributeModule._get_attribute_by_name_handle_response(
        response,
        "Status",
    )

    assert result == [matching.attributes]


def test_attribute_id_returns_first_match(monkeypatch, client):
    monkeypatch.setattr(
        AttributeModule,
        "get_attribute_by_name",
        lambda rest_client, name: [
            SimpleNamespace(eid="attribute:1")
        ],
    )

    result = AttributeModule.get_attribute_id_by_name(client, "Status")

    assert result == "attribute:1"


def test_attribute_id_returns_none_without_match(monkeypatch, client):
    monkeypatch.setattr(
        AttributeModule,
        "get_attribute_by_name",
        lambda rest_client, name: [],
    )

    result = AttributeModule.get_attribute_id_by_name(client, "Missing")

    assert result is None

