from importlib import import_module
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock, patch

import pytest

from LuPySNB.model.exceptions.LuPySNBInternalException import LuPySNBInternalException
from LuPySNB.model.responses.ADTContent import ADTContent
from LuPySNB.model.responses.ADTDescriptor import ADTDescriptor
from LuPySNB.model.responses.ADTRow import ADTRow
from LuPySNB.model.responses.EntityDescriptorList import EntityDescriptorListFromQuery
from LuPySNB.model.responses.ErrorList import ErrorList

ADTModule = import_module("LuPySNB.API.ADT")


def entity(eid="grid:1", name="Grid"):
    return SimpleNamespace(attributes=SimpleNamespace(eid=eid, name=name))


def entity_list(*values):
    return EntityDescriptorListFromQuery.model_construct(data=list(values))


def descriptor(*columns):
    return ADTDescriptor.model_construct(
        data=SimpleNamespace(attributes=SimpleNamespace(columns=list(columns)))
    )


def column(title="Result", key="column:1", field_type="text", method=None):
    return SimpleNamespace(title=title, key=key, type=field_type, method=method)


def test_get_adt_data_calls_expected_endpoint():
    client = Mock()
    expected = object()
    client.invoke_rest_get.return_value = expected

    result = ADTModule.get_adt_data(client, "grid:123")

    assert result is expected
    client.invoke_rest_get.assert_called_once_with("adt/grid:123", ADTContent)


def test_experiment_adt_ids_returns_all_eids():
    result = ADTModule._get_experiment_adt_ids_handle_response(
        entity_list(entity("grid:1"), entity("grid:2"))
    )

    assert result == ["grid:1", "grid:2"]


def test_experiment_adt_ids_returns_none_for_empty_result():
    assert ADTModule._get_experiment_adt_ids_handle_response(entity_list()) is None


def test_experiment_adt_ids_passes_error_through():
    error = ErrorList.model_construct(errors=[])

    assert ADTModule._get_experiment_adt_ids_handle_response(error) is error


def test_experiment_adt_id_by_name_returns_first_eid():
    result = ADTModule._get_experiment_adt_id_by_name_handle_response(
        entity_list(entity("grid:1"), entity("grid:2"))
    )

    assert result == "grid:1"


def test_get_experiment_adt_ids_uses_child_lookup(client):
    response = entity_list(entity("grid:1"))

    with patch.object(ADTModule, "get_child_entities_by_parent_id", return_value=response) as lookup:
        result = ADTModule.get_experiment_adt_ids(client, "experiment:1")

    assert result == ["grid:1"]
    lookup.assert_called_once_with(client, "experiment:1", "grid")


def test_get_experiment_adt_id_by_name_uses_name_filter(client):
    response = entity_list(entity("grid:1"))

    with patch.object(ADTModule, "get_child_entities_by_parent_id", return_value=response) as lookup:
        result = ADTModule.get_experiment_adt_id_by_name(client, "experiment:1", "Results")

    assert result == "grid:1"
    lookup.assert_called_once_with(client, "experiment:1", "grid", "Results")


def test_insert_adt_row_without_digest_forces_update(client):
    request = object()
    expected = object()
    client.invoke_rest_post.return_value = expected

    with patch.object(ADTModule.ADTAddRowRequest, "create", return_value=request) as create:
        result = ADTModule.insert_adt_row_by_col_ids(
            client, "grid:1", [("column:1", "text", "A")], sync_data=True
        )

    assert result is expected
    create.assert_called_once_with([("column:1", "text", "A")])
    client.invoke_rest_post.assert_called_once_with(
        "adt/grid:1?force=true&syncData=true", request, ADTRow
    )


def test_insert_adt_row_with_digest_disables_force(client):
    request = object()

    with patch.object(ADTModule.ADTAddRowRequest, "create", return_value=request):
        ADTModule.insert_adt_row_by_col_ids(
            client,
            "grid:1",
            [("column:1", "text", "A")],
            digest="digest-1",
        )

    client.invoke_rest_post.assert_called_once_with(
        "adt/grid:1?force=false&digest=digest-1&syncData=false",
        request,
        ADTRow,
    )


@pytest.mark.asyncio
async def test_insert_adt_row_async_posts_request(async_client):
    request = object()
    expected = object()
    async_client.invoke_rest_post_async.return_value = expected

    with patch.object(ADTModule.ADTAddRowRequest, "create", return_value=request):
        result = await ADTModule.insert_adt_row_by_col_ids_async(
            async_client, "grid:1", [("column:1", "text", "A")]
        )

    assert result is expected
    async_client.invoke_rest_post_async.assert_awaited_once_with(
        "adt/grid:1?force=true&syncData=false", request, ADTRow
    )


def test_insert_bulk_rows_maps_column_names(client):
    adt_descriptor = descriptor(column("Result", "column:1", "text"))
    request = object()
    expected = object()
    client.invoke_rest_patch.return_value = expected

    with patch.object(ADTModule, "get_experiment_adt_cols", return_value=adt_descriptor), patch.object(
        ADTModule.ADTBulkAddRowRequest, "create", return_value=request
    ) as create:
        result = ADTModule.insert_bulk_adt_rows_by_col_name(
            client, "grid:1", [[("Result", "A")], [("Result", "B")]]
        )

    assert result is expected
    create.assert_called_once_with(
        [[("column:1", "text", "A")], [("column:1", "text", "B")]]
    )
    client.invoke_rest_patch.assert_called_once_with(
        "adt/grid:1?force=true&syncData=false", request, ADTContent
    )


def test_insert_bulk_rows_returns_descriptor_error_in_list(client):
    error = ErrorList.model_construct(errors=[])

    with patch.object(ADTModule, "get_experiment_adt_cols", return_value=error):
        assert ADTModule.insert_bulk_adt_rows_by_col_name(client, "grid:1", []) == [error]


def test_insert_bulk_rows_rejects_unknown_columns(client):
    with patch.object(ADTModule, "get_experiment_adt_cols", return_value=descriptor(column())):
        with pytest.raises(LuPySNBInternalException, match="Non-recognized ADT column"):
            ADTModule.insert_bulk_adt_rows_by_col_name(
                client, "grid:1", [[("Missing", "A")]]
            )


def test_update_bulk_rows_maps_row_ids_and_columns(client):
    request = object()

    with patch.object(ADTModule, "get_experiment_adt_cols", return_value=descriptor(column())), patch.object(
        ADTModule.ADTBulkUpdateRowRequest, "create", return_value=request
    ) as create:
        ADTModule.update_bulk_adt_rows_by_col_name(
            client,
            "grid:1",
            [("row:1", [("Result", "A")])],
            digest="digest-1",
        )

    create.assert_called_once_with([("row:1", [("column:1", "text", "A")])])
    client.invoke_rest_patch.assert_called_once_with(
        "adt/grid:1?force=false&digest=digest-1&syncData=false",
        request,
        ADTContent,
    )


def test_insert_rows_by_name_splits_header_and_regular_cells(client):
    columns = descriptor(
        column("Header", "column:header", "text", "header"),
        column("Result", "column:result", "text", None),
    )
    first = object()
    second = object()

    with patch.object(ADTModule, "get_experiment_adt_cols", return_value=columns), patch.object(
        ADTModule, "insert_adt_row_by_col_ids", side_effect=[first, second]
    ) as insert:
        result = ADTModule.insert_adt_rows_by_col_name(
            client, "grid:1", [[("Header", "H"), ("Result", "R")]]
        )

    assert result == [first, second]
    assert insert.call_args_list[0].args[2] == [("column:header", "text", "H")]
    assert insert.call_args_list[1].args[2] == [("column:result", "text", "R")]


def test_delete_adt_row_without_digest_uses_force():
    client = Mock()

    ADTModule.delete_adt_row_by_id(client, "grid:123", "row:456")

    client.invoke_rest_delete.assert_called_once_with(
        "adt/grid:123/row:456?force=true"
    )


def test_delete_adt_row_with_digest_disables_force():
    client = Mock()

    ADTModule.delete_adt_row_by_id(client, "grid:123", "row:456", digest="abc")

    client.invoke_rest_delete.assert_called_once_with(
        "adt/grid:123/row:456?force=false&digest=abc"
    )


@pytest.mark.asyncio
async def test_delete_adt_row_async_with_digest(async_client):
    await ADTModule.delete_adt_row_by_id_async(
        async_client, "grid:1", "row:1", digest="digest-1"
    )

    async_client.invoke_rest_delete_async.assert_awaited_once_with(
        "adt/grid:1/row:1?force=false&digest=digest-1"
    )


def test_adt_entry_query_includes_parent_filter():
    query = ADTModule._get_adt_containing_entry_by_template_build_query(
        "Template", "Sample ID", "S-1", "text", "experiment:1"
    )
    dumped = query.model_dump(by_alias=True, exclude_none=True)

    assert len(dumped["query"]["$and"]) == 3
    assert dumped["query"]["$and"][0]["$match"]["field"] == "grid.Sample ID"
    assert "$parent" in dumped["query"]["$and"][2]


def test_find_adt_containing_entry_posts_query(client):
    expected = object()
    client.invoke_rest_post.return_value = expected

    result = ADTModule.get_adt_containing_adt_entry_by_template(
        client, "Template", "Sample ID", "S-1", "text"
    )

    assert result is expected
    endpoint, query, response_type, paginated = client.invoke_rest_post.call_args.args
    assert endpoint == "entities/search?source=SN"
    assert query.query.andList[0].match.field == "grid.Sample ID"
    assert response_type is EntityDescriptorListFromQuery
    assert paginated is True


def test_experiment_containing_entry_collects_parent_names(client):
    tables = entity_list(entity("grid:1"), entity("grid:2"))
    parents_1 = entity_list(entity("experiment:1", "Exp 1"))
    parents_2 = entity_list(entity("experiment:2", "Exp 2"))

    with patch.object(
        ADTModule, "get_adt_containing_adt_entry_by_template", return_value=tables
    ), patch.object(
        ADTModule,
        "get_parent_entities_by_child_id",
        side_effect=[parents_1, parents_2],
    ):
        result = ADTModule.get_experiment_containing_adt_entry(
            client, "Template", "Sample ID", "S-1", "text"
        )

    assert result == [
        ("experiment:1", "Exp 1"),
        ("experiment:2", "Exp 2"),
    ]


@pytest.mark.asyncio
async def test_experiment_containing_entry_async_skips_error_parents(async_client):
    tables = entity_list(entity("grid:1"), entity("grid:2"))
    parents = entity_list(entity("experiment:1", "Exp 1"))
    error = ErrorList.model_construct(errors=[])

    with patch.object(
        ADTModule,
        "get_adt_containing_adt_entry_by_template_async",
        AsyncMock(return_value=tables),
    ), patch.object(
        ADTModule,
        "get_parent_entities_by_child_id_async",
        AsyncMock(side_effect=[parents, error]),
    ):
        result = await ADTModule.get_experiment_containing_adt_entry_async(
            async_client, "Template", "Sample ID", "S-1", "text"
        )

    assert result == [("experiment:1", "Exp 1")]

