from importlib import import_module
from unittest.mock import patch

import pytest

from LuPySNB.model.exceptions.LuPySNBInternalException import (
    LuPySNBInternalException,
)
from LuPySNB.model.responses.CreateADOResponse import CreateADOResponse
from LuPySNB.model.responses.CreateExperimentResponse import (
    CreateExperimentResponse,
)

ExperimentModule = import_module("LuPySNB.API.Experiment")

def test_create_ado_posts_created_request(client):
    request = object()
    expected = object()
    client.invoke_rest_post.return_value = expected

    with patch.object(
        ExperimentModule.CreateADORequest,
        "create",
        return_value=request,
    ):
        result = ExperimentModule.create_ado(
            client,
            "ADO Type",
            "ado:template",
            {"Name": "A"},
        )

    assert result is expected
    client.invoke_rest_post.assert_called_once_with(
        "entities/?force=true",
        request,
        CreateADOResponse,
    )


def test_create_experiment_resolves_template_and_notebook(
    monkeypatch,
    client,
):
    monkeypatch.setattr(
        ExperimentModule,
        "get_experiment_id_by_name",
        lambda *args: "experiment:template",
    )
    monkeypatch.setattr(
        ExperimentModule,
        "get_notebook_id_by_name",
        lambda *args: "journal:1",
    )
    request = object()
    expected = object()
    client.invoke_rest_post.return_value = expected

    with patch.object(
        ExperimentModule.CreateExperimentRequest,
        "create",
        return_value=request,
    ) as create:
        result = ExperimentModule.create_experiment(
            client,
            {"Name": "Exp"},
            "Template",
            "Notebook",
        )

    assert result is expected
    create.assert_called_once_with(
        "experiment:template",
        "journal:1",
        {"Name": "Exp"},
    )
    client.invoke_rest_post.assert_called_once_with(
        "entities/?force=true",
        request,
        CreateExperimentResponse,
    )


def test_create_experiment_rejects_missing_template(
    monkeypatch,
    client,
):
    monkeypatch.setattr(
        ExperimentModule,
        "get_experiment_id_by_name",
        lambda *args: None,
    )

    with pytest.raises(
        LuPySNBInternalException,
        match="Template Missing does not exist",
    ):
        ExperimentModule.create_experiment(
            client,
            {},
            "Missing",
            None,
        )


def test_create_experiment_rejects_missing_notebook(
    monkeypatch,
    client,
):
    monkeypatch.setattr(
        ExperimentModule,
        "get_experiment_id_by_name",
        lambda *args: "template:1",
    )
    monkeypatch.setattr(
        ExperimentModule,
        "get_notebook_id_by_name",
        lambda *args: None,
    )

    with pytest.raises(
        LuPySNBInternalException,
        match="Notebook Missing does not exist",
    ):
        ExperimentModule.create_experiment(
            client,
            {},
            "Template",
            "Missing",
        )


def test_experiment_lookup_delegates_to_entity(client):
    with patch.object(
        ExperimentModule,
        "get_entity_id_by_name",
        return_value="id:1",
    ) as lookup:
        result = ExperimentModule.get_experiment_id_by_name(
            client,
            "Exp",
            True,
        )

    assert result == "id:1"
    lookup.assert_called_once_with(
        client,
        "Exp",
        "experiment",
        True,
    )

