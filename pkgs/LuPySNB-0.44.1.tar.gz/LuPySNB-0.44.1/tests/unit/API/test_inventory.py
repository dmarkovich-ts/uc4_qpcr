from importlib import import_module
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import pytest

from LuPySNB.model.exceptions.LuPySNBException import LuPySNBException
from LuPySNB.model.responses.EntityDescriptorList import EntityDescriptorListFromQuery
from LuPySNB.model.responses.InventoryLocationResponse import InventoryLocationResponse
from LuPySNB.model.responses.InventoryTypeResponse import InventoryTypeResponseList

InventoryModule = import_module("LuPySNB.API.Inventory")


def make_inventory_type(name):
    return SimpleNamespace(attributes=SimpleNamespace(name=name))


def make_inventory_types(*items):
    return InventoryTypeResponseList.model_construct(data=list(items))


def make_entity_query_response(*ids):
    return EntityDescriptorListFromQuery.model_construct(
        data=[SimpleNamespace(id=value) for value in ids]
    )


def test_inventory_types_by_name_filters_matches(monkeypatch, client):
    vial = make_inventory_type("Vial")
    tube = make_inventory_type("Tube")
    monkeypatch.setattr(InventoryModule, "get_inventory_types", lambda *args: make_inventory_types(vial, tube))

    assert InventoryModule.get_inventory_types_by_name(client, "container", "Vial") == [vial]


def test_inventory_types_by_name_passes_errors_through(monkeypatch, client):
    error = object()
    monkeypatch.setattr(InventoryModule, "get_inventory_types", lambda *args: error)

    assert InventoryModule.get_inventory_types_by_name(client, "container", "Vial") is error


def test_create_inventory_location_builds_request(client):
    request = object()
    expected = object()
    client.invoke_rest_post.return_value = expected
    fields = {"Status": "ACTIVE"}
    field_map = {"Status": object()}

    with patch.object(InventoryModule.CreateInventoryLocationRequest, "create", return_value=request) as create:
        result = InventoryModule.create_inventory_location(
            client,
            "Shelf",
            "ABC",
            4,
            6,
            "location:parent",
            "locationType:1",
            fields,
            field_map,
        )

    assert result is expected
    create.assert_called_once_with(
        "location:parent", "Shelf", "ABC", 4, 6, "locationType:1", fields, field_map
    )
    client.invoke_rest_post.assert_called_once_with(
        "inventory/locations", request, InventoryLocationResponse
    )


def test_update_inventory_location_builds_request(client):
    request = object()
    expected = object()
    client.invoke_rest_patch.return_value = expected
    values = [("Status", "ACTIVE")]
    fields = {"Status": object()}

    with patch.object(InventoryModule.UpdateInventoryLocationRequest, "create", return_value=request) as create:
        result = InventoryModule.update_inventory_location(
            client, "location:1", "digest-1", values, fields
        )

    assert result is expected
    create.assert_called_once_with(values, fields)
    client.invoke_rest_patch.assert_called_once_with(
        "inventory/locations/location:1?digest=digest-1&force=false",
        request,
        InventoryLocationResponse,
    )


def test_location_path_query_splits_parent_path_and_name():
    query = InventoryModule._get_inventory_location_by_path_build_query("/Room/Shelf", "Box")

    assert query.query.andList[1].match.value == "/Room/Shelf"
    assert query.query.andList[2].match.value == "Box"


def test_get_inventory_location_by_path_requires_leading_slash(client):
    with pytest.raises(LuPySNBException, match="must start with a leading slash"):
        InventoryModule.get_inventory_location_by_path(client, "Room/Shelf")


def test_get_inventory_location_by_path_fetches_unique_result(monkeypatch, client):
    client.invoke_rest_post.return_value = make_entity_query_response("location:1")
    expected = object()
    monkeypatch.setattr(InventoryModule, "get_inventory_location_by_eid", lambda *args: expected)

    result = InventoryModule.get_inventory_location_by_path(client, "/Room/Shelf")

    assert result is expected
    query = client.invoke_rest_post.call_args.args[1]
    assert query.query.andList[1].match.value == "/Room"
    assert query.query.andList[2].match.value == "Shelf"


def test_get_inventory_location_by_path_rejects_missing_result(client):
    client.invoke_rest_post.return_value = make_entity_query_response()

    with pytest.raises(LuPySNBException, match="not found"):
        InventoryModule.get_inventory_location_by_path(client, "/Room/Shelf")


def test_get_inventory_location_by_path_rejects_multiple_results(client):
    client.invoke_rest_post.return_value = make_entity_query_response("location:1", "location:2")

    with pytest.raises(LuPySNBException, match="Multiple locations"):
        InventoryModule.get_inventory_location_by_path(client, "/Room/Shelf")


def test_location_children_query_uses_path_and_type():
    query = InventoryModule._get_inventory_location_children_by_path_query(
        "/Room/Shelf", "container"
    )

    assert query.query.andList[0].match.value == "container"
    assert query.query.andList[1].match.value == "/Room/Shelf"


def test_get_location_path_reverses_ancestors():
    response = InventoryLocationResponse.model_construct(
        data=SimpleNamespace(
            attributes=SimpleNamespace(
                ancestors=[{"name": "Shelf"}, {"name": "Room"}], name="Box"
            )
        )
    )

    assert InventoryModule.get_location_path_from_location_response(response) == "/Room/Shelf/Box"


def test_get_location_path_handles_no_ancestors():
    response = InventoryLocationResponse.model_construct(
        data=SimpleNamespace(attributes=SimpleNamespace(ancestors=[], name="Room"))
    )

    assert InventoryModule.get_location_path_from_location_response(response) == "/Room"


def test_location_barcode_query_uses_barcode():
    query = InventoryModule._get_inventory_location_by_barcode_query("ABC")

    assert query.query.andList[1].match.value == "ABC"


def test_order_query_uses_container_name():
    query = InventoryModule._get_order_by_container_name_query("Container 1")

    assert query.query.andList[0].match.value == "Container 1"
    assert query.query.andList[1].match.value == "order"


@pytest.mark.asyncio
async def test_get_inventory_location_by_path_async_fetches_unique_result(
    monkeypatch,
    async_client,
):
    async_client.invoke_rest_post_async.return_value = (
        make_entity_query_response("location:1")
    )
    expected = object()
    get_by_id = AsyncMock(return_value=expected)

    monkeypatch.setattr(
        InventoryModule,
        "get_inventory_location_by_eid_async",
        get_by_id,
    )

    result = await InventoryModule.get_inventory_location_by_path_async(
        async_client,
        "/Room/Shelf",
    )

    assert result is expected
    get_by_id.assert_awaited_once_with(async_client, "location:1")
