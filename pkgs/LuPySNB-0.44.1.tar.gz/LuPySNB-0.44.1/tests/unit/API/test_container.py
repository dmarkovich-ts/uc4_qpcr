from importlib import import_module
from types import SimpleNamespace
from unittest.mock import patch, AsyncMock

import pytest

from LuPySNB.model.exceptions.LuPySNBException import LuPySNBException
from LuPySNB.model.responses.ContainerResponse import ContainerResponse
from LuPySNB.model.responses.ContainerTypeResponse import ContainerTypeResponseList
from LuPySNB.model.responses.CreateContainerResponse import CreateContainerResponse
from LuPySNB.model.responses.EntityDescriptorList import EntityDescriptorListFromQuery

ContainerModule = import_module("LuPySNB.API.Container")


def container_type(type_id="type:1", name="Vial", field_map=None):
    return SimpleNamespace(
        id=type_id,
        attributes=SimpleNamespace(name=name),
        get_field_map=lambda: field_map or {"Status": object()},
    )


def type_list(*values):
    return ContainerTypeResponseList.model_construct(data=list(values))


def test_containers_by_type_query_contains_type_and_container_type():
    query = ContainerModule._get_containers_by_type_build_query("Vial")
    dumped = query.model_dump(by_alias=True, exclude_none=True)

    assert dumped["query"]["$and"][0]["$in"]["values"] == ["container"]
    assert dumped["query"]["$and"][1]["$match"]["value"] == "Vial"


def test_containers_by_name_query_contains_all_names():
    query = ContainerModule._get_containers_by_name_build_query(["C-1", "C-2"])

    assert query.query.andList[1].match.values == ["C-1", "C-2"]


def test_status_and_days_query_contains_library_status_and_range():
    query = ContainerModule._get_containers_by_status_and_days_since_edited_build_query(
        "assetType:1", "AVAILABLE", 7
    )
    dumped = query.model_dump(by_alias=True, exclude_none=True)

    assert dumped["query"]["$and"][1]["$child"]["$in"]["values"] == ["assetType:1"]
    assert dumped["query"]["$and"][2]["$match"]["value"] == "AVAILABLE"
    assert dumped["query"]["$and"][3]["$range"]["from"] == "now-7d/d"


def test_get_containers_by_type_posts_query(client):
    expected = object()
    client.invoke_rest_post.return_value = expected

    result = ContainerModule.get_containers_by_type(client, "Vial")

    assert result is expected
    endpoint, query, response_type, paginated = client.invoke_rest_post.call_args.args
    assert endpoint == "entities/search?source=IVT"
    assert query.query.andList[1].match.value == "Vial"
    assert response_type is EntityDescriptorListFromQuery
    assert paginated is True


def test_get_containers_by_name_posts_query(client):
    expected = object()
    client.invoke_rest_post.return_value = expected

    result = ContainerModule.get_containers_by_name(client, ["C-1", "C-2"])

    assert result is expected
    query = client.invoke_rest_post.call_args.args[1]
    assert query.query.andList[1].match.values == ["C-1", "C-2"]


@pytest.mark.asyncio
async def test_get_containers_by_type_async_posts_query(async_client):
    await ContainerModule.get_containers_by_type_async(async_client, "Vial")

    query = async_client.invoke_rest_post_async.call_args.args[1]
    assert query.query.andList[1].match.value == "Vial"


@pytest.mark.asyncio
async def test_get_containers_by_name_async_posts_query(async_client):
    await ContainerModule.get_containers_by_name_async(async_client, ["C-1"])

    query = async_client.invoke_rest_post_async.call_args.args[1]
    assert query.query.andList[1].match.values == ["C-1"]


@pytest.mark.asyncio
async def test_get_containers_by_status_async_resolves_library(monkeypatch, async_client):
    monkeypatch.setattr(
        ContainerModule.MaterialLibrary,
        "get_material_library_by_name_async",
        AsyncMock(return_value=SimpleNamespace(id="library:1")),
    )

    await ContainerModule.get_containers_by_status_and_days_since_edited_async(
        async_client, "Reagents", "AVAILABLE", 3
    )

    query = async_client.invoke_rest_post_async.call_args.args[1]
    assert query.query.andList[1].child.match.values == ["assetType:library:1"]


def test_get_containers_by_status_resolves_library(monkeypatch, client):
    monkeypatch.setattr(
        ContainerModule.MaterialLibrary,
        "get_material_library_by_name",
        lambda rest_client, name: SimpleNamespace(id="library:1"),
    )

    ContainerModule.get_containers_by_status_and_days_since_edited(
        client, "Reagents", "AVAILABLE", 3
    )

    query = client.invoke_rest_post.call_args.args[1]
    assert query.query.andList[1].child.match.values == ["assetType:library:1"]


def test_get_container_type_by_name_returns_match(monkeypatch, client):
    expected = container_type(name="Vial")
    monkeypatch.setattr(ContainerModule, "get_container_types", lambda rest_client: type_list(expected))

    assert ContainerModule.get_container_type_by_name(client, "Vial") is expected


def test_get_container_type_by_name_raises_for_missing_type(monkeypatch, client):
    monkeypatch.setattr(ContainerModule, "get_container_types", lambda rest_client: type_list())

    with pytest.raises(LuPySNBException, match="Container type with name Tube not found"):
        ContainerModule.get_container_type_by_name(client, "Tube")


@pytest.mark.asyncio
async def test_get_container_type_by_name_async_returns_match(monkeypatch, async_client):
    expected = container_type(name="Vial")
    monkeypatch.setattr(ContainerModule, "get_container_types_async", AsyncMock(return_value=type_list(expected)))

    assert await ContainerModule.get_container_type_by_name_async(async_client, "Vial") is expected


@pytest.mark.asyncio
async def test_get_container_type_by_name_async_raises_for_missing(monkeypatch, async_client):
    monkeypatch.setattr(ContainerModule, "get_container_types_async", AsyncMock(return_value=type_list()))

    with pytest.raises(LuPySNBException, match="Container type with name Tube not found"):
        await ContainerModule.get_container_type_by_name_async(async_client, "Tube")


def test_get_container_type_by_id_returns_match(monkeypatch, client):
    expected = container_type(type_id="type:1")
    monkeypatch.setattr(ContainerModule, "get_container_types", lambda rest_client: type_list(expected))

    assert ContainerModule.get_container_type_by_id(client, "type:1") is expected


@pytest.mark.asyncio
async def test_get_container_type_by_id_async_returns_match(monkeypatch, async_client):
    expected = container_type(type_id="type:1")
    monkeypatch.setattr(ContainerModule, "get_container_types_async", AsyncMock(return_value=type_list(expected)))

    assert await ContainerModule.get_container_type_by_id_async(async_client, "type:1") is expected


def test_get_container_type_field_map_delegates_to_type(monkeypatch, client):
    expected_map = {"Status": object()}
    expected_type = container_type(field_map=expected_map)
    monkeypatch.setattr(ContainerModule, "get_container_type_by_name", lambda *args: expected_type)

    assert ContainerModule.get_container_type_field_map(client, "Vial") == expected_map


@pytest.mark.asyncio
async def test_get_container_type_field_map_async_delegates_to_type(monkeypatch, async_client):
    expected_map = {"Status": object()}
    expected_type = container_type(field_map=expected_map)
    monkeypatch.setattr(ContainerModule, "get_container_type_by_name_async", AsyncMock(return_value=expected_type))

    assert await ContainerModule.get_container_type_field_map_async(async_client, "Vial") == expected_map


@pytest.mark.asyncio
async def test_get_container_type_field_map_by_id_async_delegates(monkeypatch, async_client):
    expected_map = {"Status": object()}
    expected_type = container_type(field_map=expected_map)
    monkeypatch.setattr(ContainerModule, "get_container_type_by_id_async", AsyncMock(return_value=expected_type))

    assert await ContainerModule.get_container_type_field_map_by_id_async(async_client, "type:1") == expected_map


def test_update_container_reads_type_and_builds_request(client):
    response = ContainerResponse.model_construct(
        data=SimpleNamespace(attributes=SimpleNamespace(typeId="type:1"))
    )
    request = object()
    expected = object()
    client.invoke_rest_patch.return_value = expected

    with patch.object(ContainerModule, "get_container", return_value=response), patch.object(
        ContainerModule, "get_container_type_field_map_by_id", return_value={"Status": object()}
    ), patch.object(ContainerModule.ContainerUpdateRequest, "create", return_value=request) as create:
        result = ContainerModule.update_container(
            client, "container:1", "digest-1", [("Status", "AVAILABLE")]
        )

    assert result is expected
    create.assert_called_once_with([("Status", "AVAILABLE")], {"Status": create.call_args.args[1]["Status"]})
    client.invoke_rest_patch.assert_called_once_with(
        "/inventory/containers/container:1?digest=digest-1&force=false",
        request,
        ContainerResponse,
    )


@pytest.mark.asyncio
async def test_update_container_async_reads_type_and_builds_request(async_client):
    response = ContainerResponse.model_construct(
        data=SimpleNamespace(attributes=SimpleNamespace(typeId="type:1"))
    )
    request = object()
    expected = object()
    async_client.invoke_rest_get_async.return_value = response
    async_client.invoke_rest_patch_async.return_value = expected

    with patch.object(
        ContainerModule, "get_container_type_field_map_by_id_async",
        new=AsyncMock(return_value={"Status": object()})
    ), patch.object(ContainerModule.ContainerUpdateRequest, "create", return_value=request):
        result = await ContainerModule.update_container_async(
            async_client, "container:1", "digest-1", [("Status", "AVAILABLE")]
        )

    assert result is expected
    async_client.invoke_rest_patch_async.assert_awaited_once_with(
        "/inventory/containers/container:1?digest=digest-1&force=false",
        request,
        ContainerResponse,
    )


def test_create_container_builds_request(client):
    request = object()
    expected = object()
    client.invoke_rest_post.return_value = expected
    values = [("Status", "AVAILABLE")]
    fields = {"Status": object()}

    with patch.object(ContainerModule.CreateContainerRequest, "create", return_value=request) as create:
        result = ContainerModule.create_container(
            client,
            "type:1",
            2.0,
            "location:1",
            "ABC",
            "asset:1",
            values,
            fields,
            1,
            2,
            "mg",
        )

    assert result is expected
    create.assert_called_once_with(
        "type:1", 2.0, "location:1", 1, 2, "ABC", "asset:1", values, fields, "mg"
    )
    client.invoke_rest_post.assert_called_once_with(
        "/inventory/containers", request, CreateContainerResponse
    )


@pytest.mark.asyncio
async def test_create_container_async_builds_request(async_client):
    request = object()
    expected = object()
    async_client.invoke_rest_post_async.return_value = expected
    values = [("Status", "AVAILABLE")]
    fields = {"Status": object()}

    with patch.object(ContainerModule.CreateContainerRequest, "create", return_value=request):
        result = await ContainerModule.create_container_async(
            async_client, "type:1", 2.0, "location:1", "ABC", "asset:1", values, fields, 1, 2, "mg"
        )

    assert result is expected
    async_client.invoke_rest_post_async.assert_awaited_once_with(
        "/inventory/containers", request, CreateContainerResponse
    )


def test_get_value_for_field_returns_matching_content():
    container = SimpleNamespace(
        data=SimpleNamespace(
            attributes=SimpleNamespace(
                fields=[
                    SimpleNamespace(
                        definition=SimpleNamespace(title="Status"),
                        content=SimpleNamespace(value="AVAILABLE"),
                    )
                ]
            )
        )
    )

    assert ContainerModule.get_value_for_field(container, "Status") == "AVAILABLE"
    assert ContainerModule.get_value_for_field(container, "Missing") is None


@pytest.mark.parametrize(
    "digest,expected_endpoint",
    [
        (None, "/inventory/containers/container:1/amount?force=true"),
        ("digest-1", "/inventory/containers/container:1/amount?digest=digest-1&force=false"),
    ],
)
def test_update_amount_builds_endpoint(digest, expected_endpoint, client):
    request = object()

    with patch.object(ContainerModule.ContainerAmountUpdateRequest, "create", return_value=request) as create:
        ContainerModule.update_amount(client, "container:1", digest, 2.5, "mg")

    create.assert_called_once_with("2.5 mg")
    client.invoke_rest_patch.assert_called_once_with(
        expected_endpoint, request, ContainerResponse
    )


@pytest.mark.asyncio
async def test_update_amount_async_calls_patch(async_client):
    request = object()
    with patch.object(ContainerModule.ContainerAmountUpdateRequest, "create", return_value=request):
        await ContainerModule.update_amount_async(async_client, "container:1", None, 1.0)

    async_client.invoke_rest_patch_async.assert_awaited_once_with(
        "/inventory/containers/container:1/amount?force=true", request, ContainerResponse
    )


@pytest.mark.parametrize("action", ["dispose", "finalDispose", "restore"])
def test_status_actions_without_body(action, client):
    ContainerModule.update_container_status(client, "container:1", action, True)

    client.invoke_rest_post.assert_called_once_with(
        f"/inventory/containers/container:1/status/{action}?force=true",
        None,
        ContainerResponse,
    )


def test_move_status_builds_body_and_digest_endpoint(client):
    request = object()

    with patch.object(ContainerModule.ContainerStatusUpdateRequest, "create", return_value=request) as create:
        ContainerModule.update_container_status(
            client,
            "container:1",
            "move",
            False,
            digest="digest-1",
            location_eid="location:1",
            user_id=None,
            coordinate_x=2,
            coordinate_y=3,
        )

    create.assert_called_once_with("location:1", 2, 3, "")
    client.invoke_rest_post.assert_called_once_with(
        "/inventory/containers/container:1/status/move?digest=digest-1&force=false",
        request,
        ContainerResponse,
    )


@pytest.mark.asyncio
async def test_update_container_status_async_dispose(async_client):
    await ContainerModule.update_container_status_async(
        async_client, "container:1", "dispose", True
    )

    async_client.invoke_rest_post_async.assert_awaited_once_with(
        "/inventory/containers/container:1/status/dispose?force=true",
        None,
        ContainerResponse,
    )


@pytest.mark.asyncio
async def test_update_container_status_async_move(async_client):
    request = object()
    with patch.object(ContainerModule.ContainerStatusUpdateRequest, "create", return_value=request):
        await ContainerModule.update_container_status_async(
            async_client, "container:1", "move", False,
            digest="digest-1", location_eid="location:1", user_id="user:1",
            coordinate_x=2, coordinate_y=3,
        )

    async_client.invoke_rest_post_async.assert_awaited_once_with(
        "/inventory/containers/container:1/status/move?digest=digest-1&force=false",
        request,
        ContainerResponse,
    )


def test_disposed_containers_query_excludes_bin_path():
    query = ContainerModule._get_disposed_containers_outside_bin_build_query("/Disposed")
    dumped = query.model_dump(by_alias=True, exclude_none=True)

    assert "$not" in dumped["query"]["$and"][1]
    assert dumped["query"]["$and"][3]["$match"]["value"] == "DISPOSED"


def test_container_barcode_query_uses_barcode():
    query = ContainerModule._get_container_by_barcode_query("ABC")

    assert query.query.andList[1].match.value == "ABC"


def test_path_status_created_query_uses_older_than_date():
    query = ContainerModule._get_containers_by_path_status_and_days_since_created_query(
        30, "/Room/Shelf", "library:1", "AVAILABLE"
    )

    assert query.query.andList[4].range.to_value == "now-31d/d"


def test_prefix_path_query_omits_prefix_when_none():
    query = ContainerModule._get_containers_by_prefix_path_and_status_query(
        "library:1", None, ["AVAILABLE"]
    )

    assert len(query.query.andList) == 3


def test_prefix_path_query_includes_prefix():
    query = ContainerModule._get_containers_by_prefix_path_and_status_query(
        "library:1", "/Room", ["AVAILABLE"]
    )

    assert query.query.andList[2].prefix.value == "/Room"


def test_content_and_status_query_maps_lists():
    query = ContainerModule._get_containers_by_content_and_status_query(
        "library:1", ["Water"], ["AVAILABLE", "RESERVED"]
    )

    assert query.query.andList[2].match.values == ["Water"]
    assert query.query.andList[3].match.values == ["AVAILABLE", "RESERVED"]


def test_get_disposed_containers_outside_bin_posts_query(client):
    expected = object()
    client.invoke_rest_post.return_value = expected

    result = ContainerModule.get_disposed_containers_outside_bin(client, "/Disposed")

    assert result is expected
    client.invoke_rest_post.assert_called_once()


@pytest.mark.asyncio
async def test_get_disposed_containers_outside_bin_async_posts_query(async_client):
    await ContainerModule.get_disposed_containers_outside_bin_async(async_client, "/Disposed")

    async_client.invoke_rest_post_async.assert_awaited_once()


def test_get_container_by_barcode_posts_query(client):
    expected = object()
    client.invoke_rest_post.return_value = expected

    result = ContainerModule.get_container_by_barcode(client, "ABC")

    assert result is expected
    query = client.invoke_rest_post.call_args.args[1]
    assert query.query.andList[1].match.value == "ABC"


@pytest.mark.asyncio
async def test_get_container_by_barcode_async_posts_query(async_client):
    await ContainerModule.get_container_by_barcode_async(async_client, "ABC")

    query = async_client.invoke_rest_post_async.call_args.args[1]
    assert query.query.andList[1].match.value == "ABC"


def test_get_containers_by_path_status_created_posts_query(monkeypatch, client):
    monkeypatch.setattr(
        ContainerModule.MaterialLibrary,
        "get_material_library_by_name",
        lambda rest_client, name: SimpleNamespace(id="library:1"),
    )
    expected = object()
    client.invoke_rest_post.return_value = expected

    result = ContainerModule.get_containers_by_path_status_and_days_since_created(
        client, "Reagents", "/Room/Shelf", "AVAILABLE", 30
    )

    assert result is expected


@pytest.mark.asyncio
async def test_get_containers_by_path_status_created_async_posts_query(monkeypatch, async_client):
    monkeypatch.setattr(
        ContainerModule.MaterialLibrary,
        "get_material_library_by_name_async",
        AsyncMock(return_value=SimpleNamespace(id="library:1")),
    )

    await ContainerModule.get_containers_by_path_status_and_days_since_created_async(
        async_client, "Reagents", "/Room/Shelf", "AVAILABLE", 30
    )

    async_client.invoke_rest_post_async.assert_awaited_once()


def test_get_containers_by_prefix_path_and_status_posts_query(client):
    expected = object()
    client.invoke_rest_post.return_value = expected

    result = ContainerModule.get_containers_by_prefix_path_and_status(
        client, "library:1", "/Room", ["AVAILABLE"]
    )

    assert result is expected


@pytest.mark.asyncio
async def test_get_containers_by_prefix_path_and_status_async_posts_query(async_client):
    await ContainerModule.get_containers_by_prefix_path_and_status_async(
        async_client, "library:1", "/Room", ["AVAILABLE"]
    )

    async_client.invoke_rest_post_async.assert_awaited_once()


def test_get_containers_by_content_and_status_posts_query(client):
    expected = object()
    client.invoke_rest_post.return_value = expected

    result = ContainerModule.get_containers_by_content_and_status(
        client, "library:1", ["Water"], ["AVAILABLE"]
    )

    assert result is expected


@pytest.mark.asyncio
async def test_get_containers_by_content_and_status_async_posts_query(async_client):
    await ContainerModule.get_containers_by_content_and_status_async(
        async_client, "library:1", ["Water"], ["AVAILABLE"]
    )

    async_client.invoke_rest_post_async.assert_awaited_once()