from importlib import import_module
from io import BytesIO

import pytest

from LuPySNB.model.responses.ADTContent import ADTContent
from LuPySNB.model.responses.ADTDescriptor import ADTDescriptor
from LuPySNB.model.responses.Attachment import Attachment
from LuPySNB.model.responses.AttributeDetailDescriptor import AttributeDetailDescriptor
from LuPySNB.model.responses.ContainerResponse import ContainerResponse
from LuPySNB.model.responses.ContainerTypeResponse import ContainerTypeResponseList
from LuPySNB.model.responses.GetEntityResponse import GetEntityResponse
from LuPySNB.model.responses.InventoryLocationResponse import InventoryLocationResponse
from LuPySNB.model.responses.InventoryTypeResponse import InventoryTypeResponseList
from LuPySNB.model.responses.Layout import PageList
from LuPySNB.model.responses.MaterialAssetResponse import (
    MaterialAssetResponse,
    MaterialAssetResponseList,
)
from LuPySNB.model.responses.MaterialBulkImportResponse import MaterialBulkImportResponse
from LuPySNB.model.responses.MaterialLibraryList import MaterialLibraryList
from LuPySNB.model.responses.MaterialsTable import MaterialsTable as MaterialsTableResponse
from LuPySNB.model.responses.MaterialsTableDescriptor import MaterialsTableDescriptor
from LuPySNB.model.responses.PlateContainerResponse import PlateContainerResponse
from LuPySNB.model.responses.PlateResponse import PlateListResponse, PlateResponse
from LuPySNB.model.responses.UserResponse import UserResponse
from LuPySNB.model.responses.Worksheet import Worksheet as WorksheetResponse

# To avoid conflicts with API/__init__.py
ADTModule = import_module("LuPySNB.API.ADT")
AttributeModule = import_module("LuPySNB.API.Attribute")
ContainerModule = import_module("LuPySNB.API.Container")
EntityModule = import_module("LuPySNB.API.Entity")
FileAttachmentModule = import_module("LuPySNB.API.FileAttachment")
InventoryModule = import_module("LuPySNB.API.Inventory")
LayoutModule = import_module("LuPySNB.API.Layout")
MaterialLibraryModule = import_module("LuPySNB.API.MaterialLibrary")
MaterialsTableModule = import_module("LuPySNB.API.MaterialsTable")
PlateModule = import_module("LuPySNB.API.Plate")
UserModule = import_module("LuPySNB.API.User")
WorksheetModule = import_module("LuPySNB.API.Worksheet")

@pytest.mark.parametrize(
    "function,args,method,expected_arguments",
    [
        (ADTModule.get_adt_data, ("grid:1",), "invoke_rest_get", ("adt/grid:1", ADTContent)),
        (ADTModule.get_experiment_adt_cols, ("grid:1",), "invoke_rest_get", ("adt/grid:1/_column", ADTDescriptor)),
        (AttributeModule.get_attribute_details, ("attribute:1",), "invoke_rest_get", ("attributes/attribute:1", AttributeDetailDescriptor)),
        (ContainerModule.get_container, ("container:1",), "invoke_rest_get", ("inventory/containers/container:1", ContainerResponse)),
        (ContainerModule.get_container_types, (), "invoke_rest_get", ("inventory/types/?entityType=container", ContainerTypeResponseList)),
        (EntityModule.get_entity_by_id, ("experiment:1",), "invoke_rest_get", ("/entities/experiment:1", GetEntityResponse)),
        (EntityModule.delete_entity, ("experiment:1",), "invoke_rest_delete", ("/entities/experiment:1?force=true",)),
        (FileAttachmentModule.get_file_attachment, ("file:1",), "invoke_rest_get_file", ("entities/file:1/export",)),
        (InventoryModule.get_inventory_types, ("location",), "invoke_rest_get", ("inventory/types?entityType=location", InventoryTypeResponseList)),
        (InventoryModule.get_inventory_location_by_eid, ("location:1",), "invoke_rest_get", ("inventory/locations/location:1", InventoryLocationResponse)),
        (LayoutModule.get_pages, ("experiment:1",), "invoke_rest_get", ("entities/experiment:1/layout/pages", PageList)),
        (MaterialLibraryModule.get_material_libraries, (), "invoke_rest_get", ("materials/libraries", MaterialLibraryList)),
        (MaterialLibraryModule.get_material, ("asset:1",), "invoke_rest_get", ("materials/asset:1", MaterialAssetResponse)),
        (MaterialLibraryModule.get_asset, ("Reagents", "asset:1"), "invoke_rest_get", ("materials/Reagents/assets/id/asset:1", MaterialAssetResponse)),
        (MaterialLibraryModule.get_batch, ("Reagents", "batch:1"), "invoke_rest_get", ("materials/Reagents/batches/id/batch:1", MaterialAssetResponse)),
        (MaterialLibraryModule.get_batches, ("Reagents", "asset:1"), "invoke_rest_get", ("materials/Reagents/assets/asset:1/batches", MaterialAssetResponseList)),
        (MaterialLibraryModule.get_bulk_create_report, ("job:1",), "invoke_rest_get", ("materials/bulkImport/jobs/job:1", MaterialBulkImportResponse)),
        (MaterialsTableModule.get_materials_table_data, ("materialsTable:1",), "invoke_rest_get", ("materialsTable/materialsTable:1", MaterialsTableResponse)),
        (MaterialsTableModule.get_materials_table_cols, ("materialsTable:1",), "invoke_rest_get", ("materialsTable/materialsTable:1/_column", MaterialsTableDescriptor)),
        (PlateModule.get_plate_container, ("plateContainer:1",), "invoke_rest_get", ("plates/plateContainer:1", PlateContainerResponse)),
        (PlateModule.get_plates_from_plate_container, ("plateContainer:1",), "invoke_rest_get", ("plates/plateContainer:1/plates", PlateListResponse)),
        (PlateModule.get_plate, ("plateContainer:1", "Plate 1"), "invoke_rest_get", ("plates/plateContainer:1/plates/Plate 1", PlateResponse)),
        (UserModule.get_user_by_id, ("user:1",), "invoke_rest_get", ("users/user:1", UserResponse)),
        (WorksheetModule.get_worksheet, ("worksheet:1",), "invoke_rest_get", ("worksheet/worksheet:1", WorksheetResponse)),
    ],
)
def test_simple_sync_endpoint(function, args, method, expected_arguments, client):
    expected = object()
    getattr(client, method).return_value = expected

    result = function(client, *args)

    assert result is expected
    getattr(client, method).assert_called_once_with(*expected_arguments)


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "function,args,method,expected_arguments",
    [
        (ADTModule.get_adt_data_async, ("grid:1",), "invoke_rest_get_async", ("adt/grid:1", ADTContent)),
        (ADTModule.get_experiment_adt_cols_async, ("grid:1",), "invoke_rest_get_async", ("adt/grid:1/_column", ADTDescriptor)),
        (AttributeModule.get_attribute_details_async, ("attribute:1",), "invoke_rest_get_async", ("attributes/attribute:1", AttributeDetailDescriptor)),
        (ContainerModule.get_container_async, ("container:1",), "invoke_rest_get_async", ("inventory/containers/container:1", ContainerResponse)),
        (ContainerModule.get_container_types_async, (), "invoke_rest_get_async", ("inventory/types/?entityType=container", ContainerTypeResponseList)),
        (EntityModule.get_entity_by_id_async, ("experiment:1",), "invoke_rest_get_async", ("/entities/experiment:1", GetEntityResponse)),
        (EntityModule.delete_entity_async, ("experiment:1",), "invoke_rest_delete_async", ("/entities/experiment:1?force=true",)),
        (FileAttachmentModule.get_file_attachment_async, ("file:1",), "invoke_rest_get_file_async", ("entities/file:1/export",)),
        (InventoryModule.get_inventory_types_async, ("location",), "invoke_rest_get_async", ("inventory/types?entityType=location", InventoryTypeResponseList)),
        (InventoryModule.get_inventory_location_by_eid_async, ("location:1",), "invoke_rest_get_async", ("inventory/locations/location:1", InventoryLocationResponse)),
        (LayoutModule.get_pages_async, ("experiment:1",), "invoke_rest_get_async", ("entities/experiment:1/layout/pages", PageList)),
        (MaterialLibraryModule.get_material_libraries_async, (), "invoke_rest_get_async", ("materials/libraries", MaterialLibraryList)),
        (MaterialLibraryModule.get_material_async, ("asset:1",), "invoke_rest_get_async", ("materials/asset:1", MaterialAssetResponse)),
        (MaterialLibraryModule.get_asset_async, ("Reagents", "asset:1"), "invoke_rest_get_async", ("materials/Reagents/assets/id/asset:1", MaterialAssetResponse)),
        (MaterialLibraryModule.get_batch_async, ("Reagents", "batch:1"), "invoke_rest_get_async", ("materials/Reagents/batches/id/batch:1", MaterialAssetResponse)),
        (MaterialLibraryModule.get_batches_async, ("Reagents", "asset:1"), "invoke_rest_get_async", ("materials/Reagents/assets/asset:1/batches", MaterialAssetResponseList)),
        (MaterialLibraryModule.get_bulk_create_report_async, ("job:1",), "invoke_rest_get_async", ("materials/bulkImport/jobs/job:1", MaterialBulkImportResponse)),
        (MaterialsTableModule.get_materials_table_data_async, ("materialsTable:1",), "invoke_rest_get_async", ("materialsTable/materialsTable:1", MaterialsTableResponse)),
        (MaterialsTableModule.get_materials_table_cols_async, ("materialsTable:1",), "invoke_rest_get_async", ("materialsTable/materialsTable:1/_column", MaterialsTableDescriptor)),
        (PlateModule.get_plate_container_async, ("plateContainer:1",), "invoke_rest_get_async", ("plates/plateContainer:1", PlateContainerResponse)),
        (PlateModule.get_plates_from_plate_container_async, ("plateContainer:1",), "invoke_rest_get_async", ("plates/plateContainer:1/plates", PlateListResponse)),
        (PlateModule.get_plate_async, ("plateContainer:1", "Plate 1"), "invoke_rest_get_async", ("plates/plateContainer:1/plates/Plate 1", PlateResponse)),
        (UserModule.get_user_by_id_async, ("user:1",), "invoke_rest_get_async", ("users/user:1", UserResponse)),
        (WorksheetModule.get_worksheet_async, ("worksheet:1",), "invoke_rest_get_async", ("worksheet/worksheet:1", WorksheetResponse)),
    ],
)
async def test_simple_async_endpoint(function, args, method, expected_arguments, async_client):
    expected = object()
    getattr(async_client, method).return_value = expected

    result = await function(async_client, *args)

    assert result is expected
    getattr(async_client, method).assert_awaited_once_with(*expected_arguments)


def test_update_file_attachment_calls_put_file(client):
    content = BytesIO(b"data")
    expected = object()
    client.invoke_rest_put_file.return_value = expected

    result = FileAttachmentModule.update_file_attachment(client, "file:1", "text/plain", content)

    assert result is expected
    client.invoke_rest_put_file.assert_called_once_with(
        "entities/file:1/attachment?force=true", "text/plain", content, Attachment
    )


@pytest.mark.asyncio
async def test_update_file_attachment_async_calls_put_file(async_client):
    content = BytesIO(b"data")
    expected = object()
    async_client.invoke_rest_put_file_async.return_value = expected

    result = await FileAttachmentModule.update_file_attachment_async(
        async_client, "file:1", "text/plain", content
    )

    assert result is expected
    async_client.invoke_rest_put_file_async.assert_awaited_once_with(
        "entities/file:1/attachment?force=true", "text/plain", content, Attachment
    )
