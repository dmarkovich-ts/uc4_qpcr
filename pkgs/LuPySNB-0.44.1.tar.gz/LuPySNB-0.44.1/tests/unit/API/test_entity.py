from importlib import import_module
from datetime import datetime
from types import SimpleNamespace
from unittest.mock import patch

import pytest

from LuPySNB.model.exceptions.LuPySNBInternalException import (
    LuPySNBInternalException,
)
from LuPySNB.model.responses.CreateEntityResponse import CreateEntityResponse
from LuPySNB.model.responses.EntityDescriptorList import (
    EntityDescriptorList,
    EntityDescriptorListFromQuery,
)
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.UpdateEntityPropertiesResponse import (
    UpdateEntityPropertiesResponse,
)

EntityModule = import_module("LuPySNB.API.Entity")


def descriptor_list(*items):
    return EntityDescriptorListFromQuery.model_construct(data=list(items))


def item(item_id="id:1", eid="eid:1", name="Name", entity_type="experiment"):
    return SimpleNamespace(
        id=item_id,
        attributes=SimpleNamespace(eid=eid, name=name, type=entity_type),
    )


def test_entity_name_query_adds_optional_filters():
    query = EntityModule._get_entities_by_name_build_query(
        "Experiment 1",
        "experiment",
        False,
        is_system=True,
        has_no_parent=True,
    )
    dumped = query.model_dump(by_alias=True, exclude_none=True)

    assert len(dumped["query"]["$and"]) == 5
    assert dumped["query"]["$and"][0]["$match"]["field"] == "name"
    assert dumped["query"]["$and"][2]["$match"]["field"] == "type"
    assert dumped["query"]["$and"][3]["$match"]["field"] == "system._isSystem"
    assert "$not" in dumped["query"]["$and"][4]


def test_entities_from_names_query_supports_type_list():
    query = EntityModule._get_entities_from_names_build_query(
        ["A", "B"],
        ["experiment", "journal"],
    )
    dumped = query.model_dump(by_alias=True, exclude_none=True)

    assert dumped["query"]["$and"][2]["$in"]["values"] == [
        "experiment",
        "journal",
    ]


def test_get_entities_builds_all_url_parameters(client):
    expected = object()
    client.invoke_rest_get.return_value = expected
    start = datetime(2026, 1, 1, 8, 30)
    end = datetime(2026, 1, 2, 9, 45)

    result = EntityModule.get_entities(
        client,
        include_types=[EntityModule.EntityType.experiment],
        exclude_types=[EntityModule.EntityType.journal],
        entity_options=[
            EntityModule.EntityOption.mine,
            EntityModule.EntityOption.starred,
        ],
        start_date=start,
        end_date=end,
    )

    assert result is expected
    client.invoke_rest_get.assert_called_once_with(
        "/entities?includeTypes=experiment"
        "&excludeTypes=journal"
        "&includeOptions=mine,starred"
        "&start=2026-01-01T08:30:00"
        "&end=2026-01-02T09:45:00",
        EntityDescriptorList,
    )


@pytest.mark.asyncio
async def test_get_entities_async_builds_url(async_client):
    expected = object()
    async_client.invoke_rest_get_async.return_value = expected

    result = await EntityModule.get_entities_async(
        async_client,
        include_types=[EntityModule.EntityType.experiment],
    )

    assert result is expected
    async_client.invoke_rest_get_async.assert_awaited_once_with(
        "/entities?includeTypes=experiment",
        EntityDescriptorList,
    )


@pytest.mark.parametrize(
    "response,expected",
    [
        (descriptor_list(item(item_id="id:1")), "id:1"),
        (descriptor_list(), None),
    ],
)
def test_entity_id_response_handler(response, expected):
    result = EntityModule._get_entity_id_by_name_handle_response(
        response,
        "Name",
        "experiment",
    )

    assert result == expected


def test_entity_id_response_handler_passes_errors_through():
    error = ErrorList.model_construct(errors=[])

    result = EntityModule._get_entity_id_by_name_handle_response(
        error,
        "Name",
        "experiment",
    )

    assert result is error


def test_entity_id_response_handler_rejects_multiple_matches():
    response = descriptor_list(item("id:1"), item("id:2"))

    with pytest.raises(LuPySNBInternalException, match="No unique match"):
        EntityModule._get_entity_id_by_name_handle_response(
            response,
            "Name",
            "experiment",
        )


def test_child_query_supports_multiple_types_and_name():
    query = EntityModule._get_child_entities_by_parent_id_build_query(
        "experiment:1",
        ["grid", "worksheet"],
        "Results",
    )
    dumped = query.model_dump(by_alias=True, exclude_none=True)

    assert "$parent" in dumped["query"]["$and"][0]
    assert "$or" in dumped["query"]["$and"][1]
    assert dumped["query"]["$and"][2]["$match"]["value"] == "Results"


def test_parent_query_supports_type_and_name():
    query = EntityModule._get_parent_entities_by_child_id_build_query(
        "grid:1",
        "experiment",
        "Experiment 1",
    )
    dumped = query.model_dump(by_alias=True, exclude_none=True)

    assert "$child" in dumped["query"]["$and"][0]
    assert dumped["query"]["$and"][1]["$match"]["value"] == "experiment"
    assert dumped["query"]["$and"][2]["$match"]["value"] == "Experiment 1"


def test_child_by_name_query_omits_ado_parent_type():
    query = EntityModule._get_child_entities_by_name_build_query(
        "File",
        None,
        "Parent",
        "ado",
    )
    dumped = query.model_dump(by_alias=True, exclude_none=True)

    assert len(dumped["query"]["$and"]) == 2


def test_child_entity_id_handler_returns_unique_id():
    response = descriptor_list(item(item_id="file:1"))

    result = EntityModule._get_child_entity_id_by_name_handle_response(
        response,
        "File",
        None,
        "Parent",
        "experiment",
    )

    assert result == "file:1"


def test_child_entity_id_handler_returns_none_for_no_match():
    result = EntityModule._get_child_entity_id_by_name_handle_response(
        descriptor_list(),
        "File",
        None,
        "Parent",
        "experiment",
    )

    assert result is None


def test_create_entity_uses_request_factory_and_posts(client):
    request = object()
    expected = object()
    client.invoke_rest_post.return_value = expected

    with patch.object(
        EntityModule.CreateEntityRequest,
        "create",
        return_value=request,
    ) as create:
        result = EntityModule.create_entity(
            client,
            "template:1",
            "parent:1",
            {"Name": "A"},
        )

    assert result is expected
    create.assert_called_once_with(
        "template:1",
        "parent:1",
        {"Name": "A"},
    )
    client.invoke_rest_post.assert_called_once_with(
        "entities/?force=true",
        request,
        CreateEntityResponse,
    )


@pytest.mark.asyncio
async def test_create_entity_async_uses_request_factory(async_client):
    request = object()
    expected = object()
    async_client.invoke_rest_post_async.return_value = expected

    with patch.object(
        EntityModule.CreateEntityRequest,
        "create",
        return_value=request,
    ):
        result = await EntityModule.create_entity_async(
            async_client,
            "template:1",
            None,
            {"Name": "A"},
        )

    assert result is expected
    async_client.invoke_rest_post_async.assert_awaited_once_with(
        "entities/?force=true",
        request,
        CreateEntityResponse,
    )


def test_update_entity_properties_builds_request(client):
    request = object()
    expected = object()
    properties = [{"name": "Name", "value": "New"}]
    client.invoke_rest_patch.return_value = expected

    with patch.object(
        EntityModule.UpdateEntityRequest,
        "create",
        return_value=request,
    ) as create:
        result = EntityModule.update_entity_properties_by_id(
            client,
            "entity:1",
            properties,
        )

    assert result is expected
    create.assert_called_once_with(properties)
    client.invoke_rest_patch.assert_called_once_with(
        "/entities/entity:1/properties?force=true",
        request,
        UpdateEntityPropertiesResponse,
    )


@pytest.mark.parametrize(
    "function,endpoint",
    [
        (EntityModule.close_entity, "close"),
        (EntityModule.reopen_entity, "reopen"),
    ],
)
def test_entity_review_actions(function, endpoint, client):
    request = object()

    with patch.object(
        EntityModule.EntityReview,
        "create",
        return_value=request,
    ):
        function(client, "entity:1", "Reason")

    client.invoke_rest_post.assert_called_once_with(
        f"/entities/entity:1/reviews/{endpoint}",
        request,
        None,
    )


# ---------------------------------------------------------------------------
# Ancestors
# ---------------------------------------------------------------------------


def ancestors_list(*items):
    return EntityDescriptorList.model_construct(data=list(items))


def test_get_ancestors_by_child_id_calls_rest_get(client):
    expected = object()
    client.invoke_rest_get.return_value = expected

    result = EntityModule.get_ancestors_by_child_id(client, "grid:1")

    assert result is expected
    client.invoke_rest_get.assert_called_once_with(
        "entities/grid:1/ancestors",
        EntityDescriptorList,
    )


@pytest.mark.asyncio
async def test_get_ancestors_by_child_id_async_calls_rest_get(async_client):
    expected = object()
    async_client.invoke_rest_get_async.return_value = expected

    result = await EntityModule.get_ancestors_by_child_id_async(async_client, "grid:1")

    assert result is expected
    async_client.invoke_rest_get_async.assert_awaited_once_with(
        "entities/grid:1/ancestors",
        EntityDescriptorList,
    )


def test_get_parent_experiment_returns_experiment_ancestor(client):
    exp = item(item_id="exp:1", entity_type="experiment")
    client.invoke_rest_get.return_value = ancestors_list(
        item(item_id="ws:1", entity_type="worksheet"),
        exp,
    )

    result = EntityModule.get_parent_experiment_by_child_id(client, "grid:1")

    assert result is exp


def test_get_parent_experiment_returns_ado_ancestor(client):
    ado = item(item_id="ado:1", entity_type="ado")
    client.invoke_rest_get.return_value = ancestors_list(
        item(item_id="ws:1", entity_type="worksheet"),
        ado,
    )

    result = EntityModule.get_parent_experiment_by_child_id(client, "grid:1")

    assert result is ado


def test_get_parent_experiment_returns_none_when_no_experiment(client):
    client.invoke_rest_get.return_value = ancestors_list(
        item(item_id="ws:1", entity_type="worksheet"),
    )

    result = EntityModule.get_parent_experiment_by_child_id(client, "grid:1")

    assert result is None


def test_get_parent_experiment_returns_none_for_empty_ancestors(client):
    client.invoke_rest_get.return_value = ancestors_list()

    result = EntityModule.get_parent_experiment_by_child_id(client, "grid:1")

    assert result is None


def test_get_parent_experiment_passes_errors_through(client):
    error = ErrorList.model_construct(errors=[])
    client.invoke_rest_get.return_value = error

    result = EntityModule.get_parent_experiment_by_child_id(client, "grid:1")

    assert result is error


@pytest.mark.asyncio
async def test_get_parent_experiment_async_returns_experiment(async_client):
    exp = item(item_id="exp:1", entity_type="experiment")
    async_client.invoke_rest_get_async.return_value = ancestors_list(
        item(item_id="ws:1", entity_type="worksheet"),
        exp,
    )

    result = await EntityModule.get_parent_experiment_by_child_id_async(
        async_client, "grid:1"
    )

    assert result is exp


@pytest.mark.asyncio
async def test_get_parent_experiment_async_returns_none_when_no_experiment(async_client):
    async_client.invoke_rest_get_async.return_value = ancestors_list(
        item(item_id="ws:1", entity_type="worksheet"),
    )

    result = await EntityModule.get_parent_experiment_by_child_id_async(
        async_client, "grid:1"
    )

    assert result is None


@pytest.mark.asyncio
async def test_get_parent_experiment_async_passes_errors_through(async_client):
    error = ErrorList.model_construct(errors=[])
    async_client.invoke_rest_get_async.return_value = error

    result = await EntityModule.get_parent_experiment_by_child_id_async(
        async_client, "grid:1"
    )

    assert result is error