from importlib import import_module
from io import BytesIO
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import pytest

from LuPySNB.model.exceptions.LuPySNBInternalException import LuPySNBInternalException
from LuPySNB.model.responses.CreateEntityResponse import CreateEntityResponse
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.MaterialAssetResponse import MaterialAssetResponse, MaterialAssetResponseList
from LuPySNB.model.responses.MaterialBulkImportResponse import MaterialBulkImportResponse
from LuPySNB.model.responses.MaterialLibraryList import MaterialLibraryList
from LuPySNB.model.responses.MaterialsTable import MaterialsTable, MaterialsTableRow
from LuPySNB.model.responses.UpdateMaterialPropertiesResponse import UpdateMaterialPropertiesResponse

MaterialLibraryModule = import_module("LuPySNB.API.MaterialLibrary")

def library(name="Reagents", library_id="library:1"):
    return SimpleNamespace(id=library_id, attributes=SimpleNamespace(name=name))


def libraries(*items):
    return MaterialLibraryList.model_construct(data=list(items))


def test_material_library_handler_returns_unique_match():
    expected = library()

    assert MaterialLibraryModule._get_material_library_by_name_handle_response(
        libraries(expected), "Reagents"
    ) is expected


def test_material_library_handler_returns_none_without_match():
    assert MaterialLibraryModule._get_material_library_by_name_handle_response(
        libraries(library("Other")), "Reagents"
    ) is None


def test_material_library_handler_rejects_duplicate_names():
    with pytest.raises(LuPySNBInternalException, match="not unique"):
        MaterialLibraryModule._get_material_library_by_name_handle_response(
            libraries(library(), library(library_id="library:2")), "Reagents"
        )


def test_material_library_handler_passes_error_through():
    error = ErrorList.model_construct(errors=[])

    assert MaterialLibraryModule._get_material_library_by_name_handle_response(error, "Reagents") is error


def test_assets_by_name_query_uses_prefixed_library_id():
    query = MaterialLibraryModule._get_assets_by_name_build_query("library:1", ["A", "B"])

    assert query.query.andList[0].match.values == ["assetType:library:1"]
    assert query.query.andList[1].match.values == ["A", "B"]


def test_assets_by_tag_query_builds_material_field():
    query = MaterialLibraryModule._get_assets_by_tag_build_query(
        "library:1", "CAS", ["50-00-0"]
    )

    assert query.query.andList[1].match.field == "materials.CAS"
    assert query.query.andList[1].match.values == ["50-00-0"]


def test_unique_check_asset_posts_request(client):
    request = object()
    expected = object()
    client.invoke_rest_post.return_value = expected

    result = MaterialLibraryModule.unique_check_asset(client, "Reagents", request)

    assert result is expected
    client.invoke_rest_post.assert_called_once_with(
        "materials/Reagents/assets/uniquenessCheck", request, MaterialAssetResponseList
    )


def test_create_asset_posts_request(client):
    request = object()

    MaterialLibraryModule.create_asset(client, "Reagents", request)

    client.invoke_rest_post.assert_called_once_with(
        "materials/Reagents/assets", request, MaterialAssetResponse
    )


def test_create_asset_bulk_includes_rule(client):
    request = object()

    MaterialLibraryModule.create_asset_bulk(client, "Reagents", "CREATE", request)

    client.invoke_rest_post.assert_called_once_with(
        "materials/Reagents/bulkImport?rule=CREATE&importType=json",
        request,
        MaterialBulkImportResponse,
    )


def test_create_asset_bulk_sdf_posts_zip(client):
    content = BytesIO(b"zip")

    MaterialLibraryModule.create_asset_bulk_sdf(client, "Reagents", "CREATE", content)

    client.invoke_rest_post_file.assert_called_once_with(
        "materials/Reagents/bulkImport?rule=CREATE&importType=zip",
        "application/x-zip",
        content,
        MaterialBulkImportResponse,
    )


def test_create_batch_posts_to_asset(client):
    request = object()

    MaterialLibraryModule.create_batch(client, "Reagents", "asset:1", request)

    client.invoke_rest_post.assert_called_once_with(
        "materials/Reagents/assets/asset:1/batches", request, MaterialAssetResponse
    )


def test_update_material_properties_uses_force(client):
    request = object()

    MaterialLibraryModule.update_material_properties(client, "asset:1", request)

    client.invoke_rest_patch.assert_called_once_with(
        "materials/asset:1/properties?force=true",
        request,
        UpdateMaterialPropertiesResponse,
    )


def test_add_materials_table_row_builds_request(client):
    request = object()
    cells = [{"key": "column:1", "value": "A"}]

    with patch.object(
        MaterialLibraryModule.MaterialsTableAddRowRequest, "create", return_value=request
    ) as create:
        MaterialLibraryModule.add_materials_table_row(
            client, "materialsTable:1", "asset:1", cells
        )

    create.assert_called_once_with("asset:1", cells)
    client.invoke_rest_post.assert_called_once_with(
        "materialsTable/materialsTable:1?force=true", request, MaterialsTableRow
    )


def test_add_multiple_materials_table_rows_builds_request(client):
    request = object()
    ids = ["asset:1", "asset:2"]
    cells = [[], []]

    with patch.object(
        MaterialLibraryModule.MaterialsTableAddMultipleRowRequest,
        "create",
        return_value=request,
    ) as create:
        MaterialLibraryModule.add_multiple_materials_table_row(
            client, "materialsTable:1", ids, cells
        )

    create.assert_called_once_with(ids, cells)
    client.invoke_rest_patch.assert_called_once_with(
        "materialsTable/materialsTable:1?force=true", request, MaterialsTable
    )


def created_table(table_id="materialsTable:1", name="Materials Table"):
    return CreateEntityResponse.model_construct(
        data=SimpleNamespace(
            id=table_id,
            attributes=SimpleNamespace(name=name),
        )
    )


def test_create_materials_table_without_custom_name(client):
    response = created_table()
    client.invoke_rest_post.return_value = response

    with patch.object(MaterialLibraryModule.CreateEntityRequest, "create", return_value="request") as create:
        result = MaterialLibraryModule.create_materials_table(
            client, "Reagents", "experiment:1"
        )

    assert result is response
    create.assert_called_once_with(
        None, "experiment:1", {"libraryName": "Reagents"}, "materialsTable"
    )
    client.invoke_rest_post.assert_called_once_with(
        "entities?force=true", "request", CreateEntityResponse
    )


def test_create_materials_table_updates_custom_name(client):
    response = created_table()
    client.invoke_rest_post.return_value = response

    with patch.object(MaterialLibraryModule.CreateEntityRequest, "create", return_value="request"), patch.object(
        MaterialLibraryModule, "update_entity_properties_by_id", return_value=object()
    ) as update:
        result = MaterialLibraryModule.create_materials_table(
            client, "Reagents", "experiment:1", "Samples"
        )

    update.assert_called_once_with(
        client,
        "materialsTable:1",
        [{"name": "Name", "value": "Samples"}],
    )
    assert result.data.attributes.name == "Samples"


def test_create_materials_table_keeps_name_when_update_errors(client):
    response = created_table(name="Original")
    client.invoke_rest_post.return_value = response
    error = ErrorList.model_construct(errors=[])

    with patch.object(MaterialLibraryModule.CreateEntityRequest, "create", return_value="request"), patch.object(
        MaterialLibraryModule, "update_entity_properties_by_id", return_value=error
    ):
        result = MaterialLibraryModule.create_materials_table(
            client, "Reagents", "experiment:1", "Samples"
        )

    assert result.data.attributes.name == "Original"


@pytest.mark.asyncio
async def test_add_materials_table_row_async_uses_post(async_client):
    request = object()
    with patch.object(
        MaterialLibraryModule.MaterialsTableAddRowRequest, "create", return_value=request
    ):
        await MaterialLibraryModule.add_materials_table_row_async(
            async_client, "materialsTable:1", "asset:1"
        )

    async_client.invoke_rest_post_async.assert_awaited_once_with(
        "materialsTable/materialsTable:1?force=true", request, MaterialsTableRow
    )


@pytest.mark.asyncio
async def test_create_materials_table_async_updates_name(async_client):
    response = created_table()
    async_client.invoke_rest_post_async.return_value = response

    with patch.object(MaterialLibraryModule.CreateEntityRequest, "create", return_value="request"), patch.object(
        MaterialLibraryModule,
        "update_entity_properties_by_id_async",
        AsyncMock(return_value=object()),
    ):
        result = await MaterialLibraryModule.create_materials_table_async(
            async_client, "Reagents", "experiment:1", "Samples"
        )

    assert result.data.attributes.name == "Samples"
