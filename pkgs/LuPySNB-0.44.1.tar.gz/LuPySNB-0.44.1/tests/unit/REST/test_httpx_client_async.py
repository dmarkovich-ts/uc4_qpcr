from io import BytesIO
from unittest.mock import AsyncMock

import pytest

from LuPySNB.model.exceptions.SignalsException import SignalsException
from LuPySNB.model.responses.ErrorList import ErrorList

from helpers import (
    Page,
    RequestBody,
    Result,
    async_client,
    httpx_response,
)


@pytest.mark.asyncio
async def test_async_post_serializes_request_body():
    client = async_client(auto_expand=False)
    client._session.post.return_value = httpx_response(json_data={"value": "ok"})

    result = await client.invoke_rest_post_async(
        "items", RequestBody(value="A"), Result
    )

    assert result.value == "ok"
    client._session.post.assert_awaited_once_with("items", content=b'{"value":"A"}')

@pytest.mark.asyncio
async def test_async_post_without_return_type_returns_none():
    client = async_client()
    client._session.post.return_value = httpx_response()

    assert await client.invoke_rest_post_async("actions", None, None) is None

@pytest.mark.asyncio
async def test_async_put_returns_parsed_response():
    client = async_client()
    client._session.put.return_value = httpx_response(json_data={"value": "ok"})

    result = await client.invoke_rest_put_async("items/1", RequestBody(value="A"), Result)

    assert result.value == "ok"
    client._session.put.assert_awaited_once_with("items/1", content=b'{"value":"A"}')


@pytest.mark.asyncio
async def test_async_patch_returns_parsed_response():
    client = async_client()
    client._session.patch.return_value = httpx_response(json_data={"value": "ok"})

    result = await client.invoke_rest_patch_async("items/1", RequestBody(value="A"), Result)

    assert result.value == "ok"
    client._session.patch.assert_awaited_once_with("items/1", content=b'{"value":"A"}')


@pytest.mark.asyncio
async def test_async_file_upload_streams_content():
    client = async_client()
    client._session.post.return_value = httpx_response(json_data={"value": "ok"})
    body = BytesIO(b"data")

    result = await client.invoke_rest_post_file_async(
        "files", "text/plain", body, Result
    )

    assert result.value == "ok"
    content = client._session.post.call_args.kwargs["content"]
    assert [chunk async for chunk in content] == [b"data"]


@pytest.mark.asyncio
async def test_async_put_file_streams_content():
    client = async_client()
    client._session.put.return_value = httpx_response(json_data={"value": "ok"})
    body = BytesIO(b"pdf-data")

    result = await client.invoke_rest_put_file_async("files/1", "application/pdf", body, Result)

    assert result.value == "ok"
    call_kwargs = client._session.put.call_args.kwargs
    assert call_kwargs["headers"]["Content-Type"] == "application/pdf"
    assert [chunk async for chunk in call_kwargs["content"]] == [b"pdf-data"]


@pytest.mark.asyncio
async def test_async_patch_file_streams_content():
    client = async_client()
    client._session.patch.return_value = httpx_response(json_data={"value": "ok"})
    body = BytesIO(b"img-data")

    result = await client.invoke_rest_patch_file_async("files/1", "image/png", body, Result)

    assert result.value == "ok"
    call_kwargs = client._session.patch.call_args.kwargs
    assert call_kwargs["headers"]["Content-Type"] == "image/png"
    assert [chunk async for chunk in call_kwargs["content"]] == [b"img-data"]


@pytest.mark.asyncio
async def test_async_delete_returns_none_on_success():
    client = async_client()
    client._session.delete.return_value = httpx_response()

    assert await client.invoke_rest_delete_async("items/1") is None
    client._session.delete.assert_awaited_once_with("items/1")


@pytest.mark.asyncio
async def test_async_pagination_extends_pages():
    client = async_client(next_limit=2, auto_expand=True)
    operation = AsyncMock(
        side_effect=[
            httpx_response(json_data={"data": [1, 2], "next_url": "page-2"}),
            httpx_response(json_data={"data": [3], "next_url": None}),
        ]
    )

    result = await client._get_paged_response_async("items", True, operation, Page)

    assert result.data == [1, 2, 3]
    assert operation.await_args_list[0].args == ("items?page[limit]=2",)

@pytest.mark.asyncio
async def test_async_pagination_stops_when_auto_expand_is_disabled():
    client = async_client(auto_expand=False)
    operation = AsyncMock(
        return_value=httpx_response(json_data={"data": [1], "next_url": "page-2"})
    )

    result = await client._get_paged_response_async("items", False, operation, Page)

    assert result.data == [1]
    operation.assert_awaited_once_with("items")


@pytest.mark.asyncio
async def test_async_download_decodes_filename():
    client = async_client()
    client._session.get.return_value = httpx_response(
        headers={
            "content-type": "text/plain",
            "content-disposition": "attachment; filename*=utf-8''notes.txt",
        },
        content=b"data",
    )

    result = await client.invoke_rest_get_file_async("files/1")

    assert result.filename == "notes.txt"

@pytest.mark.asyncio
async def test_async_download_allows_missing_filename():
    client = async_client()
    client._session.get.return_value = httpx_response(
        headers={"content-type": "application/pdf"},
        content=b"data",
    )

    result = await client.invoke_rest_get_file_async("files/1")

    assert result.filename is None
    assert result.mime_type == "application/pdf"
    assert result.content == b"data"


@pytest.mark.asyncio
async def test_async_handle_error_returns_error_list():
    client = async_client()
    response = httpx_response(
        success=False,
        status_code=400,
        json_data={"errors": [{"status": 400, "code": "bad_request"}]},
    )

    result = client._handle_error(response)

    assert isinstance(result, ErrorList)
    assert result.errors[0].code == "bad_request"


@pytest.mark.asyncio
async def test_async_handle_error_builds_rate_limit_error():
    client = async_client()
    response = httpx_response(
        success=False,
        status_code=429,
        headers={"retry-after": "10"},
    )
    response.json.side_effect = ValueError("not JSON")

    result = client._handle_error(response)

    assert result.errors[0].status == 429
    assert result.errors[0].detail == "Retry after 10 seconds"


@pytest.mark.asyncio
async def test_async_handle_error_raises_signals_exception_when_configured():
    client = async_client(raise_on_signals_error=True)
    response = httpx_response(
        success=False,
        status_code=400,
        json_data={"errors": [{"status": 400, "code": "bad_request"}]},
    )

    with pytest.raises(SignalsException):
        client._handle_error(response)


@pytest.mark.asyncio
async def test_async_handle_error_raises_signals_exception_on_rate_limit():
    client = async_client(raise_on_signals_error=True)
    response = httpx_response(
        success=False,
        status_code=429,
        headers={"retry-after": "5"},
    )
    response.json.side_effect = ValueError("not JSON")

    with pytest.raises(SignalsException):
        client._handle_error(response)


@pytest.mark.asyncio
async def test_async_context_manager_closes_session():
    client = async_client()

    async with client as entered:
        assert entered is client

    client._session.aclose.assert_awaited_once_with()