from io import BytesIO
from unittest.mock import Mock

import pytest

from LuPySNB.model.exceptions.SignalsException import SignalsException

from helpers import (
    Page,
    RequestBody,
    Result,
    requests_client,
    requests_response,
)


def test_requests_post_uses_base_url_and_serialized_body():
    client = requests_client(auto_expand=False)
    client._session.post.return_value = requests_response(json_data={"value": "ok"})

    result = client.invoke_rest_post("items", RequestBody(value="A"), Result)

    assert result.value == "ok"
    client._session.post.assert_called_once_with(
        "https://signals.test/items", data=b'{"value":"A"}'
    )

def test_requests_post_without_return_type_uses_timeout_and_verify():
    client = requests_client(request_timeout=12, request_verify=False)
    client._session.post.return_value = requests_response()

    result = client.invoke_rest_post("actions", None, None)

    assert result is None
    client._session.post.assert_called_once_with(
        "https://signals.test/actions", data=None, timeout=12, verify=False
    )

def test_requests_put_returns_parsed_response():
    client = requests_client()
    client._session.put.return_value = requests_response(
        json_data={"value": "ok"}
    )

    result = client.invoke_rest_put("items/1", RequestBody(value="A"), Result)

    assert result.value == "ok"
    client._session.put.assert_called_once_with(
        "https://signals.test/items/1",
        data=b'{"value":"A"}',
        timeout=30,
        verify=True,
    )

def test_requests_patch_returns_parsed_response():
    client = requests_client()
    client._session.patch.return_value = requests_response(
        json_data={"value": "ok"}
    )

    result = client.invoke_rest_patch("items/1", RequestBody(value="A"), Result)

    assert result.value == "ok"
    client._session.patch.assert_called_once_with(
        "https://signals.test/items/1",
        timeout=30,
        verify=True,
        data=b'{"value":"A"}',
    )

def test_requests_post_file_adds_content_type():
    client = requests_client()
    body = BytesIO(b"data")
    client._session.post.return_value = requests_response(
        json_data={"value": "ok"}
    )

    result = client.invoke_rest_post_file("files", "text/plain", body, Result)

    assert result.value == "ok"
    expected_headers = {"Authorization": "Key", "Content-Type": "text/plain"}
    client._session.post.assert_called_once_with(
        "https://signals.test/files",
        data=body,
        headers=expected_headers,
        timeout=30,
        verify=True,
    )

def test_requests_put_file_adds_content_type():
    client = requests_client()
    body = BytesIO(b"data")
    client._session.put.return_value = requests_response(
        json_data={"value": "ok"}
    )

    result = client.invoke_rest_put_file("files/1", "application/pdf", body, Result)

    assert result.value == "ok"
    expected_headers = {"Authorization": "Key", "Content-Type": "application/pdf"}
    client._session.put.assert_called_once_with(
        "https://signals.test/files/1",
        data=body,
        headers=expected_headers,
        timeout=30,
        verify=True,
    )

def test_requests_patch_file_adds_content_type():
    client = requests_client()
    body = BytesIO(b"data")
    client._session.patch.return_value = requests_response(
        json_data={"value": "ok"}
    )

    result = client.invoke_rest_patch_file("files/1", "image/png", body, Result)

    assert result.value == "ok"
    expected_headers = {"Authorization": "Key", "Content-Type": "image/png"}
    client._session.patch.assert_called_once_with(
        "https://signals.test/files/1",
        data=body,
        headers=expected_headers,
        timeout=30,
        verify=True,
    )

def test_requests_file_download_returns_file():
    client = requests_client()
    client._session.get.return_value = requests_response(
        headers={"content-type": "application/pdf", "content-disposition": "attachment; filename*=utf-8''report.pdf"}, content=b"pdf"
    )

    result = client.invoke_rest_get_file("files/1")

    assert result.filename == "report.pdf"
    assert result.mime_type == "application/pdf"
    assert result.content == b"pdf"

    expected_headers = client._config.headers.copy()
    expected_headers["Accept"] = "application/octet-stream"

    client._session.get.assert_called_once_with(
        "https://signals.test/files/1", headers=expected_headers, timeout=30, verify=True,
    )


def test_requests_file_download_allows_missing_filename():
    client = requests_client()
    client._session.get.return_value = requests_response(
        headers={"content-type": "application/pdf"}, content=b"pdf"
    )

    result = client.invoke_rest_get_file("files/1")

    assert result.filename is None

def test_requests_delete_uses_base_url():
    client = requests_client()
    client._session.delete.return_value = requests_response(status_code=204)

    assert client.invoke_rest_delete("items/1") is None
    client._session.delete.assert_called_once_with(
        "https://signals.test/items/1", timeout=30, verify=True
    )

def test_requests_pagination_adds_base_url_and_limit():
    client = requests_client(next_limit=5, auto_expand=False)
    operation = Mock(
        return_value=requests_response(json_data={"data": [1], "next_url": None})
    )

    result = client._get_paged_response("items", True, operation, Page)

    assert result.data == [1]
    operation.assert_called_once_with("https://signals.test/items?page[limit]=5")

def test_requests_pagination_extends_pages_with_auto_expand():
    client = requests_client(next_limit=2, auto_expand=True)
    responses = [
        requests_response(json_data={"data": [1, 2], "next_url": "https://signals.test/items?page=2"}),
        requests_response(json_data={"data": [3], "next_url": None}),
    ]
    operation = Mock(side_effect=responses)

    result = client._get_paged_response("items", True, operation, Page)

    assert result.data == [1, 2, 3]
    assert operation.call_args_list[0].args == ("https://signals.test/items?page[limit]=2",)
    assert operation.call_args_list[1].args == ("https://signals.test/items?page=2",)

def test_requests_pagination_stops_when_auto_expand_is_disabled():
    client = requests_client(auto_expand=False)
    operation = Mock(
        return_value=requests_response(json_data={"data": [1], "next_url": "page-2"})
    )

    result = client._get_paged_response("items", False, operation, Page)

    assert result.data == [1]
    operation.assert_called_once_with("https://signals.test/items")

def test_requests_handle_error_returns_error_list():
    client = requests_client()
    response = requests_response(
        status_code=400,
        json_data={"errors": [{"status": 400, "code": "bad_request"}]},
    )

    assert client._handle_error(response).errors[0].code == "bad_request"


def test_requests_handle_error_builds_rate_limit_error():
    client = requests_client()
    response = requests_response(status_code=429, headers={"retry-after": "10"})
    response.json.side_effect = ValueError("not JSON")

    result = client._handle_error(response)

    assert result.errors[0].status == 429
    assert result.errors[0].detail == "Retry after 10 seconds"


def test_requests_handle_error_raises_signals_exception_when_configured():
    client = requests_client(raise_on_signals_error=True)
    response = requests_response(
        status_code=400,
        json_data={"errors": [{"status": 400, "code": "bad_request"}]},
    )

    with pytest.raises(SignalsException):
        client._handle_error(response)


def test_requests_handle_error_raises_signals_exception_on_rate_limit():
    client = requests_client(raise_on_signals_error=True)
    response = requests_response(status_code=429, headers={"retry-after": "5"})
    response.json.side_effect = ValueError("not JSON")

    with pytest.raises(SignalsException):
        client._handle_error(response)


def test_requests_context_manager_closes_session():
    client = requests_client()

    with client as entered:
        assert entered is client

    client._session.close.assert_called_once_with()