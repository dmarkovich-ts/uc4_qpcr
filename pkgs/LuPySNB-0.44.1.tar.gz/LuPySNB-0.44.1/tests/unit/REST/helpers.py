from unittest.mock import AsyncMock, Mock

from LuPySNB.REST.RestClientAsyncHTTPX import RestClientAsyncHTTPX
from LuPySNB.REST.RestClientHTTPX import RestClientHTTPX
from LuPySNB.REST.RestClientRequests import RestClientRequests
from LuPySNB.REST.RestConfig import RestConfig
from LuPySNB.model.requests.APIRequest import APIRequest
from LuPySNB.model.responses.APIResponse import APIResponse


class RequestBody(APIRequest):
    value: str
    optional: str | None = None

class Result(APIResponse):
    value: str

class Page(APIResponse):
    data: list[int]
    next_url: str | None = None

    def extend(self, other):
        self.data.extend(other.data)
        self.next_url = other.next_url

    def next_link(self):
        return self.next_url


def config(**overrides):
    values = {"base_url": "https://signals.test", "headers": {"Authorization": "Key"}}
    values.update(overrides)
    return RestConfig(**values)


def async_client(**overrides):
    client = RestClientAsyncHTTPX.__new__(RestClientAsyncHTTPX)
    client._config = config(**overrides)
    client._session = Mock()
    client._session.post = AsyncMock()
    client._session.put = AsyncMock()
    client._session.patch = AsyncMock()
    client._session.get = AsyncMock()
    client._session.delete = AsyncMock()
    client._session.aclose = AsyncMock()
    return client


def httpx_client(**overrides):
    client = RestClientHTTPX.__new__(RestClientHTTPX)
    client._config = config(**overrides)
    client._session = Mock()
    return client


def requests_client(**overrides):
    client = RestClientRequests.__new__(RestClientRequests)
    client._config = config(**overrides)
    client._session = Mock()
    return client


def httpx_response(*, success=True, json_data=None, status_code=200, headers=None, content=b""):
    response = Mock()
    response.is_success = success
    response.status_code = status_code
    response.headers = headers or {}
    response.content = content
    response.json.return_value = json_data if json_data is not None else {}
    return response


def requests_response(*, status_code=200, json_data=None, headers=None, content=b""):
    response = Mock()
    response.status_code = status_code
    response.headers = headers or {}
    response.content = content
    response.json.return_value = json_data if json_data is not None else {}
    return response
