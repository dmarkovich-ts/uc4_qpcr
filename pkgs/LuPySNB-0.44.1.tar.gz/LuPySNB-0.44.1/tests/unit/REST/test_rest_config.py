from LuPySNB.REST.RestConfig import RestConfig


def test_rest_config_defaults():
    value = RestConfig(base_url="https://signals.test")

    assert value.next_limit == 100
    assert value.request_timeout == 30
    assert value.request_verify is True
    assert value.auto_expand is True
    assert value.raise_on_signals_error is False

