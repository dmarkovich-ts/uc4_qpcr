from io import BytesIO
from unittest.mock import Mock

import pytest

from LuPySNB.model.exceptions.SignalsException import SignalsException
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.File import File

from helpers import (
    Page,
    RequestBody,
    Result,
    httpx_client,
    httpx_response,
)


def test_httpx_post_serializes_request_body():
    client = httpx_client(auto_expand=False)
    client._session.post.return_value = httpx_response(json_data={"value": "ok"})

    result = client.invoke_rest_post("items", RequestBody(value="A"), Result)

    assert result.value == "ok"
    client._session.post.assert_called_once_with(
        "items", content=b'{"value":"A"}', headers={"Authorization": "Key"}
    )

def test_httpx_post_without_return_type_returns_none():
    client = httpx_client()
    client._session.post.return_value = httpx_response()

    assert client.invoke_rest_post("actions", None, None) is None

def test_httpx_put_returns_parsed_response():
    client = httpx_client()
    client._session.put.return_value = httpx_response(json_data={"value": "ok"})

    result = client.invoke_rest_put("items/1", RequestBody(value="A"), Result)

    assert result.value == "ok"

def test_httpx_patch_returns_parsed_response():
    client = httpx_client()
    client._session.patch.return_value = httpx_response(json_data={"value": "ok"})

    result = client.invoke_rest_patch("items/1", RequestBody(value="A"), Result)

    assert result.value == "ok"

def test_httpx_file_upload_adds_content_type():
    client = httpx_client()
    body = BytesIO(b"data")
    client._session.post.return_value = httpx_response(json_data={"value": "ok"})

    result = client.invoke_rest_post_file("files", "text/plain", body, Result)

    assert result.value == "ok"
    client._session.post.assert_called_once_with(
        "files",
        content=body,
        headers={"Authorization": "Key", "Content-Type": "text/plain"},
    )

def test_httpx_patch_file_adds_content_type():
    client = httpx_client()
    body = BytesIO(b"data")
    client._session.patch.return_value = httpx_response(json_data={"value": "ok"})

    result = client.invoke_rest_patch_file("files/1", "image/png", body, Result)

    assert result.value == "ok"
    client._session.patch.assert_called_once_with(
        "files/1",
        content=body,
        headers={"Authorization": "Key", "Content-Type": "image/png"},
    )

def test_httpx_download_decodes_filename():
    client = httpx_client()
    client._session.get.return_value = httpx_response(
        headers={
            "content-type": "text/plain",
            "content-disposition": "attachment; filename*=utf-8''my%20file.txt",
        },
        content=b"data",
    )

    result = client.invoke_rest_get_file("files/1")

    assert isinstance(result, File)
    assert result.filename == "my file.txt"
    assert result.mime_type == "text/plain"
    assert result.content == b"data"

def test_httpx_delete_returns_none_on_success():
    client = httpx_client()
    client._session.delete.return_value = httpx_response()

    assert client.invoke_rest_delete("items/1") is None

def test_httpx_pagination_adds_limit_and_extends_pages():
    client = httpx_client(next_limit=2, auto_expand=True)
    responses = [
        httpx_response(json_data={"data": [1, 2], "next_url": "items?page=2"}),
        httpx_response(json_data={"data": [3], "next_url": None}),
    ]
    operation = Mock(side_effect=responses)

    result = client._get_paged_response("items?type=A", True, operation, Page)

    assert result.data == [1, 2, 3]
    assert operation.call_args_list[0].args == ("items?type=A&page[limit]=2",)
    assert operation.call_args_list[1].args == ("items?page=2",)

def test_httpx_pagination_stops_when_auto_expand_is_disabled():
    client = httpx_client(auto_expand=False)
    operation = Mock(
        return_value=httpx_response(json_data={"data": [1], "next_url": "page-2"})
    )

    result = client._get_paged_response("items", False, operation, Page)

    assert result.data == [1]
    operation.assert_called_once_with("items")

def test_httpx_handle_error_returns_signals_errors():
    client = httpx_client()
    response = httpx_response(
        success=False,
        status_code=400,
        json_data={"errors": [{"status": 400, "code": "bad_request"}]},
    )

    result = client._handle_error(response)

    assert isinstance(result, ErrorList)
    assert result.errors[0].code == "bad_request"

def test_httpx_handle_error_builds_rate_limit_error():
    client = httpx_client()
    response = httpx_response(
        success=False,
        status_code=429,
        headers={"retry-after": "10"},
    )
    response.json.side_effect = ValueError("not JSON")

    result = client._handle_error(response)

    assert result.errors[0].status == 429
    assert result.errors[0].detail == "Retry after 10 seconds"

def test_httpx_handle_error_raises_signals_exception_when_configured():
    client = httpx_client(raise_on_signals_error=True)
    response = httpx_response(
        success=False,
        status_code=400,
        json_data={"errors": [{"status": 400, "code": "bad_request"}]},
    )

    with pytest.raises(SignalsException):
        client._handle_error(response)

def test_httpx_context_manager_closes_session():
    client = httpx_client()

    with client as entered:
        assert entered is client

    client._session.close.assert_called_once_with()

