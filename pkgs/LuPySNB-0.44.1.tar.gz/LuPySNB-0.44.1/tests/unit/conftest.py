import sys
import types
from unittest.mock import AsyncMock, Mock

import pytest


# The project imports httpx_retries from LuPySNB.__init__.
# This fallback keeps isolated unit tests runnable
try:
    import httpx_retries  # noqa: F401
except ModuleNotFoundError:
    module = types.ModuleType("httpx_retries")

    class Retry:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    class RetryTransport:
        def __init__(self, retry=None):
            self.retry = retry

    module.Retry = Retry
    module.RetryTransport = RetryTransport
    sys.modules["httpx_retries"] = module


@pytest.fixture
def client():
    return Mock()


@pytest.fixture
def async_client():
    client = Mock()
    client.invoke_rest_get_async = AsyncMock()
    client.invoke_rest_post_async = AsyncMock()
    client.invoke_rest_put_async = AsyncMock()
    client.invoke_rest_patch_async = AsyncMock()
    client.invoke_rest_delete_async = AsyncMock()
    client.invoke_rest_get_file_async = AsyncMock()
    client.invoke_rest_post_file_async = AsyncMock()
    client.invoke_rest_put_file_async = AsyncMock()
    client.invoke_rest_patch_file_async = AsyncMock()
    return client

