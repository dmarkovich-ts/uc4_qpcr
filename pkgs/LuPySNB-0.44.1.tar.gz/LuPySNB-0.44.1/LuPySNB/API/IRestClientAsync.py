from typing import Type, TypeVar, Union, Optional
from io import BytesIO

from LuPySNB.model.requests.APIRequest import APIRequest
from LuPySNB.model.responses.File import File
from LuPySNB.model.responses.APIResponse import APIResponse
from LuPySNB.model.responses.ErrorList import ErrorList


class IRestClientAsync:
    T = TypeVar('T', bound=APIResponse)

    async def invoke_rest_post_async(self, endpoint: str, req_body: Optional[APIRequest], ret_type: Type[T],
                                     use_pagination: bool = False) -> Union[T, ErrorList]:
        pass

    async def invoke_rest_post_file_async(self, endpoint: str, mime_type: str, req_body: BytesIO, ret_type: Type[T]) -> Union[T, ErrorList]:
        pass

    async def invoke_rest_put_async(self, endpoint: str, req_body: APIRequest, ret_type: Type[T]) -> Union[T, ErrorList]:
        pass

    async def invoke_rest_put_file_async(self, endpoint: str, mime_type: str, req_body: BytesIO, ret_type: Type[T]) -> Union[T, ErrorList]:
        pass

    async def invoke_rest_patch_async(self, endpoint: str, req_body: APIRequest, ret_type: Type[T]) -> Union[T, ErrorList]:
        pass

    async def invoke_rest_patch_file_async(self, endpoint: str, mime_type: str, req_body: BytesIO, ret_type: Type[T]) -> Union[T, ErrorList]:
        pass

    async def invoke_rest_get_async(self, endpoint: str, ret_type: Type[T], use_pagination: bool = False) -> Union[T, ErrorList]:
        pass

    async def invoke_rest_get_file_async(self, endpoint: str) -> Union[File, ErrorList]:
        pass

    async def invoke_rest_delete_async(self, endpoint: str) -> Optional[ErrorList]:
        pass

