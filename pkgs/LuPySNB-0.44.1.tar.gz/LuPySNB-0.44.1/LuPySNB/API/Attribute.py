from typing import List, Optional, Union, Any

from LuPySNB.API.IRestClientAsync import IRestClientAsync
from LuPySNB.API.IRestClient import IRestClient
from LuPySNB.model.DTOs.AttributeDescriptor import AttributeDescriptor
from LuPySNB.model.requests import AttributeOptionsUpdateRequest
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.AttributeDescriptorList import AttributeDescriptorList
from LuPySNB.model.responses.AttributeDetailDescriptor import AttributeDetailDescriptor


def _get_attribute_by_name_handle_response(response: Any, attribute_name: str) \
        -> Union[List[AttributeDescriptor], ErrorList]:
    if isinstance(response, AttributeDescriptorList):
        return list(map(lambda x: x.attributes, filter(lambda x: x.attributes.type == "attribute"
                                                                 and x.attributes.name == attribute_name,
                                                       response.data)))
    else:
        return response


def get_attribute_by_name(rest_client: IRestClient, attribute_name: str) -> Union[List[AttributeDescriptor], ErrorList]:
    return _get_attribute_by_name_handle_response(rest_client.invoke_rest_get("attributes", AttributeDescriptorList),
                                                  attribute_name)


async def get_attribute_by_name_async(rest_client: IRestClientAsync, attribute_name: str) \
        -> Union[List[AttributeDescriptor], ErrorList]:
    return _get_attribute_by_name_handle_response(
        await rest_client.invoke_rest_get_async("attributes", AttributeDescriptorList), attribute_name)


def get_attribute_id_by_name(rest_client: IRestClient, attribute_name: str) -> Optional[str]:
    try:
        return next(map(lambda x: x.eid, get_attribute_by_name(rest_client, attribute_name)))
    except StopIteration:
        return None


async def get_attribute_id_by_name_async(rest_client: IRestClientAsync, attribute_name: str) -> Optional[str]:
    try:
        return next(map(lambda x: x.eid, await get_attribute_by_name_async(rest_client, attribute_name)))
    except StopIteration:
        return None


def get_attribute_details(rest_client: IRestClient, attribute_eid: str) -> Union[AttributeDetailDescriptor, ErrorList]:
    return rest_client.invoke_rest_get(f"attributes/{attribute_eid}", AttributeDetailDescriptor)


async def get_attribute_details_async(rest_client: IRestClientAsync, attribute_eid: str) \
        -> Union[AttributeDetailDescriptor, ErrorList]:
    return await rest_client.invoke_rest_get_async(f"attributes/{attribute_eid}", AttributeDetailDescriptor)


def update_attribute_options(rest_client: IRestClient,
                             request: AttributeOptionsUpdateRequest) -> Union[AttributeDetailDescriptor, ErrorList]:
    return rest_client.invoke_rest_patch(f"attributes/{request.data.id}", request, AttributeDetailDescriptor)


async def update_attribute_options_async(rest_client: IRestClientAsync,
                                         request: AttributeOptionsUpdateRequest)\
        -> Union[AttributeDetailDescriptor, ErrorList]:
    return await rest_client.invoke_rest_patch_async(f"attributes/{request.data.id}", request,
                                                     AttributeDetailDescriptor)
