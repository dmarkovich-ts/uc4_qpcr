from typing import Union, BinaryIO

from LuPySNB.model.responses.File import File
from LuPySNB.API.IRestClientAsync import IRestClientAsync
from LuPySNB.API.IRestClient import IRestClient
from LuPySNB.API.Entity import get_entity_by_id, get_child_entity_id_by_name, get_entity_by_id_async, \
    get_child_entity_id_by_name_async, update_entity_properties_by_id, update_entity_properties_by_id_async
from LuPySNB.model.responses.GetEntityResponse import GetEntityResponse
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.Attachment import Attachment
from LuPySNB.model.exceptions.LuPySNBInternalException import LuPySNBInternalException

from urllib.parse import quote
from uuid import uuid4
import mimetypes


def get_file_attachment(rest_client: IRestClient, eid: str) -> Union[File, ErrorList]:
    return rest_client.invoke_rest_get_file(f"entities/{eid}/export")


async def get_file_attachment_async(rest_client: IRestClientAsync, eid: str) -> Union[File, ErrorList]:
    return await rest_client.invoke_rest_get_file_async(f"entities/{eid}/export")


def add_file_attachment(rest_client: IRestClient, eid: str, file_name: str, mime_type: str, content: BinaryIO)\
        -> Union[Attachment, ErrorList]:
    if len(file_name) > 255:
        raise LuPySNBInternalException(f'File name {file_name} is too long. Must be less than 256 characters.')
    if mime_type is None:
        # TODO: replace with mimetypes.guess_file_type when supporting python 3.13
        mime_type = mimetypes.guess_type(file_name)[0] or 'application/octet-stream'
    return rest_client.invoke_rest_post_file(f"entities/{eid}/children/{quote(file_name)}?force=true", mime_type, content,
                                             Attachment)

async def add_file_attachment_async(rest_client: IRestClientAsync, eid: str, file_name: str, mime_type: str | None,
                                    content: BinaryIO) -> Union[Attachment, ErrorList]:
    if len(file_name) > 255:
        raise LuPySNBInternalException(f'File name {file_name} is too long. Must be less than 256 characters.')
    if mime_type is None:
        # TODO: replace with mimetypes.guess_file_type when supporting python 3.13
        mime_type = mimetypes.guess_type(file_name)[0] or 'application/octet-stream'
    return await rest_client.invoke_rest_post_file_async(f"entities/{eid}/children/{quote(file_name)}?force=true", mime_type,
                                                         content, Attachment)

def update_file_attachment(rest_client: IRestClient, eid: str, mime_type: str, content: BinaryIO) -> Union[Attachment, ErrorList]:
    return rest_client.invoke_rest_put_file(f"entities/{eid}/attachment?force=true", mime_type, content,
                                           Attachment)

async def update_file_attachment_async(rest_client: IRestClientAsync, eid: str, mime_type: str, content: BinaryIO) -> Union[Attachment, ErrorList]:
    return await rest_client.invoke_rest_put_file_async(f"entities/{eid}/attachment?force=true", mime_type, content,
                                                       Attachment)

def replace_file_attachment(rest_client: IRestClient, eid: str, file_name: str, mime_type: str | None, content: BinaryIO) -> Union[Attachment, ErrorList]:
    parent_entity = get_entity_by_id(rest_client, eid)
    if not isinstance(parent_entity, GetEntityResponse):
        raise LuPySNBInternalException(f'No match found for parent entity {eid}')

    existing_file_eid = get_child_entity_id_by_name(rest_client, file_name, None, parent_entity.data.attributes.name,
                                                    parent_entity.data.attributes.type)
    if isinstance(existing_file_eid, ErrorList):
        raise LuPySNBInternalException(f'Error retrieving child entity by name: {existing_file_eid}')
    if mime_type is None:
        # TODO: replace with mimetypes.guess_file_type when supporting python 3.13
        mime_type = mimetypes.guess_type(file_name)[0] or 'application/octet-stream'
    if existing_file_eid is not None:
        return update_file_attachment(rest_client, existing_file_eid, mime_type, content)

    return add_file_attachment(rest_client, eid, file_name, mime_type, content)


async def replace_file_attachment_async(rest_client: IRestClientAsync, eid: str, file_name: str, mime_type: str | None,
                                        content: BinaryIO) -> Union[Attachment, ErrorList]:
    parent_entity = await get_entity_by_id_async(rest_client, eid)
    if not isinstance(parent_entity, GetEntityResponse):
        raise LuPySNBInternalException(f'No match found for parent entity {eid}')

    existing_file_eid = await get_child_entity_id_by_name_async(rest_client, file_name, None,
                                                                parent_entity.data.attributes.name,
                                                                parent_entity.data.attributes.type)
    if isinstance(existing_file_eid, ErrorList):
        raise LuPySNBInternalException(f'Error retrieving child entity by name: {existing_file_eid}')

    if mime_type is None:
        # TODO: replace with mimetypes.guess_file_type when supporting python 3.13
        mime_type = mimetypes.guess_type(file_name)[0] or 'application/octet-stream'
    if existing_file_eid is not None:
        return await update_file_attachment_async(rest_client, existing_file_eid, mime_type, content)

    return await add_file_attachment_async(rest_client, eid, file_name, mime_type, content)


