from typing import Union

from LuPySNB.API.IRestClientAsync import IRestClientAsync
from LuPySNB.API.IRestClient import IRestClient
from LuPySNB.model.responses.ErrorList import ErrorList

from LuPySNB.model.requests import Layout as LayoutRequest
from LuPySNB.model.responses import Layout as LayoutResponse

def create_page(rest_client: IRestClient, eid: str, name: str, index: int = -1) -> Union[LayoutResponse.Page, ErrorList]:
    layout_req = LayoutRequest.NewPageRequest.create(name, index)
    return rest_client.invoke_rest_post(f"entities/{eid}/layout/pages?force=true", layout_req, LayoutResponse.Page)

async def create_page_async(rest_client: IRestClientAsync, eid: str, name: str, index: int = -1) -> Union[LayoutResponse.Page, ErrorList]:
    layout_req = LayoutRequest.NewPageRequest.create(name, index)
    return await rest_client.invoke_rest_post_async(f"entities/{eid}/layout/pages?force=true", layout_req, LayoutResponse.Page)

def get_pages(rest_client: IRestClient, eid: str) -> Union[LayoutResponse.PageList, ErrorList]:
    return rest_client.invoke_rest_get(f"entities/{eid}/layout/pages", LayoutResponse.PageList)

async def get_pages_async(rest_client: IRestClientAsync, eid: str) -> Union[LayoutResponse.PageList, ErrorList]:
    return await rest_client.invoke_rest_get_async(f"entities/{eid}/layout/pages", LayoutResponse.PageList)

def put_entity_on_page(rest_client: IRestClient, eid: str, page_id: str, index: int = -1) -> Union[LayoutResponse.Page, ErrorList]:
    layout_req = LayoutRequest.PutEntityOnPageRequest.create(page_id, index)
    return rest_client.invoke_rest_put(f"entities/{eid}/layout/location?force=true", layout_req, LayoutResponse.Page)

async def put_entity_on_page_async(rest_client: IRestClientAsync, eid: str, page_id: str, index: int = -1) -> Union[LayoutResponse.Page, ErrorList]:
    layout_req = LayoutRequest.PutEntityOnPageRequest.create(page_id, index)
    return await rest_client.invoke_rest_put_async(f"entities/{eid}/layout/location?force=true", layout_req, LayoutResponse.Page)
