from typing import Any, Optional
from LuPySNB.API.IRestClientAsync import IRestClientAsync
from LuPySNB.API.IRestClient import IRestClient
from LuPySNB.API.Entity import get_child_entities_by_parent_id, get_child_entities_by_parent_id_async
from LuPySNB.model.responses import MaterialsTable
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.MaterialsTable import MaterialsTable, MaterialsTableRow
from LuPySNB.model.responses.EntityDescriptorList import EntityDescriptorListFromQuery
from LuPySNB.model.responses.MaterialsTableDescriptor import MaterialsTableDescriptor


def _get_experiment_materials_table_id_by_name_handle_response(response: Any) -> str | None | ErrorList:
    if isinstance(response, EntityDescriptorListFromQuery):
        if len(response.data) > 0:
            return response.data[0].attributes.eid
        else:
            return None
    else:
        return response


def get_experiment_materials_table_id_by_name(rest_client: IRestClient, experiment_eid: str,
                                              materials_table_name: str) -> str | None | ErrorList:
    return _get_experiment_materials_table_id_by_name_handle_response(
        get_child_entities_by_parent_id(rest_client, experiment_eid, "materialsTable", materials_table_name))


async def get_experiment_materials_table_id_by_name_async(rest_client: IRestClientAsync, experiment_eid: str,
                                                          materials_table_name: str) -> str | None | ErrorList:
    return _get_experiment_materials_table_id_by_name_handle_response(
        await get_child_entities_by_parent_id_async(rest_client, experiment_eid, "materialsTable",
                                                    materials_table_name))


def get_materials_table_data(rest_client: IRestClient, materials_table_eid: str) -> MaterialsTable | ErrorList:
    return rest_client.invoke_rest_get(f"materialsTable/{materials_table_eid}", MaterialsTable)


async def get_materials_table_data_async(rest_client: IRestClientAsync, materials_table_eid: str)\
        -> MaterialsTable | ErrorList:
    return await rest_client.invoke_rest_get_async(f"materialsTable/{materials_table_eid}", MaterialsTable)


def register_material(rest_client: IRestClient, materials_table_eid: str,materials_table_row_id: str,
                      digest: Optional[str] = None) -> MaterialsTableRow | ErrorList:
    return rest_client.invoke_rest_post(f"materialsTable/{materials_table_eid}/{materials_table_row_id}/register"
                                        f"?force={'false' if digest else 'true'}"
                                        f"{'&digest=' + digest if digest else ''}", None, MaterialsTableRow)


async def register_material_async(rest_client: IRestClientAsync, materials_table_eid: str, materials_table_row_id: str,
                                  digest: Optional[str] = None) -> MaterialsTableRow | ErrorList:
    return await rest_client.invoke_rest_post_async(f"materialsTable/{materials_table_eid}/{materials_table_row_id}/register"
                                        f"?force={'false' if digest else 'true'}"
                                        f"{'&digest=' + digest if digest else ''}", None, MaterialsTableRow)


def get_materials_table_cols(rest_client: IRestClient, materials_table_eid: str) -> MaterialsTableDescriptor | ErrorList:
    return rest_client.invoke_rest_get(f"materialsTable/{materials_table_eid}/_column", MaterialsTableDescriptor)


async def get_materials_table_cols_async(rest_client: IRestClientAsync, materials_table_eid: str) -> MaterialsTableDescriptor | ErrorList:
    return await rest_client.invoke_rest_get_async(f"materialsTable/{materials_table_eid}/_column", MaterialsTableDescriptor)


def delete_materials_table_row(rest_client: IRestClient, materials_table_id: str, row_id: str) -> None | ErrorList:
    return rest_client.invoke_rest_delete(f"materialsTable/{materials_table_id}/{row_id}?force=true")


async def delete_materials_table_row_async(rest_client: IRestClientAsync, materials_table_id: str, row_id: str) -> None | ErrorList:
    return await rest_client.invoke_rest_delete_async(f"materialsTable/{materials_table_id}/{row_id}?force=true")