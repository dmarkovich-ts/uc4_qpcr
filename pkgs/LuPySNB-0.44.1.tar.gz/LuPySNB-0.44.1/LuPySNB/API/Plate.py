from typing import Optional
from LuPySNB.API.IRestClient import IRestClient
from LuPySNB.API.IRestClientAsync import IRestClientAsync
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.PlateResponse import PlateResponse, PlateListResponse
from LuPySNB.model.responses.PlateContainerResponse import PlateContainerResponse
from LuPySNB.model.requests.PlateUpdateRequest import PlateUpdateRequest


def get_plate_container(rest_client: IRestClient, plate_container_eid: str) -> PlateContainerResponse | ErrorList:
    return rest_client.invoke_rest_get(f"plates/{plate_container_eid}", PlateContainerResponse)


async def get_plate_container_async(rest_client: IRestClientAsync, plate_container_eid: str) \
        -> PlateContainerResponse | ErrorList:
    return await rest_client.invoke_rest_get_async(f"plates/{plate_container_eid}", PlateContainerResponse)


def get_plates_from_plate_container(rest_client: IRestClient,
                                    plate_container_eid: str) -> PlateListResponse | ErrorList:
    return rest_client.invoke_rest_get(f"plates/{plate_container_eid}/plates", PlateListResponse)


async def get_plates_from_plate_container_async(rest_client: IRestClientAsync, plate_container_eid: str) \
        -> PlateListResponse | ErrorList:
    return await rest_client.invoke_rest_get_async(f"plates/{plate_container_eid}/plates", PlateListResponse)


def get_plate(rest_client: IRestClient, plate_container_eid: str, plate_name: str) -> PlateResponse | ErrorList:
    return rest_client.invoke_rest_get(f"plates/{plate_container_eid}/plates/{plate_name}", PlateResponse)


async def get_plate_async(rest_client: IRestClientAsync, plate_container_eid: str, plate_name: str) \
        -> PlateResponse | ErrorList:
    return await rest_client.invoke_rest_get_async(f"plates/{plate_container_eid}/plates/{plate_name}", PlateResponse)


def update_plate(rest_client: IRestClient, plate_container_eid: str, plate_name: str, body: PlateUpdateRequest,
                 digest: Optional[str] = None) -> PlateResponse | ErrorList:
    return rest_client.invoke_rest_patch(f"plates/{plate_container_eid}/plates/{plate_name}"
                                         f"?force={'false' if digest else 'true'}"
                                         f"{'&digest=' + digest if digest else ''}", body, PlateResponse)


async def update_plate_async(rest_client: IRestClientAsync, plate_container_eid: str, plate_name: str,
                             body: PlateUpdateRequest, digest: Optional[str] = None) -> PlateResponse | ErrorList:
    return await rest_client.invoke_rest_patch_async(f"plates/{plate_container_eid}/plates/{plate_name}"
                                                     f"?force={'false' if digest else 'true'}"
                                                     f"{'&digest=' + digest if digest else ''}", body, PlateResponse)
