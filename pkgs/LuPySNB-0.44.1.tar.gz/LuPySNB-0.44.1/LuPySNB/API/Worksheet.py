from typing import List, Tuple, Union, Any
from LuPySNB.API.IRestClient import IRestClient
from LuPySNB.API.IRestClientAsync import IRestClientAsync
from LuPySNB.model.DTOs.FieldValue import InputValueTypes
from LuPySNB.model.DTOs.FieldDefinition import FieldDefinition
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.Worksheet import Worksheet
from LuPySNB.model.responses.EntityDescriptorList import EntityDescriptorList
from LuPySNB.model.requests.WorkssheetUpdateRequest import WorksheetUpdateRequest


def _get_experiment_worksheet_ids_by_name_handle_response(response: Any, worksheet_name: str) \
        -> Union[List[str], ErrorList]:
    return list(map(lambda x: x.attributes.eid,
                    filter(lambda x: x.attributes.type == "worksheet" and x.attributes.name == worksheet_name,
                           response.data))) if isinstance(response, EntityDescriptorList) else response


def get_experiment_worksheet_ids_by_name(rest_client: IRestClient, experiment_eid: str, worksheet_name: str) \
        -> Union[List[str], ErrorList]:
    return _get_experiment_worksheet_ids_by_name_handle_response(
        rest_client.invoke_rest_get(f"entities/{experiment_eid}/children", EntityDescriptorList, True),
        worksheet_name)


async def get_experiment_worksheet_ids_by_name_async(rest_client: IRestClientAsync, experiment_eid: str,
                                                     worksheet_name: str) -> Union[List[str], ErrorList]:
    return _get_experiment_worksheet_ids_by_name_handle_response(
        await rest_client.invoke_rest_get_async(f"entities/{experiment_eid}/children", EntityDescriptorList, True),
        worksheet_name)


def get_worksheet(rest_client: IRestClient, worksheet_eid: str) -> Union[Worksheet, ErrorList]:
    return rest_client.invoke_rest_get(f"worksheet/{worksheet_eid}", Worksheet)


async def get_worksheet_async(rest_client: IRestClientAsync, worksheet_eid: str) -> Union[Worksheet, ErrorList]:
    return await rest_client.invoke_rest_get_async(f"worksheet/{worksheet_eid}", Worksheet)


def get_worksheet_fields_definition(rest_client: IRestClient, worksheet_eid: str) -> List[FieldDefinition]:
    field_defs = next(
        filter(lambda x: x.type == 'worksheetFieldsDefinition', get_worksheet(rest_client, worksheet_eid).included))
    return field_defs.attributes.fieldsDefinition


async def get_worksheet_fields_definition_async(rest_client: IRestClientAsync, worksheet_eid: str) \
        -> List[FieldDefinition]:
    field_defs = next(
        filter(lambda x: x.type == 'worksheetFieldsDefinition',
               (await get_worksheet_async(rest_client, worksheet_eid)).included))
    return field_defs.attributes.fieldsDefinition


def update_worksheet(rest_client: IRestClient, worksheet_eid: str, field_values: List[Tuple[str, InputValueTypes]]) -> \
        Union[Worksheet, ErrorList]:
    mapped_fields = dict(map(lambda x: (x.title, x), get_worksheet_fields_definition(rest_client, worksheet_eid)))
    update_reg = WorksheetUpdateRequest.create(worksheet_eid, list(
        map(lambda x: (mapped_fields[x[0]].key, mapped_fields[x[0]].type, x[1]), field_values)))
    return rest_client.invoke_rest_patch(f"worksheet/{worksheet_eid}?force=true", update_reg, Worksheet)


async def update_worksheet_async(rest_client: IRestClientAsync, worksheet_eid: str,
                                 field_values: List[Tuple[str, InputValueTypes]]) -> Union[Worksheet, ErrorList]:
    mapped_fields = dict(map(lambda x: (x.title, x), await get_worksheet_fields_definition_async(rest_client,
                                                                                                 worksheet_eid)))
    update_reg = WorksheetUpdateRequest.create(worksheet_eid, list(
        map(lambda x: (mapped_fields[x[0]].key, mapped_fields[x[0]].type, x[1]), field_values)))
    return await rest_client.invoke_rest_patch_async(f"worksheet/{worksheet_eid}?force=true", update_reg, Worksheet)
