from typing import Dict, List, Tuple, Union
from LuPySNB.model.DTOs.FieldDefinition import FieldDefinition
from LuPySNB.model.DTOs.MaterialFieldValue import InputTypes
from LuPySNB.model.exceptions.LuPySNBException import LuPySNBException
from LuPySNB.API import MaterialLibrary
from LuPySNB.API.IRestClient import IRestClient
from LuPySNB.API.IRestClientAsync import IRestClientAsync
from LuPySNB.model.DTOs.Query import QueryIn, QueryDateRange, NotQueryTerm, QueryExists
from LuPySNB.model.requests.CreateContainerRequest import CreateContainerRequest
from LuPySNB.model.responses.EntityDescriptorList import EntityDescriptorListFromQuery
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.ContainerTypeResponse import ContainerTypeResponseList
from LuPySNB.model.DTOs.Query import QueryMatch, AndQueryTerm, Query, QueryChild, QueryPrefix
from LuPySNB.model.DTOs.ContainerType import ContainerType
from LuPySNB.model.responses.ContainerResponse import ContainerResponse
from LuPySNB.model.responses.CreateContainerResponse import CreateContainerResponse
from LuPySNB.model.requests.ContainerUpdateRequest import ContainerUpdateRequest
from LuPySNB.model.requests.ContainerAmountUpdateRequest import ContainerAmountUpdateRequest
from LuPySNB.model.requests.ContainerStatusUpdateRequest import ContainerStatusUpdateRequest


def _get_containers_by_type_build_query(container_type: str) -> Query:
    return Query(query=AndQueryTerm.create(
        [
            QueryIn[str].create('type', ['container'], 'keyword'),
            QueryMatch[str].create('container.Container Type', container_type, 'keyword', 'text', 'tags')
        ]))


def get_containers_by_type(rest_client: IRestClient, container_type: str) \
        -> EntityDescriptorListFromQuery:
    query = _get_containers_by_type_build_query(container_type)
    return rest_client.invoke_rest_post('entities/search?source=IVT', query, EntityDescriptorListFromQuery, True)


async def get_containers_by_type_async(rest_client: IRestClientAsync, container_type: str) \
        -> EntityDescriptorListFromQuery:
    query = _get_containers_by_type_build_query(container_type)
    return await rest_client.invoke_rest_post_async('entities/search?source=IVT', query, EntityDescriptorListFromQuery,
                                                    True)


def _get_containers_by_name_build_query(container_names: List[str]) -> Query:
    return Query(query=AndQueryTerm.create(
        [
            QueryIn[str].create('type', ['container'], 'keyword'),
            QueryIn[str].create('name', container_names, 'keyword', 'text')
        ]))


def get_containers_by_name(rest_client: IRestClient, container_names: List[str]) \
        -> EntityDescriptorListFromQuery:
    query = _get_containers_by_name_build_query(container_names)
    return rest_client.invoke_rest_post('entities/search?source=IVT', query, EntityDescriptorListFromQuery, True)


async def get_containers_by_name_async(rest_client: IRestClientAsync, container_names: List[str]) \
        -> EntityDescriptorListFromQuery:
    query = _get_containers_by_name_build_query(container_names)
    return await rest_client.invoke_rest_post_async('entities/search?source=IVT', query, EntityDescriptorListFromQuery,
                                                    True)


def _get_containers_by_status_and_days_since_edited_build_query(reagents_library_eid: str, status: str,
                                                                days_since_edited: int) -> Query:
    return Query(query=AndQueryTerm.create(
        [
            QueryMatch[str].create('type', 'container', 'keyword'),
            QueryChild[str].create(
                QueryIn[str].create('assetTypeEid', [reagents_library_eid], 'keyword')),
            QueryMatch[str].create('fields.Status', status, 'keyword', 'text', 'tags'),
            QueryDateRange[int].create('modifiedAt', f'now-{days_since_edited}d/d', 'now/d', 'range', 'date')
        ]))


def get_containers_by_status_and_days_since_edited(rest_client: IRestClient, material_library_name: str, status: str,
                                                   days_since_edited: int) -> EntityDescriptorListFromQuery:
    reagents_library = MaterialLibrary.get_material_library_by_name(rest_client, material_library_name)
    reagents_library_eid = f'assetType:{reagents_library.id}'
    query = _get_containers_by_status_and_days_since_edited_build_query(reagents_library_eid, status, days_since_edited)
    return rest_client.invoke_rest_post('entities/search?source=IVT', query, EntityDescriptorListFromQuery, True)


async def get_containers_by_status_and_days_since_edited_async(rest_client: IRestClientAsync,
                                                               material_library_name: str, status: str,
                                                               days_since_edited: int) -> EntityDescriptorListFromQuery:
    reagents_library = await MaterialLibrary.get_material_library_by_name_async(rest_client, material_library_name)
    reagents_library_eid = f'assetType:{reagents_library.id}'
    query = _get_containers_by_status_and_days_since_edited_build_query(reagents_library_eid, status, days_since_edited)
    return await rest_client.invoke_rest_post_async('entities/search?source=IVT', query, EntityDescriptorListFromQuery,
                                                    True)


def get_container(rest_client: IRestClient, container_id: str) -> ContainerResponse | ErrorList:
    return rest_client.invoke_rest_get(f'inventory/containers/{container_id}', ContainerResponse)


async def get_container_async(rest_client: IRestClientAsync, container_id: str) -> ContainerResponse | ErrorList:
    return await rest_client.invoke_rest_get_async(f'inventory/containers/{container_id}', ContainerResponse)


def get_container_types(rest_client: IRestClient) -> ContainerTypeResponseList:
    return rest_client.invoke_rest_get(f'inventory/types/?entityType=container', ContainerTypeResponseList)


async def get_container_types_async(rest_client: IRestClientAsync) -> ContainerTypeResponseList:
    return await rest_client.invoke_rest_get_async(f'inventory/types/?entityType=container', ContainerTypeResponseList)


def get_container_type_by_name(rest_client: IRestClient, container_type_name: str) -> ContainerType:
    container_types = get_container_types(rest_client)
    for container_type in container_types.data:
        if container_type.attributes.name == container_type_name:
            return container_type
    raise LuPySNBException(f"Container type with name {container_type_name} not found")


async def get_container_type_by_name_async(rest_client: IRestClientAsync,
                                           container_type_name: str) -> ContainerType:
    container_types = await get_container_types_async(rest_client)
    for container_type in container_types.data:
        if container_type.attributes.name == container_type_name:
            return container_type
    raise LuPySNBException(f"Container type with name {container_type_name} not found")


def get_container_type_by_id(rest_client: IRestClient, container_type_id: str) -> ContainerType:
    container_types = get_container_types(rest_client)
    for container_type in container_types.data:
        if container_type.id == container_type_id:
            return container_type
    raise LuPySNBException(f"Container type with id {container_type_id} not found")


async def get_container_type_by_id_async(rest_client: IRestClientAsync,
                                         container_type_id: str) -> ContainerType:
    container_types = await get_container_types_async(rest_client)
    for container_type in container_types.data:
        if container_type.id == container_type_id:
            return container_type
    raise LuPySNBException(f"Container type with id {container_type_id} not found")


def get_container_type_field_map(rest_client: IRestClient, container_type_name: str) -> Dict[str, FieldDefinition]:
    container_type = get_container_type_by_name(rest_client, container_type_name)
    return container_type.get_field_map()


async def get_container_type_field_map_async(rest_client: IRestClientAsync, container_type_name: str) \
        -> Dict[str, FieldDefinition]:
    container_type = await get_container_type_by_name_async(rest_client, container_type_name)
    return container_type.get_field_map()


def get_container_type_field_map_by_id(rest_client: IRestClient, container_type_id: str) -> Dict[str, FieldDefinition]:
    container_type = get_container_type_by_id(rest_client, container_type_id)
    return container_type.get_field_map()


async def get_container_type_field_map_by_id_async(rest_client: IRestClientAsync, container_type_id: str) \
        -> Dict[str, FieldDefinition]:
    container_type = await get_container_type_by_id_async(rest_client, container_type_id)
    return container_type.get_field_map()


def update_container(rest_client: IRestClient, container_eid: str, digest: str,
                     field_values: List[Tuple[str, InputTypes]]) -> ContainerResponse | ErrorList:
    container = get_container(rest_client, container_eid)
    container_type_id = container.data.attributes.typeId
    field_map = get_container_type_field_map_by_id(rest_client, container_type_id)
    update_req = ContainerUpdateRequest.create(field_values, field_map)
    return rest_client.invoke_rest_patch(f"/inventory/containers/{container_eid}?digest={digest}&force=false",
                                         update_req, ContainerResponse)


async def update_container_async(rest_client: IRestClientAsync, container_eid: str, digest: str,
                                 field_values: List[Tuple[str, InputTypes]]) -> ContainerResponse | ErrorList:
    container = await get_container_async(rest_client, container_eid)

    container_type_id = container.data.attributes.typeId
    field_map = await get_container_type_field_map_by_id_async(rest_client, container_type_id)
    update_req = ContainerUpdateRequest.create(field_values, field_map)

    return await rest_client.invoke_rest_patch_async(
        f"/inventory/containers/{container_eid}?digest={digest}&force=false",
        update_req, ContainerResponse)


def create_container(rest_client: IRestClient, container_type_eid: str, amount: float, location_eid: str,
                     barcode: str, content_eid: str, field_values: List[Tuple[str, InputTypes]],
                     field_map: Dict[str, FieldDefinition],
                     coordinate_x: int | None = None, coordinate_y: int | None = None, unit: str = 'g') \
        -> CreateContainerResponse | ErrorList:
    body = CreateContainerRequest.create(container_type_eid, amount, location_eid, coordinate_x, coordinate_y, barcode,
                                         content_eid, field_values, field_map, unit)
    return rest_client.invoke_rest_post(f"/inventory/containers", body, CreateContainerResponse)


async def create_container_async(rest_client: IRestClientAsync, container_type_eid: str, amount: float,
                                 location_eid: str, barcode: str, content_eid: str,
                                 field_values: List[Tuple[str, InputTypes]], field_map: Dict[str, FieldDefinition],
                                 coordinate_x: int | None = None, coordinate_y: int | None = None, unit: str = 'g') \
        -> CreateContainerResponse | ErrorList:
    body = CreateContainerRequest.create(container_type_eid, amount, location_eid, coordinate_x, coordinate_y, barcode,
                                         content_eid, field_values, field_map, unit)
    return await rest_client.invoke_rest_post_async(f"/inventory/containers", body, CreateContainerResponse)


def get_value_for_field(container, field_name):
    value = None
    for f in container.data.attributes.fields:
        if f.definition.title == field_name:
            if f.content is not None and f.content.value is not None:
                value = f.content.value
    return value


def update_amount(rest_client: IRestClient, container_eid: str, digest: str | None, amount: float, unit: str = 'g') \
        -> ContainerResponse | ErrorList:
    if digest is None:
        endpoint = f'/inventory/containers/{container_eid}/amount?force=true'
    else:
        endpoint = f'/inventory/containers/{container_eid}/amount?digest={digest}&force=false'
    update_body = ContainerAmountUpdateRequest.create(f'{amount} {unit}')
    return rest_client.invoke_rest_patch(endpoint, update_body, ContainerResponse)


async def update_amount_async(rest_client: IRestClientAsync, container_eid: str, digest: str | None, amount: float, unit: str = 'g') \
        -> ContainerResponse | ErrorList:
    if digest is None:
        endpoint = f'/inventory/containers/{container_eid}/amount?force=true'
    else:
        endpoint = f'/inventory/containers/{container_eid}/amount?digest={digest}&force=false'
    update_body = ContainerAmountUpdateRequest.create(f'{amount} {unit}')
    return await rest_client.invoke_rest_patch_async(endpoint, update_body, ContainerResponse)


def update_container_status(rest_client: IRestClient, container_eid: str, action: str, force: bool,
                            digest: str | None = None, location_eid: str | None = None, user_id: str | None = '',
                            coordinate_x: int | None = None, coordinate_y: int | None = None) \
        -> Union[ContainerResponse, ErrorList]:
    if user_id is None:
        user_id = ''

    if action in ('dispose', 'finalDispose', 'restore'):
        update_status_body = None
    else:
        update_status_body = ContainerStatusUpdateRequest.create(location_eid, coordinate_x, coordinate_y, user_id)

    force = str(force).lower()
    if force == 'true':
        endpoint = f"/inventory/containers/{container_eid}/status/{action}?force={force}"
    else:
        endpoint = f"/inventory/containers/{container_eid}/status/{action}?digest={digest}&force={force}"

    return rest_client.invoke_rest_post(endpoint, update_status_body, ContainerResponse)


async def update_container_status_async(rest_client: IRestClientAsync, container_eid: str, action: str, force: bool,
                                        digest: str | None = None,
                                        location_eid: str | None = None, user_id: str | None = '',
                                        coordinate_x: int | None = None, coordinate_y: int | None = None) \
        -> ContainerResponse | ErrorList:
    if user_id is None:
        user_id = ''

    if action in ('dispose', 'finalDispose', 'restore'):
        update_status_body = None
    else:
        update_status_body = ContainerStatusUpdateRequest.create(location_eid, coordinate_x, coordinate_y, user_id)

    force = str(force).lower()
    if force == 'true':
        endpoint = f"/inventory/containers/{container_eid}/status/{action}?force={force}"
    else:
        endpoint = f"/inventory/containers/{container_eid}/status/{action}?digest={digest}&force={force}"

    return await rest_client.invoke_rest_post_async(endpoint, update_status_body, ContainerResponse)


def _get_disposed_containers_outside_bin_build_query(bin_path: str) -> Query:
    return Query(query=AndQueryTerm.create(
        [
            QueryMatch[str].create('type', 'container', 'keyword'),
            NotQueryTerm.create([QueryMatch[str].create('fields.Path', bin_path, 'keyword', 'text', 'tags')]),
            QueryExists.create('fields.Path', 'text', 'tags'),
            QueryMatch[str].create('fields.Status', 'DISPOSED', 'keyword', 'text', 'tags'),
            AndQueryTerm.create([
                QueryMatch[str].create('isTemplate', 'false'),
                NotQueryTerm.create([QueryMatch[str].create('type', 'assetType')]),
            ])
        ]))


def get_disposed_containers_outside_bin(rest_client: IRestClient, bin_path: str) -> EntityDescriptorListFromQuery:
    query = _get_disposed_containers_outside_bin_build_query(bin_path)
    return rest_client.invoke_rest_post('entities/search?source=IVT', query, EntityDescriptorListFromQuery,
                                        True)


async def get_disposed_containers_outside_bin_async(rest_client: IRestClientAsync,
                                                    bin_path: str) -> EntityDescriptorListFromQuery:
    query = _get_disposed_containers_outside_bin_build_query(bin_path)
    return await rest_client.invoke_rest_post_async('entities/search?source=IVT', query, EntityDescriptorListFromQuery,
                                                    True)


def _get_container_by_barcode_query(barcode) -> Query:
    return Query(query=AndQueryTerm.create(
        [
            QueryMatch[str].create('type', 'container', 'keyword'),
            QueryMatch[str].create('fields.Barcode', barcode, 'keyword', 'text', 'tags')
        ]))


def get_container_by_barcode(rest_client: IRestClient, barcode: str) -> EntityDescriptorListFromQuery:
    query = _get_container_by_barcode_query(barcode)
    return rest_client.invoke_rest_post('entities/search?source=IVT', query, EntityDescriptorListFromQuery,
                                        True)


async def get_container_by_barcode_async(rest_client: IRestClientAsync, barcode: str) -> EntityDescriptorListFromQuery:
    query = _get_container_by_barcode_query(barcode)
    return await rest_client.invoke_rest_post_async('entities/search?source=IVT', query, EntityDescriptorListFromQuery,
                                                    True)


def _get_containers_by_path_status_and_days_since_created_query(days_since_created: int, path: str,
                                                                reagents_library_eid: str, status: str) -> Query:
    return Query(query=AndQueryTerm.create(
        [
            QueryMatch[str].create('type', 'container', 'keyword'),
            QueryChild[str].create(
                QueryIn[str].create('assetTypeEid', ["assetType:" + reagents_library_eid], 'keyword')),
            QueryMatch[str].create('fields.Path', path, 'keyword', 'text', 'tags'),
            QueryMatch[str].create('fields.Status', status, 'keyword', 'text', 'tags'),
            QueryDateRange[int].create('createdAt', '1970-01-01', f'now-{days_since_created + 1}d/d', 'range', 'date')
        ]))


def get_containers_by_path_status_and_days_since_created(rest_client: IRestClient, material_library_name: str,
                                                         path: str, status: str,
                                                         days_since_created: int) -> EntityDescriptorListFromQuery:
    reagents_library_eid = (MaterialLibrary.get_material_library_by_name(rest_client, material_library_name)).id
    query = _get_containers_by_path_status_and_days_since_created_query(days_since_created, path, reagents_library_eid,
                                                                        status)
    return rest_client.invoke_rest_post('entities/search?source=IVT', query, EntityDescriptorListFromQuery,
                                        True)


async def get_containers_by_path_status_and_days_since_created_async(rest_client: IRestClientAsync,
                                                                     material_library_name: str, path: str, status: str,
                                                                     days_since_created: int) -> EntityDescriptorListFromQuery:
    reagents_library_eid = (
        await MaterialLibrary.get_material_library_by_name_async(rest_client, material_library_name)).id
    query = _get_containers_by_path_status_and_days_since_created_query(days_since_created, path, reagents_library_eid,
                                                                        status)
    return await rest_client.invoke_rest_post_async('entities/search?source=IVT', query, EntityDescriptorListFromQuery,
                                                    True)


def _get_containers_by_prefix_path_and_status_query(library_eid: str, prefix_path: str | None, status: list[str]) -> Query:
    query = [
        QueryMatch[str].create('type', 'container', 'keyword'),
        QueryChild[str].create(
            QueryMatch[str].create('assetTypeEid', 'assetType:' + library_eid, 'keyword')
        )
    ]
    if prefix_path:
        query.append(QueryPrefix[str].create('fields.Path', prefix_path, 'keyword', 'text', 'tags'))
    query.append(QueryIn[str].create('fields.Status', status, 'keyword', 'text', 'tags'))
    
    return Query(query=AndQueryTerm.create(query))


def get_containers_by_prefix_path_and_status(
        rest_client: IRestClient,
        library_eid: str,
        prefix_path: str | None,
        status: list[str]
        ) -> EntityDescriptorListFromQuery:
    query = _get_containers_by_prefix_path_and_status_query(library_eid, prefix_path, status)
    return rest_client.invoke_rest_post('entities/search?source=IVT', query, EntityDescriptorListFromQuery, True)


async def get_containers_by_prefix_path_and_status_async(
        rest_client: IRestClientAsync,
        library_eid: str,
        prefix_path: str | None,
        status: list[str]
        ) -> EntityDescriptorListFromQuery:
    query = _get_containers_by_prefix_path_and_status_query(library_eid, prefix_path, status)
    return await rest_client.invoke_rest_post_async('entities/search?source=IVT', query, EntityDescriptorListFromQuery, True)


def _get_containers_by_content_and_status_query(library_eid: str, content_name: list[str], status: list[str] | None) -> Query:
    query = [
        QueryMatch[str].create('type', 'container', 'keyword'),
        QueryChild[str].create(
            QueryMatch[str].create('assetTypeEid', 'assetType:' + library_eid, 'keyword')),
        QueryIn[str].create('container.Contents Name', content_name, 'keyword', 'text', 'tags')
    ]
    if status is not None:
        query.append(QueryIn[str].create('fields.Status', status, 'keyword', 'text', 'tags'))
    return Query(query=AndQueryTerm.create(query))


def get_containers_by_content_and_status(
        rest_client: IRestClient,
        library_eid: str,
        content_name: list[str],
        status: list[str] | None
        ) -> EntityDescriptorListFromQuery:
    query = _get_containers_by_content_and_status_query(library_eid, content_name, status)
    return rest_client.invoke_rest_post('entities/search?source=IVT', query, EntityDescriptorListFromQuery, True)


async def get_containers_by_content_and_status_async(
        rest_client: IRestClientAsync,
        library_eid: str,
        content_name: list[str],
        status: list[str] | None
        ) -> EntityDescriptorListFromQuery:
    query = _get_containers_by_content_and_status_query(library_eid, content_name, status)
    return await rest_client.invoke_rest_post_async('entities/search?source=IVT', query, EntityDescriptorListFromQuery, True)


def _get_containers_by_barcode_prefix_query(barcode_prefix: str) -> Query:
    return Query(query=AndQueryTerm.create(
        [
            QueryMatch[str].create('type', 'container', 'keyword'),
            QueryPrefix[str].create('fields.Barcode', barcode_prefix, 'keyword', 'text', 'tags')
        ]))


def get_containers_by_barcode_prefix(
        rest_client: IRestClient,
        barcode_prefix: str
        ) -> EntityDescriptorListFromQuery:
    query = _get_containers_by_barcode_prefix_query(barcode_prefix)
    return rest_client.invoke_rest_post('entities/search?source=IVT', query, EntityDescriptorListFromQuery, True)


async def get_containers_by_barcode_prefix_async(
        rest_client: IRestClientAsync,
        barcode_prefix: str
        ) -> EntityDescriptorListFromQuery:
    query = _get_containers_by_barcode_prefix_query(barcode_prefix)
    return await rest_client.invoke_rest_post_async('entities/search?source=IVT', query, EntityDescriptorListFromQuery, True)
