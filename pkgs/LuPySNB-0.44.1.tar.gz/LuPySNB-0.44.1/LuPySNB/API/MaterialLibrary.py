from typing import Union, List, Any
from typing import Optional
from io import BytesIO

from LuPySNB.API.Entity import update_entity_properties_by_id, update_entity_properties_by_id_async
from LuPySNB.API.IRestClient import IRestClient
from LuPySNB.API.IRestClientAsync import IRestClientAsync
from LuPySNB.model.DTOs.MaterialLibraryDescriptor import MaterialLibraryDescriptor
from LuPySNB.model.DTOs.Query import Query, QueryIn, AndQueryTerm
from LuPySNB.model.requests.CreateEntityRequest import CreateEntityRequest
from LuPySNB.model.requests.MaterialAssetRequest import MaterialAssetRequest, MaterialAssetRequestList
from LuPySNB.model.requests.MaterialBatchRequest import MaterialBatchRequest
from LuPySNB.model.requests.MaterialsTableRequest import MaterialsTableAddRowRequest,\
    MaterialsTableAddMultipleRowRequest
from LuPySNB.model.requests.UpdateMaterialPropertiesRequest import UpdateMaterialPropertiesRequest
from LuPySNB.model.responses.CreateEntityResponse import CreateEntityResponse
from LuPySNB.model.responses.EntityDescriptorList import EntityDescriptorListFromQuery
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.MaterialAssetResponse import MaterialAssetResponse, MaterialAssetResponseList
from LuPySNB.model.responses.MaterialBulkImportResponse import MaterialBulkImportResponse
from LuPySNB.model.responses.MaterialLibraryList import MaterialLibraryList
from LuPySNB.model.responses.MaterialsTable import MaterialsTableRow, MaterialsTable
from LuPySNB.model.responses.UpdateMaterialPropertiesResponse import UpdateMaterialPropertiesResponse
from LuPySNB.model.exceptions.LuPySNBInternalException import LuPySNBInternalException


def get_material_libraries(rest_client: IRestClient) -> Union[MaterialLibraryList, ErrorList]:
    return rest_client.invoke_rest_get('materials/libraries', MaterialLibraryList)


async def get_material_libraries_async(rest_client: IRestClientAsync) -> Union[MaterialLibraryList, ErrorList]:
    return await rest_client.invoke_rest_get_async('materials/libraries', MaterialLibraryList)


def _get_material_library_by_name_handle_response(response: Any, library_name: str) \
        -> Union[Optional[MaterialLibraryDescriptor], ErrorList]:
    if isinstance(response, MaterialLibraryList):
        matches = list(filter(lambda x: x.attributes.name == library_name, response.data))
        if len(matches) == 0:
            return None
        elif len(matches) == 1:
            return matches[0]
        else:
            raise LuPySNBInternalException(f'Material Library Name {library_name} is not unique')
    else:
        return response


def get_material_library_by_name(rest_client: IRestClient, library_name: str) \
        -> Union[Optional[MaterialLibraryDescriptor], ErrorList]:
    return _get_material_library_by_name_handle_response(get_material_libraries(rest_client), library_name)


async def get_material_library_by_name_async(rest_client: IRestClientAsync, library_name: str) \
        -> Union[Optional[MaterialLibraryDescriptor], ErrorList]:
    return _get_material_library_by_name_handle_response(await get_material_libraries_async(rest_client), library_name)


def get_material(rest_client: IRestClient, material_eid: str) -> Union[MaterialAssetResponse, ErrorList]:
    return rest_client.invoke_rest_get(f'materials/{material_eid}', MaterialAssetResponse)


async def get_material_async(rest_client: IRestClientAsync, material_eid: str) -> Union[MaterialAssetResponse, ErrorList]:
    return await rest_client.invoke_rest_get_async(f'materials/{material_eid}', MaterialAssetResponse)


def get_material_field_values(rest_client: IRestClient, material: str | MaterialAssetResponse,
                              pattern: str) -> str | ErrorList:
    """Return a material field value, recursively following dotted links."""
    if isinstance(material, str):
        material = get_material(rest_client, material)

    if isinstance(material, ErrorList):
        return material

    field_name, separator, remaining_pattern = pattern.partition('.')
    value = material.data.attributes.fields[field_name].value

    if separator:
        linked_material = get_material(rest_client, value.eid)
        return get_material_field_values(rest_client, linked_material, remaining_pattern)

    return value.display_value if hasattr(value, 'display_value') else str(value)


async def get_material_field_values_async(rest_client: IRestClientAsync,
                                          material: str | MaterialAssetResponse,
                                          pattern: str) -> str | ErrorList:
    """Async version of :func:`get_material_field_values`."""
    if isinstance(material, str):
        material = await get_material_async(rest_client, material)

    if isinstance(material, ErrorList):
        return material

    field_name, separator, remaining_pattern = pattern.partition('.')
    value = material.data.attributes.fields[field_name].value

    if separator:
        linked_material = await get_material_async(rest_client, value.eid)
        return await get_material_field_values_async(rest_client, linked_material, remaining_pattern)

    return value.display_value if hasattr(value, 'display_value') else str(value)


def _get_assets_by_name_build_query(library_eid: str, asset_names: List[str]) -> Query:
    return Query(query=AndQueryTerm.create(
        [QueryIn[str].create('assetTypeEid', ['assetType:' + library_eid], 'keyword'),
         QueryIn[str].create('name', asset_names, 'keyword', 'text')]))


def get_assets_by_name(rest_client: IRestClient, library_eid: str, asset_names: List[str]) \
        -> EntityDescriptorListFromQuery:
    query = _get_assets_by_name_build_query(library_eid, asset_names)
    return rest_client.invoke_rest_post('entities/search?source=SN', query, EntityDescriptorListFromQuery, True)


async def get_assets_by_name_async(rest_client: IRestClientAsync, library_eid: str, asset_names: List[str]) \
        -> EntityDescriptorListFromQuery:
    query = _get_assets_by_name_build_query(library_eid, asset_names)
    return await rest_client.invoke_rest_post_async('entities/search?source=SN', query, EntityDescriptorListFromQuery,
                                                    True)


def _get_assets_by_tag_build_query(library_eid: str, tag: str, tag_values: List[str]) -> Query:
    return Query(query=AndQueryTerm.create(
        [QueryIn[str].create('assetTypeEid', ['assetType:' + library_eid], 'keyword'),
         QueryIn[str].create('materials.' + tag, tag_values, 'keyword', 'text', 'tags')]))


def get_assets_by_tag(rest_client: IRestClient, library_eid: str, tag: str, tag_values: List[str]) \
        -> EntityDescriptorListFromQuery:
    query = _get_assets_by_tag_build_query(library_eid, tag, tag_values)
    return rest_client.invoke_rest_post('entities/search?source=SN', query, EntityDescriptorListFromQuery, True)


async def get_assets_by_tag_async(rest_client: IRestClientAsync, library_eid: str, tag: str, tag_values: List[str]) \
        -> EntityDescriptorListFromQuery:
    query = _get_assets_by_tag_build_query(library_eid, tag, tag_values)
    return await rest_client.invoke_rest_post_async('entities/search?source=SN', query, EntityDescriptorListFromQuery,
                                                    True)


def get_asset(rest_client: IRestClient, library_name: str, asset_id: str) -> Union[MaterialAssetResponse, ErrorList]:
    return rest_client.invoke_rest_get(f'materials/{library_name}/assets/id/{asset_id}',
                                       MaterialAssetResponse)


async def get_asset_async(rest_client: IRestClientAsync, library_name: str, asset_id: str) \
        -> Union[MaterialAssetResponse, ErrorList]:
    return await rest_client.invoke_rest_get_async(f'materials/{library_name}/assets/id/{asset_id}',
                                                   MaterialAssetResponse)


def get_batch(rest_client: IRestClient, library_name: str, batch_id: str) -> Union[MaterialAssetResponse, ErrorList]:
    return rest_client.invoke_rest_get(f'materials/{library_name}/batches/id/{batch_id}',
                                       MaterialAssetResponse)


async def get_batch_async(rest_client: IRestClientAsync, library_name: str, batch_id: str) \
        -> Union[MaterialAssetResponse, ErrorList]:
    return await rest_client.invoke_rest_get_async(f'materials/{library_name}/batches/id/{batch_id}',
                                                   MaterialAssetResponse)


def get_batches(rest_client: IRestClient, library_name: str, asset_id: str) \
        -> Union[MaterialAssetResponseList, ErrorList]:
    return rest_client.invoke_rest_get(f'materials/{library_name}/assets/{asset_id}/batches',
                                       MaterialAssetResponseList)


async def get_batches_async(rest_client: IRestClientAsync, library_name: str, asset_id: str) \
        -> Union[MaterialAssetResponseList, ErrorList]:
    return await rest_client.invoke_rest_get_async(f'materials/{library_name}/assets/{asset_id}/batches',
                                                   MaterialAssetResponseList)


def unique_check_asset(rest_client: IRestClient, library_name: str, asset_request: MaterialAssetRequest) \
        -> [MaterialAssetResponseList, ErrorList]:
    return rest_client.invoke_rest_post(f'materials/{library_name}/assets/uniquenessCheck', asset_request,
                                        MaterialAssetResponseList)


async def unique_check_asset_async(rest_client: IRestClientAsync, library_name: str,
                                   asset_request: MaterialAssetRequest) -> [MaterialAssetResponseList, ErrorList]:
    return await rest_client.invoke_rest_post_async(f'materials/{library_name}/assets/uniquenessCheck', asset_request,
                                                    MaterialAssetResponseList)


def create_asset(rest_client: IRestClient, library_name: str, asset_request: MaterialAssetRequest) \
        -> [MaterialAssetResponse, ErrorList]:
    return rest_client.invoke_rest_post(f'materials/{library_name}/assets', asset_request,
                                        MaterialAssetResponse)


async def create_asset_async(rest_client: IRestClientAsync, library_name: str, asset_request: MaterialAssetRequest) \
        -> [MaterialAssetResponse, ErrorList]:
    return await rest_client.invoke_rest_post_async(f'materials/{library_name}/assets', asset_request,
                                                    MaterialAssetResponse)


def create_asset_bulk(rest_client: IRestClient, library_name: str, rule: str,
                      asset_requests: MaterialAssetRequestList) -> Union[MaterialBulkImportResponse, ErrorList]:
    return rest_client.invoke_rest_post(f'materials/{library_name}/bulkImport?rule={rule}&importType=json',
                                        asset_requests, MaterialBulkImportResponse)


async def create_asset_bulk_async(rest_client: IRestClientAsync, library_name: str, rule: str,
                                  asset_requests: MaterialAssetRequestList) \
        -> Union[MaterialBulkImportResponse, ErrorList]:
    return await rest_client.invoke_rest_post_async(f'materials/{library_name}/bulkImport?rule={rule}&importType=json',
                                                    asset_requests, MaterialBulkImportResponse)


def create_asset_bulk_sdf(rest_client: IRestClient, library_name: str, rule: str, zipped_sdf: BytesIO) \
        -> Union[MaterialBulkImportResponse, ErrorList]:
    return rest_client.invoke_rest_post_file(f'materials/{library_name}/bulkImport?rule={rule}&importType=zip',
                                             'application/x-zip', zipped_sdf, MaterialBulkImportResponse)


async def create_asset_bulk_sdf_async(rest_client: IRestClientAsync, library_name: str, rule: str,
                                      zipped_sdf: BytesIO) \
        -> Union[MaterialBulkImportResponse, ErrorList]:
    return await rest_client.invoke_rest_post_file_async(
        f'materials/{library_name}/bulkImport?rule={rule}&importType=zip',
        'application/x-zip', zipped_sdf, MaterialBulkImportResponse)


def get_bulk_create_report(rest_client: IRestClient, job_id: str) -> Union[MaterialBulkImportResponse, ErrorList]:
    return rest_client.invoke_rest_get(f'materials/bulkImport/jobs/{job_id}', MaterialBulkImportResponse)


async def get_bulk_create_report_async(rest_client: IRestClientAsync, job_id: str) \
        -> Union[MaterialBulkImportResponse, ErrorList]:
    return await rest_client.invoke_rest_get_async(f'materials/bulkImport/jobs/{job_id}', MaterialBulkImportResponse)


def create_batch(rest_client: IRestClient, library_name: str, asset_id: str, batch_request: MaterialBatchRequest) \
        -> [MaterialAssetResponse, ErrorList]:
    return rest_client.invoke_rest_post(f'materials/{library_name}/assets/{asset_id}/batches', batch_request,
                                        MaterialAssetResponse)


async def create_batch_async(rest_client: IRestClientAsync, library_name: str, asset_id: str,
                             batch_request: MaterialBatchRequest) -> [MaterialAssetResponse, ErrorList]:
    return await rest_client.invoke_rest_post_async(f'materials/{library_name}/assets/{asset_id}/batches',
                                                    batch_request, MaterialAssetResponse)


def update_material_properties(rest_client: IRestClient, eid: str, update_request: UpdateMaterialPropertiesRequest) \
        -> [UpdateMaterialPropertiesResponse]:
    return rest_client.invoke_rest_patch(f'materials/{eid}/properties?force=true', update_request,
                                         UpdateMaterialPropertiesResponse)


async def update_material_properties_async(rest_client: IRestClientAsync, eid: str,
                                           update_request: UpdateMaterialPropertiesRequest) \
        -> [UpdateMaterialPropertiesResponse]:
    return await rest_client.invoke_rest_patch_async(f'materials/{eid}/properties?force=true', update_request,
                                                     UpdateMaterialPropertiesResponse)


def add_materials_table_row(rest_client: IRestClient, materials_table_id: str, material_id: str, cells: list | None = None) \
        -> Union[MaterialsTableRow, ErrorList]:
    ###
    # Add a row to a materials table.
    # :param rest_client: REST client to use
    # :param materials_table_id: The materials table ID
    # :param material_id: The material ID
    # :param cells: The additional columns to add
    # :return: The added row
    ###

    row_request = MaterialsTableAddRowRequest.create(material_id, cells)
    return rest_client.invoke_rest_post(f'materialsTable/{materials_table_id}?force=true', row_request,
                                        MaterialsTableRow)


async def add_materials_table_row_async(rest_client: IRestClientAsync, materials_table_id: str, material_id: str, cells: list | None = None) \
        -> Union[MaterialsTableRow, ErrorList]:
    ###
    # Add a row to a materials table.
    # :param rest_client: REST client to use
    # :param materials_table_id: The materials table ID
    # :param material_id: The material ID
    # :param cells: The additional columns to add
    # :return: The added row
    ###

    row_request = MaterialsTableAddRowRequest.create(material_id, cells)
    return await rest_client.invoke_rest_post_async(f'materialsTable/{materials_table_id}?force=true', row_request,
                                               MaterialsTableRow)


def add_multiple_materials_table_row(rest_client: IRestClient, materials_table_id: str, material_ids: list, cells: list[list] | None = None) \
        -> Union[MaterialsTableRow, ErrorList]:
    ###
    # Add multiple rows to a materials table.
    # :param rest_client: REST client to use
    # :param materials_table_id: The materials table ID
    # :param material_ids: The list of material ID
    # :param cells: The additional columns to add
    # :return: The materials table
    ###

    row_request = MaterialsTableAddMultipleRowRequest.create(material_ids, cells)
    return rest_client.invoke_rest_patch(f'materialsTable/{materials_table_id}?force=true', row_request,
                                         MaterialsTable)


async def add_multiple_materials_table_row_async(rest_client: IRestClientAsync, materials_table_id: str, material_ids: list, cells: list[list] | None = None) \
        -> Union[MaterialsTableRow, ErrorList]:
    ###
    # Add multiple rows to a materials table.
    # :param rest_client: REST client to use
    # :param materials_table_id: The materials table ID
    # :param material_ids: The list of material ID
    # :param cells: The additional columns to add
    # :return: The materials table
    ###

    row_request = MaterialsTableAddMultipleRowRequest.create(material_ids, cells)
    return await rest_client.invoke_rest_patch_async(f'materialsTable/{materials_table_id}?force=true', row_request,
                                                     MaterialsTable)


def create_materials_table(rest_client: IRestClient, library_name: str, parent_eid: str, materials_table_name: str = None) -> Union[CreateEntityResponse, ErrorList]:
    materials_table = rest_client.invoke_rest_post(f'entities?force=true',
                                 CreateEntityRequest.create(None, parent_eid, {'libraryName': library_name},
                                                            'materialsTable'), CreateEntityResponse)
    if isinstance(materials_table, CreateEntityResponse):
        if materials_table_name is not None:
            update_name_res = update_entity_properties_by_id(rest_client, materials_table.data.id, [{'name': 'Name', 'value': materials_table_name}])
            if not isinstance(update_name_res, ErrorList):
                materials_table.data.attributes.name = materials_table_name
    return materials_table


async def create_materials_table_async(rest_client: IRestClientAsync, library_name: str, parent_eid: str, materials_table_name: str = None) -> Union[CreateEntityResponse, ErrorList]:
    materials_table = await rest_client.invoke_rest_post_async(f'entities?force=true',
                                 CreateEntityRequest.create(None, parent_eid, {'libraryName': library_name},
                                                            'materialsTable'), CreateEntityResponse)
    if isinstance(materials_table, CreateEntityResponse):
        if materials_table_name is not None:
            update_name_res = await update_entity_properties_by_id_async(rest_client, materials_table.data.id, [{'name': 'Name', 'value': materials_table_name}])
            if not isinstance(update_name_res, ErrorList):
                materials_table.data.attributes.name = materials_table_name
    return materials_table
