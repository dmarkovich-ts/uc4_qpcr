from typing import List, Dict, Optional, Union, Tuple
from LuPySNB.model.DTOs.MaterialFieldValue import InputTypes
from LuPySNB.API import IRestClientAsync
from LuPySNB.model.DTOs.FieldDefinition import FieldDefinition
from LuPySNB.model.DTOs.InventoryTypeDefinition import InventoryTypeDefinition
from LuPySNB.model.requests.CreateInventoryLocationRequest import CreateInventoryLocationRequest
from LuPySNB.model.requests.UpdateInventoryLocationRequest import UpdateInventoryLocationRequest
from LuPySNB.model.responses.InventoryLocationResponse import InventoryLocationResponse
from LuPySNB.model.responses.InventoryTypeResponse import InventoryTypeResponseList
from LuPySNB.API import IRestClient
from LuPySNB.model.exceptions.LuPySNBException import LuPySNBException
from LuPySNB.model.responses.EntityDescriptorList import EntityDescriptorListFromQuery
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.DTOs.Query import QueryMatch, AndQueryTerm, Query


def get_inventory_types(rest_client: IRestClient, entity_type: str) -> Union[InventoryTypeResponseList, ErrorList]:
    return rest_client.invoke_rest_get(f"inventory/types?entityType={entity_type}", InventoryTypeResponseList)


async def get_inventory_types_async(rest_client: IRestClientAsync, entity_type: str) \
        -> Union[InventoryTypeResponseList, ErrorList]:
    return await rest_client.invoke_rest_get_async(f"inventory/types?entityType={entity_type}",
                                                   InventoryTypeResponseList)


def get_inventory_types_by_name(rest_client: IRestClient, entity_type: str, inventory_type_name: str) \
        -> Union[List[InventoryTypeDefinition], ErrorList]:
    inventory_types = get_inventory_types(rest_client, entity_type)
    return list(filter(lambda x: x.attributes.name == inventory_type_name, inventory_types.data)) \
        if isinstance(inventory_types, InventoryTypeResponseList) else inventory_types


async def get_inventory_types_by_name_async(rest_client: IRestClientAsync, entity_type: str, inventory_type_name: str) \
        -> Union[List[InventoryTypeDefinition], ErrorList]:
    inventory_types = await get_inventory_types_async(rest_client, entity_type)
    return list(filter(lambda x: x.attributes.name == inventory_type_name, inventory_types.data)) \
        if isinstance(inventory_types, InventoryTypeResponseList) else inventory_types


def create_inventory_location(rest_client: IRestClient, name: str, barcode: Optional[str],
                              rows: Optional[int], columns: Optional[int], parent_id: Optional[str],
                              location_type_id: str, field_values: Dict[str, Union[str, List[str]]],
                              field_map: Dict[str, FieldDefinition]) -> InventoryLocationResponse:
    request = CreateInventoryLocationRequest.create(parent_id, name, barcode, rows, columns, location_type_id,
                                                    field_values, field_map)
    return rest_client.invoke_rest_post("inventory/locations", request, InventoryLocationResponse)


async def create_inventory_location_async(rest_client: IRestClientAsync, name: str, barcode: Optional[str],
                                          rows: Optional[int], columns: Optional[int], parent_id: Optional[str],
                                          location_type_id: str, field_values: List[Tuple[str, InputTypes]],
                                          field_map: Dict[str, FieldDefinition]) -> InventoryLocationResponse:
    request = CreateInventoryLocationRequest.create(parent_id, name, barcode, rows, columns, location_type_id,
                                                    field_values, field_map)
    return await rest_client.invoke_rest_post_async("inventory/locations", request, InventoryLocationResponse)


def update_inventory_location(rest_client: IRestClient, location_eid: str, digest: str,
                              field_values: List[Tuple[str, InputTypes]],
                              field_map: Dict[str, FieldDefinition]) -> InventoryLocationResponse:
    request = UpdateInventoryLocationRequest.create(field_values, field_map)
    return rest_client.invoke_rest_patch(f"inventory/locations/{location_eid}?digest={digest}&force=false", request,
                                         InventoryLocationResponse)


async def update_inventory_location_async(rest_client: IRestClientAsync, location_eid: str, digest: str,
                                          field_values: List[Tuple[str, InputTypes]],
                                          field_map: Dict[str, FieldDefinition]) -> InventoryLocationResponse:
    request = UpdateInventoryLocationRequest.create(field_values, field_map)
    return await rest_client.invoke_rest_patch_async(f"inventory/locations/{location_eid}?digest={digest}&force=false",
                                                     request, InventoryLocationResponse)


def _get_inventory_location_by_path_build_query(path_part, name_part):
    return Query(query=AndQueryTerm.create(
        [
            QueryMatch[str].create('type', 'location', 'keyword'),
            QueryMatch[str].create('fields.Path', path_part, 'keyword', 'text', 'tags'),
            QueryMatch[str].create('name', name_part, 'keyword', 'text')
        ]))


def get_inventory_location_by_path(rest_client: IRestClient, location_path: str) -> Union[
    InventoryLocationResponse, ErrorList]:
    if not location_path.startswith('/'):
        raise LuPySNBException(f"Location {location_path} must start with a leading slash.")
    location_nodes = location_path.split('/')
    path_part = location_nodes[1:-1]
    path_part = '/'.join(path_part)
    path_part = '/' + path_part
    name_part = location_nodes[-1]
    query = _get_inventory_location_by_path_build_query(path_part, name_part)
    query_result = rest_client.invoke_rest_post('entities/search?source=IVT', query, EntityDescriptorListFromQuery,
                                                True)
    if len(query_result.data) == 0:
        raise LuPySNBException(f"Location {location_path} not found")
    elif len(query_result.data) > 1:
        raise LuPySNBException(f"Multiple locations found for {location_path}")

    location_eid = query_result.data[0].id
    return get_inventory_location_by_eid(rest_client, location_eid)


async def get_inventory_location_by_path_async(rest_client: IRestClientAsync, location_path: str) -> Union[
    InventoryLocationResponse, ErrorList]:
    if not location_path.startswith('/'):
        raise LuPySNBException(f"Location {location_path} must start with a leading slash.")
    location_nodes = location_path.split('/')
    path_part = location_nodes[1:-1]
    path_part = '/'.join(path_part)
    path_part = '/' + path_part
    name_part = location_nodes[-1]
    query = _get_inventory_location_by_path_build_query(path_part, name_part)
    query_result = await rest_client.invoke_rest_post_async('entities/search?source=IVT', query,
                                                            EntityDescriptorListFromQuery, True)
    if len(query_result.data) == 0:
        raise LuPySNBException(f"Location {location_path} not found")
    elif len(query_result.data) > 1:
        raise LuPySNBException(f"Multiple locations found for {location_path}")

    location_eid = query_result.data[0].id
    return await get_inventory_location_by_eid_async(rest_client, location_eid)


def get_inventory_location_by_eid(rest_client: IRestClient, location_eid: str) -> InventoryLocationResponse:
    return rest_client.invoke_rest_get(f'inventory/locations/{location_eid}', InventoryLocationResponse)


async def get_inventory_location_by_eid_async(rest_client: IRestClientAsync,
                                              location_eid: str) -> InventoryLocationResponse:
    return await rest_client.invoke_rest_get_async(f'inventory/locations/{location_eid}', InventoryLocationResponse)


def _get_inventory_location_children_by_path_query(location_path: str, entity_type: str) -> Query:
    return Query(query=AndQueryTerm.create(
        [
            QueryMatch[str].create('type', entity_type, 'keyword'),
            QueryMatch[str].create('fields.Path', location_path, 'keyword', 'text', 'tags')
        ]))


def get_inventory_location_children_by_path(rest_client: IRestClient, location_path: str,
                                            entity_type: str) -> EntityDescriptorListFromQuery:
    query = _get_inventory_location_children_by_path_query(location_path, entity_type)
    return rest_client.invoke_rest_post('entities/search?source=IVT', query, EntityDescriptorListFromQuery, True)


async def get_inventory_location_children_by_path_async(rest_client: IRestClientAsync, location_path: str,
                                                        entity_type: str) -> EntityDescriptorListFromQuery:
    query = _get_inventory_location_children_by_path_query(location_path, entity_type)
    return await rest_client.invoke_rest_post_async('entities/search?source=IVT', query, EntityDescriptorListFromQuery,
                                                    True)


def get_location_path_from_location_response(location_response: InventoryLocationResponse) -> str:
    path = ''
    ancestor_names = [v['name'] for v in location_response.data.attributes.ancestors]
    if len(ancestor_names) > 0:
        ancestor_names.reverse()
        path = '/'.join(ancestor_names)
        path = '/' + path

    return path + '/' + location_response.data.attributes.name


def _get_inventory_location_by_barcode_query(barcode) -> Query:
    return Query(query=AndQueryTerm.create(
        [
            QueryMatch[str].create('type', 'location', 'keyword'),
            QueryMatch[str].create('fields.Barcode', barcode, 'keyword', 'text', 'tags')
        ]))


def get_inventory_location_by_barcode(rest_client: IRestClient, barcode: str) -> EntityDescriptorListFromQuery:
    query = _get_inventory_location_by_barcode_query(barcode)
    return rest_client.invoke_rest_post('entities/search?source=IVT', query, EntityDescriptorListFromQuery,
                                        True)


async def get_inventory_location_by_barcode_async(rest_client: IRestClientAsync,
                                                  barcode: str) -> EntityDescriptorListFromQuery:
    query = _get_inventory_location_by_barcode_query(barcode)
    return await rest_client.invoke_rest_post_async('entities/search?source=IVT', query, EntityDescriptorListFromQuery,
                                                    True)


def _get_order_by_container_name_query(container_name: str) -> Query:
    return Query(query=AndQueryTerm.create(
        [
            QueryMatch[str].create('order.Container ID', container_name, 'keyword', 'text', 'tags'),
            QueryMatch[str].create('type', 'order')
        ]))


def get_order_by_container_name(rest_client: IRestClient, container_name: str) -> EntityDescriptorListFromQuery:
    query = _get_order_by_container_name_query(container_name)
    return rest_client.invoke_rest_post('entities/search?source=SN', query, EntityDescriptorListFromQuery, True)


async def get_order_by_container_name_async(rest_client: IRestClientAsync,
                                            container_name: str) -> EntityDescriptorListFromQuery:
    query = _get_order_by_container_name_query(container_name)
    return await rest_client.invoke_rest_post_async('entities/search?source=SN', query, EntityDescriptorListFromQuery,
                                                    True)
