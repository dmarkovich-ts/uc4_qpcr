from typing import Type, TypeVar, Union, Optional
from io import BytesIO

from LuPySNB.model.responses.File import File
from LuPySNB.model.requests.APIRequest import APIRequest
from LuPySNB.model.responses.APIResponse import APIResponse
from LuPySNB.model.responses.ErrorList import ErrorList


class IRestClient:
    T = TypeVar('T', bound=APIResponse)

    def invoke_rest_post(self, endpoint: str, req_body: Optional[APIRequest], ret_type: Type[T],
                         use_pagination: bool = False) -> Union[T, ErrorList]:
        pass

    def invoke_rest_put(self, endpoint: str, req_body: APIRequest, ret_type: Type[T]) -> Union[T, ErrorList]:
        pass

    def invoke_rest_post_file(self, endpoint: str, mime_type: str, req_body: BytesIO, ret_type: Type[T]) -> Union[T, ErrorList]:
        pass

    def invoke_rest_put_file(self, endpoint: str, mime_type: str, req_body: BytesIO, ret_type: Type[T]) -> Union[T, ErrorList]:
        pass

    def invoke_rest_patch(self, endpoint: str, req_body: APIRequest, ret_type: Type[T]) -> Union[T, ErrorList]:
        pass

    def invoke_rest_patch_file(self, endpoint: str, mime_type: str, req_body: BytesIO, ret_type: Type[T]) -> Union[T, ErrorList]:
        pass

    def invoke_rest_get(self, endpoint: str, ret_type: Type[T], use_pagination: bool = False) -> Union[T, ErrorList]:
        pass

    def invoke_rest_get_file(self, endpoint: str) -> Union[File, ErrorList]:
        pass

    def invoke_rest_delete(self, endpoint: str) -> Optional[ErrorList]:
        pass
