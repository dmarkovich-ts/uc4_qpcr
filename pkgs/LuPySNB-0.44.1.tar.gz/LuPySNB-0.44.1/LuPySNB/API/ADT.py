from typing import List, Tuple, Union, Any, Optional
from LuPySNB.API.IRestClientAsync import IRestClientAsync
from LuPySNB.API.IRestClient import IRestClient
from LuPySNB.API.Entity import get_child_entities_by_parent_id, get_child_entities_by_parent_id_async, \
    get_parent_entities_by_child_id, get_parent_entities_by_child_id_async, get_entity_id_by_name
from LuPySNB.model.DTOs.FieldValue import InputValueTypes
from LuPySNB.model.DTOs.Query import Query, AndQueryTerm, QueryMatch, QueryParent
from LuPySNB.model.requests.ADTAddRowRequest import ADTAddRowRequest
from LuPySNB.model.requests.ADTBulkAddRowRequest import ADTBulkAddRowRequest
from LuPySNB.model.requests.ADTBulkUpdateRowRequest import ADTBulkUpdateRowRequest
from LuPySNB.model.responses.ADTBulkRow import ADTBulkRow
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.ADTDescriptor import ADTDescriptor
from LuPySNB.model.responses.ADTContent import ADTContent
from LuPySNB.model.responses.ADTRow import ADTRow
from LuPySNB.model.responses.EntityDescriptorList import EntityDescriptorListFromQuery
from LuPySNB.model.exceptions.LuPySNBInternalException import LuPySNBInternalException


def get_adt_data(rest_client: IRestClient, adt_eid: str) -> Union[ADTContent, ErrorList]:
    return rest_client.invoke_rest_get(f"adt/{adt_eid}", ADTContent)


async def get_adt_data_async(rest_client: IRestClientAsync, adt_eid: str) -> Union[ADTContent, ErrorList]:
    return await rest_client.invoke_rest_get_async(f"adt/{adt_eid}", ADTContent)


def _get_experiment_adt_ids_handle_response(response: Any) -> Union[List[str], None, ErrorList]:
    if isinstance(response, EntityDescriptorListFromQuery):
        return list(map(lambda x: x.attributes.eid, response.data)) if len(response.data) > 0 else None
    else:
        return response


def get_experiment_adt_ids(rest_client: IRestClient, experiment_eid: str) -> Union[List[str], None, ErrorList]:
    return _get_experiment_adt_ids_handle_response(get_child_entities_by_parent_id(rest_client, experiment_eid, "grid"))


async def get_experiment_adt_ids_async(rest_client: IRestClientAsync, experiment_eid: str) \
        -> Union[List[str], None, ErrorList]:
    return _get_experiment_adt_ids_handle_response(
        await get_child_entities_by_parent_id_async(rest_client, experiment_eid, "grid"))


def _get_experiment_adt_id_by_name_handle_response(response: Any) -> Union[str, None, ErrorList]:
    if isinstance(response, EntityDescriptorListFromQuery):
        return response.data[0].attributes.eid if len(response.data) > 0 else None
    else:
        return response


def get_experiment_adt_id_by_name(rest_client: IRestClient, experiment_eid: str, table_name: str) \
        -> Union[str, None, ErrorList]:
    return _get_experiment_adt_id_by_name_handle_response(
        get_child_entities_by_parent_id(rest_client, experiment_eid, "grid", table_name))


async def get_experiment_adt_id_by_name_async(rest_client: IRestClientAsync, experiment_eid: str, table_name: str) \
        -> Union[str, None, ErrorList]:
    return _get_experiment_adt_id_by_name_handle_response(
        await get_child_entities_by_parent_id_async(rest_client, experiment_eid, "grid", table_name))


def get_experiment_adt_cols(rest_client: IRestClient, adt_eid: str) -> Union[ADTDescriptor, ErrorList]:
    return rest_client.invoke_rest_get(f"adt/{adt_eid}/_column", ADTDescriptor)


async def get_experiment_adt_cols_async(rest_client: IRestClientAsync, adt_eid: str) -> Union[ADTDescriptor, ErrorList]:
    return await rest_client.invoke_rest_get_async(f"adt/{adt_eid}/_column", ADTDescriptor)


def insert_adt_row_by_col_ids(rest_client: IRestClient, adt_eid: str, cols: List[Tuple[str, str, InputValueTypes]],
                              sync_data: bool = False, digest: Optional[str] = None) -> Union[ADTRow, ErrorList]:
    adt_row_req = ADTAddRowRequest.create(cols)
    return rest_client.invoke_rest_post(f"adt/{adt_eid}?force={'false' if digest else 'true'}"
                                        f"{'&digest=' + digest if digest else ''}"
                                        f"&syncData={'true' if sync_data else 'false'}",
                                        adt_row_req, ADTRow)


async def insert_adt_row_by_col_ids_async(rest_client: IRestClientAsync, adt_eid: str,
                                          cols: List[Tuple[str, str, InputValueTypes]],
                                          sync_data: bool = False, digest: Optional[str] = None) \
        -> Union[ADTRow, ErrorList]:
    adt_row_req = ADTAddRowRequest.create(cols)
    return await rest_client.invoke_rest_post_async(f"adt/{adt_eid}?force={'false' if digest else 'true'}"
                                                    f"{'&digest='+ digest if digest else ''}"
                                                    f"&syncData={'true' if sync_data else 'false'}",
                                                    adt_row_req, ADTRow)


def insert_bulk_adt_rows_by_col_name(
        rest_client: IRestClient,
        adt_eid: str,
        col_sets: list[list[tuple[str, InputValueTypes]]],
        sync_data: bool = False,
        digest: Optional[str] = None) -> ADTContent | ErrorList | list[ErrorList]:
    adt_descriptor = get_experiment_adt_cols(rest_client, adt_eid)
    if not isinstance(adt_descriptor, ADTDescriptor):
        return [adt_descriptor]

    adt_cols = dict(map(lambda x: (x.title, x), adt_descriptor.data.attributes.columns))
    bulk_data = []

    for row in col_sets:
        non_mapped_cols = list(map(lambda x: x[0], filter(lambda y: y[0] not in adt_cols, row)))
        if any(non_mapped_cols):
            raise LuPySNBInternalException(f'Non-recognized ADT column names in request: {non_mapped_cols}')

        mapped_row = []
        for col_name, value in row:
            col_def = adt_cols[col_name]
            mapped_row.append((col_def.key, col_def.type, value))
        bulk_data.append(mapped_row)

    adt_req = ADTBulkAddRowRequest.create(bulk_data)
    return rest_client.invoke_rest_patch(
        f"adt/{adt_eid}?force={'false' if digest else 'true'}"
        f"{'&digest=' + digest if digest else ''}"
        f"&syncData={'true' if sync_data else 'false'}",
        adt_req,
        ADTContent
    )


async def insert_bulk_adt_rows_by_col_name_async(
        rest_client: IRestClientAsync,
        adt_eid: str,
        col_sets: list[list[tuple[str, InputValueTypes]]],
        sync_data: bool = False,
        digest: Optional[str] = None) -> ADTContent | ErrorList | list[ErrorList]:
    adt_descriptor = await get_experiment_adt_cols_async(rest_client, adt_eid)
    if not isinstance(adt_descriptor, ADTDescriptor):
        return [adt_descriptor]

    adt_cols = dict(map(lambda x: (x.title, x), adt_descriptor.data.attributes.columns))
    bulk_data = []

    for row in col_sets:
        non_mapped_cols = list(map(lambda x: x[0], filter(lambda y: y[0] not in adt_cols, row)))
        if any(non_mapped_cols):
            raise LuPySNBInternalException(f'Non-recognized ADT column names in request: {non_mapped_cols}')

        mapped_row = []
        for col_name, value in row:
            col_def = adt_cols[col_name]
            mapped_row.append((col_def.key, col_def.type, value))
        bulk_data.append(mapped_row)

    adt_req = ADTBulkAddRowRequest.create(bulk_data)
    return await rest_client.invoke_rest_patch_async(
        f"adt/{adt_eid}?force={'false' if digest else 'true'}"
        f"{'&digest=' + digest if digest else ''}"
        f"&syncData={'true' if sync_data else 'false'}",
        adt_req,
        ADTContent
    )


def update_bulk_adt_rows_by_col_name(
        rest_client: IRestClient,
        adt_eid: str,
        row_sets: list[tuple[str, list[tuple[str, InputValueTypes]]]],
        sync_data: bool = False,
        digest: Optional[str] = None) -> ADTContent | ErrorList | list[ErrorList]:
    '''
    Synchronous bulk update of rows.

    :rest_client: The REST client.
    :adt_eid: The entity ID of the table.
    :row_sets: A list of rows. For each row, use a tuple with the row ID and a list of tuples with column names and input values.
    :sync_data: To synchronize data form an External Data Source connection.
    '''
    adt_descriptor = get_experiment_adt_cols(rest_client, adt_eid)
    if not isinstance(adt_descriptor, ADTDescriptor):
        return [adt_descriptor]

    adt_cols = dict(map(lambda x: (x.title, x), adt_descriptor.data.attributes.columns))
    bulk_data = []

    for row in row_sets:
        non_mapped_cols = list(map(lambda x: x[0], filter(lambda y: y[0] not in adt_cols, row[1])))
        if any(non_mapped_cols):
            raise LuPySNBInternalException(f'Non-recognized ADT column names in request: {non_mapped_cols}')

        mapped_row = []
        for col_name, value in row[1]:
            col_def = adt_cols[col_name]
            mapped_row.append((col_def.key, col_def.type, value))
        bulk_data.append((row[0], mapped_row))

    adt_req = ADTBulkUpdateRowRequest.create(bulk_data)
    return rest_client.invoke_rest_patch(
        f"adt/{adt_eid}?force={'false' if digest else 'true'}"
        f"{'&digest=' + digest if digest else ''}"
        f"&syncData={'true' if sync_data else 'false'}",
        adt_req,
        ADTContent
    )


async def update_bulk_adt_rows_by_col_name_async(
        rest_client: IRestClientAsync,
        adt_eid: str,
        row_sets: list[tuple[str, list[tuple[str, InputValueTypes]]]],
        sync_data: bool = False,
        digest: Optional[str] = None) -> ADTContent | ErrorList | list[ErrorList]:
    '''
    Asynchronous bulk update of rows.

    :rest_client: The REST client.
    :adt_eid: The entity ID of the table.
    :row_sets: A list of rows. For each row, use a tuple with the row ID and a list of tuples with column names and input values.
    :sync_data: To synchronize data form an External Data Source connection.
    '''
    adt_descriptor = await get_experiment_adt_cols_async(rest_client, adt_eid)
    if not isinstance(adt_descriptor, ADTDescriptor):
        return [adt_descriptor]

    adt_cols = dict(map(lambda x: (x.title, x), adt_descriptor.data.attributes.columns))
    bulk_data = []

    for row in row_sets:
        non_mapped_cols = list(map(lambda x: x[0], filter(lambda y: y[0] not in adt_cols, row[1])))
        if any(non_mapped_cols):
            raise LuPySNBInternalException(f'Non-recognized ADT column names in request: {non_mapped_cols}')

        mapped_row = []
        for col_name, value in row[1]:
            col_def = adt_cols[col_name]
            mapped_row.append((col_def.key, col_def.type, value))
        bulk_data.append((row[0], mapped_row))

    adt_req = ADTBulkUpdateRowRequest.create(bulk_data)
    return await rest_client.invoke_rest_patch_async(
        f"adt/{adt_eid}?force={'false' if digest else 'true'}"
        f"{'&digest=' + digest  if digest else ''}"
        f"&syncData={'true' if sync_data else 'false'}",
        adt_req,
        ADTContent
    )


def insert_adt_rows_by_col_name(rest_client: IRestClient, adt_eid: str,
                                cols_set: List[List[Tuple[str, InputValueTypes]]],
                                sync_data: bool = False) \
        -> List[Union[ADTRow, ErrorList]]:
    adt_descriptor = get_experiment_adt_cols(rest_client, adt_eid)
    if not isinstance(adt_descriptor, ADTDescriptor):
        return [adt_descriptor]

    adt_cols = dict(map(lambda x: (x.title, x), adt_descriptor.data.attributes.columns))

    ret_list = []
    for cols in cols_set:
        non_mapped_cols = list(map(lambda x: x[0], filter(lambda y: y[0] not in adt_cols, cols)))
        if any(non_mapped_cols):
            raise LuPySNBInternalException(f'Non-recognized ADT column names in request: {non_mapped_cols}')

        for method in ['header', None]:
            mapped_cols = list(map(lambda x: (adt_cols[x[0]].key, adt_cols[x[0]].type, x[1]),
                                   filter(lambda y: y[0] in adt_cols and adt_cols[y[0]].method == method, cols)))

            if any(mapped_cols):
                ret_list.append(insert_adt_row_by_col_ids(rest_client, adt_eid, mapped_cols, sync_data))

    return ret_list


async def insert_adt_rows_by_col_name_async(rest_client: IRestClientAsync, adt_eid: str,
                                            cols_set: List[List[Tuple[str, InputValueTypes]]],
                                            sync_data: bool = False) -> List[Union[ADTRow, ErrorList]]:
    adt_descriptor = await get_experiment_adt_cols_async(rest_client, adt_eid)
    if not isinstance(adt_descriptor, ADTDescriptor):
        return [adt_descriptor]

    adt_cols = dict(map(lambda x: (x.title, x), adt_descriptor.data.attributes.columns))

    ret_list = []
    for cols in cols_set:
        non_mapped_cols = list(map(lambda x: x[0], filter(lambda y: y[0] not in adt_cols, cols)))
        if any(non_mapped_cols):
            raise LuPySNBInternalException(f'Non-recognized ADT column names in request: {non_mapped_cols}')

        for method in ['header', None]:
            mapped_cols = list(map(lambda x: (adt_cols[x[0]].key, adt_cols[x[0]].type, x[1]),
                                   filter(lambda y: y[0] in adt_cols and adt_cols[y[0]].method == method, cols)))

            if any(mapped_cols):
                ret_list.append(await insert_adt_row_by_col_ids_async(rest_client, adt_eid, mapped_cols,
                                                                      sync_data))

    return ret_list


def delete_adt_row_by_id(rest_client: IRestClient, adt_eid: str, row_id: str, digest: Optional[str] = None):
    return rest_client.invoke_rest_delete(f"adt/{adt_eid}/{row_id}?force={'false' if digest else 'true'}"
                                          f"{'&digest=' + digest if digest else ''}")


async def delete_adt_row_by_id_async(rest_client: IRestClientAsync, adt_eid: str, row_id: str, digest: Optional[str] = None):
    return await rest_client.invoke_rest_delete_async(f"adt/{adt_eid}/{row_id}?force={'false' if digest else 'true'}"
                                                      f"{'&digest='+ digest if digest else ''}")


def _get_adt_containing_entry_by_template_build_query(adt_template_name: str, column_name: str, cell_value: any,
                                                      cell_value_type: str, filter_experiment_id: str) -> Query:
    query = Query(query=AndQueryTerm.create([QueryMatch.create(f'grid.{column_name}', cell_value, 'keyword',
                                                               cell_value_type, 'tags'),
                                             QueryMatch.create('system.Origin Template Name', adt_template_name,
                                                               'keyword', 'text', 'tags')]))
    if filter_experiment_id:
        query.query.andList.append(QueryParent.create(parent=QueryMatch.create('eid', filter_experiment_id,
                                                                               'keyword', 'text')))

    return query


def get_adt_containing_adt_entry_by_template(rest_client: IRestClient, adt_template_name: str, column_name: str,
                                             cell_value: any, cell_value_type: str, filter_experiment_id: str = None) \
        -> EntityDescriptorListFromQuery | ErrorList:
    '''
    Get the ADT entity that contains an entry with the specified value in the specified column and that is based on the specified template.
    rest_client: The Signals REST client.
    adt_template_name: The name of the template that the ADT is based on.
    column_name: The name of the column to search in.
    cell_value: The value to search for in the specified column.
    filter_experiment_id: If specified, only return ADTs that are in the experiment with the specified ID.
    returns a list of entity descriptors, as there could be multiple ADTs based on the same template that contain the
    same entry (e.g. if the template is used for multiple experiments or if there are multiple ADT instances in the same experiment based on the same template).
    The entity descriptors will contain the EID and name of the ADT(s) that match the criteria.
    '''
    return rest_client.invoke_rest_post('entities/search?source=SN',
                                        _get_adt_containing_entry_by_template_build_query(adt_template_name,
                                                                                          column_name, cell_value,
                                                                                          cell_value_type,
                                                                                          filter_experiment_id),
                                        EntityDescriptorListFromQuery, True)


async def get_adt_containing_adt_entry_by_template_async(rest_client: IRestClientAsync, adt_template_name: str,
                                                         column_name: str,
                                                         cell_value: any,
                                                         cell_value_type: str,
                                                         filter_experiment_id: str = None) \
        -> EntityDescriptorListFromQuery | ErrorList:
    '''
    Get the ADT entity that contains an entry with the specified value in the specified column and that is based on the specified template.
    rest_client: The Signals REST client.
    adt_template_name: The name of the template that the ADT is based on.
    column_name: The name of the column to search in.
    cell_value: The value to search for in the specified column.
    filter_experiment_id: If specified, only return ADTs that are in the experiment with the specified ID.
    returns a list of entity descriptors, as there could be multiple ADTs based on the same template that contain the
    same entry (e.g. if the template is used for multiple experiments or if there are multiple ADT instances in the same experiment based on the same template).
    The entity descriptors will contain the EID and name of the ADT(s) that match the criteria.
    '''

    return await rest_client.invoke_rest_post_async('entities/search?source=SN',
                                                    _get_adt_containing_entry_by_template_build_query(
                                                        adt_template_name, column_name,
                                                        cell_value, cell_value_type, filter_experiment_id),
                                                    EntityDescriptorListFromQuery, True)


def get_experiment_containing_adt_entry(rest_client: IRestClient, adt_template_name: str, column_name: str,
                                        cell_value: any,
                                        cell_value_type: str) -> List[Tuple[str, str]] | ErrorList:
    tables = get_adt_containing_adt_entry_by_template(rest_client, adt_template_name, column_name, cell_value,
                                                      cell_value_type)

    if not isinstance(tables, EntityDescriptorListFromQuery):
        return tables

    return list(map(lambda z: (z.attributes.eid, z.attributes.name),
                    sum(map(lambda y: y.data,
                            map(lambda x: get_parent_entities_by_child_id(rest_client, x.attributes.eid, 'experiment'),
                                tables.data)), []))) \
        if isinstance(tables, EntityDescriptorListFromQuery) and tables.data else tables


async def get_experiment_containing_adt_entry_async(rest_client: IRestClientAsync, adt_name: str,
                                                    column_name: str, cell_value: any,
                                                    cell_value_type: str) -> List[Tuple[str, str]] | ErrorList:
    tables = await get_adt_containing_adt_entry_by_template_async(rest_client, adt_name, column_name, cell_value,
                                                                  cell_value_type)

    if not isinstance(tables, EntityDescriptorListFromQuery):
        return tables

    ret_list = []
    for table in tables.data:
        parent_entities = await get_parent_entities_by_child_id_async(rest_client, table.attributes.eid, 'experiment')
        if isinstance(parent_entities, EntityDescriptorListFromQuery):
            ret_list.extend([(z.attributes.eid, z.attributes.name) for z in parent_entities.data])
    return ret_list
