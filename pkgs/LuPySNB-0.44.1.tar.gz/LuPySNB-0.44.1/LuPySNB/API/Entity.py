from enum import Enum
from typing import Optional, Union, Dict, Any, List

from LuPySNB.API.IRestClientAsync import IRestClientAsync
from LuPySNB.model.requests.EntityReview import EntityReview
from LuPySNB.model.requests.UpdateEntityRequest import UpdateEntityRequest
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.EntityDescriptor import EntityDescriptor
from LuPySNB.model.responses.APIPaginatedResponse import APIPaginatedResponse
from LuPySNB.model.responses.EntityDescriptorList import EntityDescriptorListFromQuery, EntityDescriptorList
from LuPySNB.model.responses.CreateEntityResponse import CreateEntityResponse
from LuPySNB.model.DTOs.Query import QueryMatch, QueryIn, QueryParent, AndQueryTerm, Query, QueryExists, NotQueryTerm, \
    OrQueryTerm, QueryChild
from LuPySNB.model.responses.GetEntityResponse import GetEntityResponse
from LuPySNB.model.requests.CreateEntityRequest import CreateEntityRequest
from LuPySNB.model.exceptions.LuPySNBInternalException import LuPySNBInternalException
from LuPySNB.API.IRestClient import IRestClient
from LuPySNB.model.responses.UpdateEntityPropertiesResponse import UpdateEntityPropertiesResponse
from datetime import datetime


def create_entity(rest_client: IRestClient, template_id: str, ancestor_id: str | None, attributes: Dict[str, Any]) \
        -> CreateEntityResponse | ErrorList:
    entity_req = CreateEntityRequest.create(template_id, ancestor_id, attributes)
    return rest_client.invoke_rest_post("entities/?force=true", entity_req, CreateEntityResponse)


async def create_entity_async(rest_client: IRestClientAsync, template_id: str, ancestor_id: str | None,
                              attributes: Dict[str, Any]) \
        -> CreateEntityResponse | ErrorList:
    entity_req = CreateEntityRequest.create(template_id, ancestor_id, attributes)
    return await rest_client.invoke_rest_post_async("entities/?force=true", entity_req, CreateEntityResponse)


def _get_entities_by_name_build_query(entity_name: str, entity_type: str, is_template: bool,
                                      is_system: bool | None = None, has_no_parent: bool | None = None) -> Query:
    query = Query(query=AndQueryTerm.create(
        [QueryMatch[str].create('name', entity_name, 'keyword', 'text'),
         QueryMatch[bool].create('isTemplate', value=is_template)]))

    if entity_type is not None:
        query.query.andList.append(QueryMatch[str].create("type", entity_type, 'keyword'))

    if is_system is not None:
        query.query.andList.append(
            QueryMatch[bool].create("system._isSystem", value=is_system, as_type='boolean', in_object='tags'))

    if has_no_parent is not None:
        query.query.andList.append(NotQueryTerm.create([QueryExists.create("_parent_type")]))

    return query


class EntityType(Enum):
    experiment = 'experiment'
    journal = 'journal'
    ado = 'ado'
    request = 'request'


class EntityOption(Enum):
    mine = 'mine'
    other = 'other'
    shared = 'shared'
    trashed = 'trashed'
    untrashed = 'untrashed'
    trashedAncestor = 'trashedAncestor'
    starred = 'starred'
    unstarred = 'unstarred'
    template = 'template'
    nontemplate = 'nontemplate'
    systemTemplate = 'systemTemplate'
    nonSystemTemplate = 'nonSystemTemplate'


def get_entities(rest_client: IRestClient,
                 include_types: List[EntityType] | None = None,
                 exclude_types: List[EntityType] | None = None,
                 entity_options: List[EntityOption] | None = None,
                 start_date: datetime | None = None,
                 end_date: datetime | None = None) -> EntityDescriptorList | ErrorList:
    url = '/entities'
    if include_types is not None:
        url += ('&' if '?' in url else '?') + f'includeTypes={",".join([et.value for et in include_types])}'
    if exclude_types is not None:
        url += ('&' if '?' in url else '?') + f'excludeTypes={",".join([et.value for et in exclude_types])}'
    if entity_options is not None:
        url += ('&' if '?' in url else '?') + f'includeOptions={",".join([eo.value for eo in entity_options])}'
    if start_date is not None:
        url += ('&' if '?' in url else '?') + f'start={start_date.isoformat()}'
    if end_date is not None:
        url += ('&' if '?' in url else '?') + f'end={end_date.isoformat()}'
    return rest_client.invoke_rest_get(url, EntityDescriptorList)


async def get_entities_async(rest_client: IRestClientAsync,
                             include_types: List[EntityType] | None = None,
                             exclude_types: List[EntityType] | None = None,
                             entity_options: List[EntityOption] | None = None,
                             start_date: datetime | None = None,
                             end_date: datetime | None = None) -> EntityDescriptorList | ErrorList:
    url = '/entities'
    if include_types is not None:
        url += ('&' if '?' in url else '?') + f'includeTypes={",".join([et.value for et in include_types])}'
    if exclude_types is not None:
        url += ('&' if '?' in url else '?') + f'excludeTypes={",".join([et.value for et in exclude_types])}'
    if entity_options is not None:
        url += ('&' if '?' in url else '?') + f'includeOptions={",".join([eo.value for eo in entity_options])}'
    if start_date is not None:
        url += ('&' if '?' in url else '?') + f'start={start_date.isoformat()}'
    if end_date is not None:
        url += ('&' if '?' in url else '?') + f'end={end_date.isoformat()}'
    return await rest_client.invoke_rest_get_async(url, EntityDescriptorList)


def get_entities_by_name(rest_client: IRestClient, entity_name: str, entity_type: str, is_template: bool,
                         is_system: bool | None = None, has_no_parent: bool | None = None) \
        -> EntityDescriptorListFromQuery | ErrorList:
    query = _get_entities_by_name_build_query(entity_name, entity_type, is_template, is_system, has_no_parent)
    return rest_client.invoke_rest_post('entities/search?source=SN', query, EntityDescriptorListFromQuery, True)


async def get_entities_by_name_async(rest_client: IRestClientAsync, entity_name: str, entity_type: str,
                                     is_template: bool,
                                     is_system: bool = None, has_no_parent: bool = None) \
        -> Union[EntityDescriptorListFromQuery, ErrorList]:
    query = _get_entities_by_name_build_query(entity_name, entity_type, is_template, is_system, has_no_parent)
    return await rest_client.invoke_rest_post_async('entities/search?source=SN', query, EntityDescriptorListFromQuery,
                                                    True)


def _get_entities_from_names_build_query(
        entity_name: List[str],
        entity_type: str | List[str] | None = None,
        is_template: bool = False,
        is_system: bool | None = None,
        has_no_parent: bool | None = None
    ) -> Query:
    query = Query(query=AndQueryTerm.create(
        [QueryIn[str].create('name', entity_name, 'keyword', 'text'),
         QueryMatch[bool].create('isTemplate', value=is_template)]))

    if entity_type is not None:
        if isinstance(entity_type, str):
            query.query.andList.append(QueryMatch[str].create('type', entity_type, 'keyword'))
        elif isinstance(entity_type, list):
            query.query.andList.append(QueryIn[str].create('type', entity_type, 'keyword', 'text'))
    
    if is_system is not None:
        query.query.andList.append(
            QueryMatch[bool].create('system._isSystem', value=is_system, as_type='boolean', in_object='tags'))
    
    if has_no_parent is not None:
        query.query.andList.append(NotQueryTerm.create([QueryExists.create('_parent_type')]))
    
    return query


def get_entities_from_names(
        rest_client: IRestClient,
        entity_name: List[str],
        entity_type: str | List[str] | None = None,
        is_template: bool = False,
        is_system: bool | None = None,
        has_no_parent: bool | None = None
    ) -> EntityDescriptorListFromQuery | ErrorList:
    query = _get_entities_from_names_build_query(entity_name, entity_type, is_template, is_system, has_no_parent)
    return rest_client.invoke_rest_post('entities/search?source=SN', query, EntityDescriptorListFromQuery, True)


async def get_entities_from_names_async(
        rest_client: IRestClientAsync,
        entity_name: List[str],
        entity_type: str | List[str] | None = None,
        is_template: bool = False,
        is_system: bool | None = None,
        has_no_parent: bool | None = None
    ) -> EntityDescriptorListFromQuery | ErrorList:
    query = _get_entities_from_names_build_query(entity_name, entity_type, is_template, is_system, has_no_parent)
    return await rest_client.invoke_rest_post_async('entities/search?source=SN', query, EntityDescriptorListFromQuery,
                                                    True)


def _get_entity_id_by_name_handle_response(response: Any, entity_name: str, entity_type: str) -> str | None | ErrorList:
    if isinstance(response, EntityDescriptorListFromQuery):
        if len(response.data) == 1:
            return response.data[0].id
        elif len(response.data) == 0:
            return None
        else:
            raise LuPySNBInternalException(
                f'No unique match found for entity name {entity_name} and entity type {entity_type}')
    else:
        return response


def get_entity_id_by_name(rest_client: IRestClient, entity_name: str, entity_type: str, is_template: bool,
                          is_system: bool | None = None, has_no_parent: bool | None = None) \
        -> str | None | ErrorList:
    return _get_entity_id_by_name_handle_response(
        get_entities_by_name(rest_client, entity_name, entity_type, is_template, is_system, has_no_parent),
        entity_name, entity_type)


async def get_entity_id_by_name_async(rest_client: IRestClientAsync, entity_name: str, entity_type: str,
                                      is_template: bool, is_system: bool | None = None,
                                      has_no_parent: bool | None = None) -> str | None | ErrorList:
    return _get_entity_id_by_name_handle_response(
        await get_entities_by_name_async(rest_client, entity_name, entity_type, is_template, is_system, has_no_parent),
        entity_name, entity_type)


def _get_child_entities_by_parent_id_build_query(parent_entity_id: str, filter_type: str | List = None,
                                                 filter_name: str | None = None) -> Query:
    query = Query(query=AndQueryTerm.create([QueryParent.create(QueryMatch[str].create(
        'eid', parent_entity_id, 'keyword', 'text'))]))

    if isinstance(filter_type, str):
        query.query.andList.append(QueryMatch[str].create("type", filter_type, 'keyword'))
    elif isinstance(filter_type, list):
        qm = [QueryMatch[str].create('type', et, 'keyword') for et in filter_type]
        query.query.andList.append(OrQueryTerm.create(qm))

    if filter_name is not None:
        query.query.andList.append(QueryMatch[str].create("name", filter_name, mode='keyword'))

    return query


def get_child_entities_by_parent_id(rest_client: IRestClient, parent_entity_id: str, filter_type: str | List = None,
                                    filter_name: str = None) -> EntityDescriptorListFromQuery | ErrorList:
    query = _get_child_entities_by_parent_id_build_query(parent_entity_id, filter_type, filter_name)
    return rest_client.invoke_rest_post('entities/search?source=SN', query, EntityDescriptorListFromQuery, True)


async def get_child_entities_by_parent_id_async(rest_client: IRestClientAsync, parent_entity_id: str,
                                                filter_type: str | List = None,
                                                filter_name: str = None) -> EntityDescriptorListFromQuery | ErrorList:
    query = _get_child_entities_by_parent_id_build_query(parent_entity_id, filter_type, filter_name)
    return await rest_client.invoke_rest_post_async('entities/search?source=SN', query, EntityDescriptorListFromQuery,
                                                    True)


def _get_parent_entities_by_child_id_build_query(child_entity_id: str, filter_type: str | List | None = None,
                                                 filter_name: str | None = None) -> Query:
    query = Query(query=AndQueryTerm.create([QueryChild.create(QueryMatch[str].create(
        'eid', child_entity_id, 'keyword', 'text'))]))

    if isinstance(filter_type, str):
        query.query.andList.append(QueryMatch[str].create("type", filter_type, 'keyword'))
    elif isinstance(filter_type, list):
        qm = [QueryMatch[str].create('type', et, 'keyword') for et in filter_type]
        query.query.andList.append(OrQueryTerm.create(qm))

    if filter_name is not None:
        query.query.andList.append(QueryMatch[str].create("name", filter_name, mode='keyword'))

    return query


def get_ancestors_by_child_id(rest_client: IRestClient, child_entity_id: str)\
        -> EntityDescriptorList | ErrorList:
    return rest_client.invoke_rest_get(f"entities/{child_entity_id}/ancestors", EntityDescriptorList)


async def get_ancestors_by_child_id_async(rest_client: IRestClientAsync, child_entity_id: str)\
        -> EntityDescriptorList | ErrorList:
    return await rest_client.invoke_rest_get_async(f"entities/{child_entity_id}/ancestors", EntityDescriptorList)


def get_parent_experiment_by_child_id(rest_client: IRestClient, child_entity_id: str) -> EntityDescriptor | None | ErrorList:
    ancestors = get_ancestors_by_child_id(rest_client, child_entity_id)
    if isinstance(ancestors, APIPaginatedResponse):
        for ancestor in ancestors.data:
            if ancestor.attributes.type in ['experiment', 'ado']:
                return ancestor
        return None
    else:
        return ancestors


async def get_parent_experiment_by_child_id_async(rest_client: IRestClientAsync, child_entity_id: str) -> EntityDescriptor | None | ErrorList:
    ancestors = await get_ancestors_by_child_id_async(rest_client, child_entity_id)
    if isinstance(ancestors, APIPaginatedResponse):
        for ancestor in ancestors.data:
            if ancestor.attributes.type in ['experiment', 'ado']:
                return ancestor
        return None
    else:
        return ancestors


def get_parent_entities_by_child_id(rest_client: IRestClient, child_entity_id: str,
                                    filter_type: str | List | None = None, filter_name: str | None = None)\
        -> EntityDescriptorListFromQuery | ErrorList:
    query = _get_parent_entities_by_child_id_build_query(child_entity_id, filter_type, filter_name)
    return rest_client.invoke_rest_post('entities/search?source=SN', query, EntityDescriptorListFromQuery, True)


async def get_parent_entities_by_child_id_async(rest_client: IRestClientAsync, child_entity_id: str,
                                                filter_type: str | List = None,
                                                filter_name: str | None = None)\
        -> EntityDescriptorListFromQuery | ErrorList:
    query = _get_parent_entities_by_child_id_build_query(child_entity_id, filter_type, filter_name)
    return await rest_client.invoke_rest_post_async('entities/search?source=SN', query, EntityDescriptorListFromQuery,
                                                    True)


def _get_child_entities_by_name_build_query(entity_name: str, entity_type: str | None, parent_name: str,
                                            parent_type: str | None) -> Query:
    query = Query(query=AndQueryTerm.create(
        [QueryMatch[str].create('name', entity_name, 'keyword', 'text'),
         QueryParent.create(QueryMatch[str].create('name', parent_name, 'keyword', 'text'))]))

    if entity_type is not None:
        query.query.andList.append(QueryMatch[str].create("type", entity_type, 'keyword'))

    if parent_type is not None and parent_type not in ('ado'): #  to query for ADOs, we need to use the ado id
        query.query.andList.append(QueryParent.create(QueryMatch[str].create(
            'type', parent_type, 'keyword', 'text')))

    return query


def get_child_entities_by_name(rest_client: IRestClient, entity_name: str, entity_type: str, parent_name: str,
                               parent_type: str) -> EntityDescriptorListFromQuery | ErrorList:
    query = _get_child_entities_by_name_build_query(entity_name, entity_type, parent_name, parent_type)
    return rest_client.invoke_rest_post('entities/search?source=SN', query, EntityDescriptorListFromQuery, True)


async def get_child_entities_by_name_async(rest_client: IRestClientAsync, entity_name: str, entity_type: str,
                                           parent_name: str, parent_type: str) \
        -> EntityDescriptorListFromQuery | ErrorList:
    query = _get_child_entities_by_name_build_query(entity_name, entity_type, parent_name, parent_type)
    return await rest_client.invoke_rest_post_async('entities/search?source=SN', query, EntityDescriptorListFromQuery,
                                                    True)


def _get_child_entity_id_by_name_handle_response(response: Any, entity_name: str, entity_type: str | None,
                                                 parent_name: str, parent_type: str | None) \
        -> Union[Optional[str], ErrorList]:
    if isinstance(response, EntityDescriptorListFromQuery):
        if len(response.data) == 1:
            return response.data[0].id
        elif len(response.data) == 0:
            return None
        else:
            raise LuPySNBInternalException(
                f'No unique match found for entity name {entity_name} and entity type {entity_type} / '
                f'parent name{parent_name} and parent type {parent_type}')
    else:
        return response


def get_child_entity_id_by_name(rest_client: IRestClient, entity_name: str, entity_type: str | None,
                                parent_name: str, parent_type: str | None) -> str | None | ErrorList:
    return _get_child_entity_id_by_name_handle_response(
        get_child_entities_by_name(rest_client, entity_name, entity_type, parent_name, parent_type),
        entity_name, entity_type, parent_name, parent_type)


async def get_child_entity_id_by_name_async(rest_client: IRestClientAsync, entity_name: str, entity_type: str | None,
                                            parent_name: str, parent_type: str | None) \
        -> str | None | ErrorList:
    return _get_child_entity_id_by_name_handle_response(
        await get_child_entities_by_name_async(rest_client, entity_name, entity_type, parent_name, parent_type),
        entity_name, entity_type, parent_name, parent_type)


def get_entity_by_id(rest_client: IRestClient, eid: str) -> GetEntityResponse | ErrorList:
    return rest_client.invoke_rest_get(f'/entities/{eid}', GetEntityResponse)


async def get_entity_by_id_async(rest_client: IRestClientAsync, eid: str) -> GetEntityResponse | ErrorList:
    return await rest_client.invoke_rest_get_async(f'/entities/{eid}', GetEntityResponse)


def delete_entity(rest_client: IRestClient, eid: str) -> ErrorList | None:
    return rest_client.invoke_rest_delete(f"/entities/{eid}?force=true")


async def delete_entity_async(rest_client: IRestClientAsync, eid: str) -> ErrorList | None:
    return await rest_client.invoke_rest_delete_async(f"/entities/{eid}?force=true")


def update_entity_properties_by_id(rest_client: IRestClient, eid: str, properties: List[Dict[str, Any]])\
        -> UpdateEntityPropertiesResponse | ErrorList:
    return rest_client.invoke_rest_patch(f'/entities/{eid}/properties?force=true',
                                         UpdateEntityRequest.create(properties), UpdateEntityPropertiesResponse)


async def update_entity_properties_by_id_async(rest_client: IRestClientAsync, eid: str,
                                               properties: List[Dict[str, Any]])\
        -> UpdateEntityPropertiesResponse | ErrorList:
    return await rest_client.invoke_rest_patch_async(f'/entities/{eid}/properties?force=true',
                                                     UpdateEntityRequest.create(properties),
                                                     UpdateEntityPropertiesResponse)

def close_entity(rest_client: IRestClient, eid: str, reason: str) -> None | ErrorList:
    return rest_client.invoke_rest_post(f'/entities/{eid}/reviews/close', EntityReview.create(reason),
                                        None)

async def close_entity_async(rest_client: IRestClientAsync, eid: str, reason: str) -> None | ErrorList:
    return await rest_client.invoke_rest_post_async(f'/entities/{eid}/reviews/close', EntityReview.create(reason),
                                                   None)

def reopen_entity(rest_client: IRestClient, eid: str, reason: str) -> None | ErrorList:
    return rest_client.invoke_rest_post(f'/entities/{eid}/reviews/reopen', EntityReview.create(reason),
                                        None)

async def reopen_entity_async(rest_client: IRestClientAsync, eid: str, reason: str) -> None | ErrorList:
    return await rest_client.invoke_rest_post_async(f'/entities/{eid}/reviews/reopen', EntityReview.create(reason),
                                                   None)
