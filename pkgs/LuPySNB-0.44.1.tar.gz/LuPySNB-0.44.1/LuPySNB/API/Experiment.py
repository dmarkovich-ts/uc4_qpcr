from typing import Dict, Any, Optional, Union

from LuPySNB.API import IRestClientAsync
from LuPySNB.model.exceptions.LuPySNBInternalException import LuPySNBInternalException
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.requests.CreateExperimentRequest import CreateExperimentRequest
from LuPySNB.model.requests.CreateADORequest import CreateADORequest
from LuPySNB.API.IRestClient import IRestClient
from LuPySNB.API.Entity import get_entity_id_by_name, get_entity_id_by_name_async
from LuPySNB.model.responses.CreateExperimentResponse import CreateExperimentResponse
from LuPySNB.model.responses.CreateADOResponse import CreateADOResponse


def create_ado(rest_client: IRestClient, ado_type: str, template_id: str, attributes: Dict[str, Any]) -> Union[CreateADOResponse, ErrorList]:
    ado_req = CreateADORequest.create(ado_type, template_id, attributes)
    return rest_client.invoke_rest_post("entities/?force=true", ado_req, CreateADOResponse)


async def create_ado_async(rest_client: IRestClientAsync, ado_type: str, template_id: str, attributes: Dict[str, Any]) -> Union[CreateADOResponse, ErrorList]:
    ado_req = CreateADORequest.create(ado_type, template_id, attributes)
    return await rest_client.invoke_rest_post_async("entities/?force=true", ado_req, CreateADOResponse)


def create_experiment(rest_client: IRestClient, attributes: Dict[str, Any], template_name: str, notebook_name: str) \
        -> Union[CreateExperimentResponse, ErrorList]:
    template_eid = get_experiment_id_by_name(rest_client, template_name, True)
    if template_eid is None:
        raise LuPySNBInternalException(f'Experiment Template {template_name} does not exist.')

    notebook_eid = None
    if notebook_name is not None:
        notebook_eid = get_notebook_id_by_name(rest_client, notebook_name)
        if notebook_eid is None:
            raise LuPySNBInternalException(f'Notebook {notebook_name} does not exist.')

    experiment_req = CreateExperimentRequest.create(template_eid, notebook_eid, attributes)
    return rest_client.invoke_rest_post("entities/?force=true", experiment_req, CreateExperimentResponse)


async def create_experiment_async(rest_client: IRestClientAsync, attributes: Dict[str, Any], template_name: str,
                                  notebook_name: str) -> Union[CreateExperimentResponse, ErrorList]:
    template_eid = await get_experiment_id_by_name_async(rest_client, template_name, True)
    if template_eid is None:
        raise LuPySNBInternalException(f'Experiment Template {template_name} does not exist.')

    notebook_eid = None
    if notebook_name is not None:
        notebook_eid = await get_notebook_id_by_name_async(rest_client, notebook_name)
        if notebook_eid is None:
            raise LuPySNBInternalException(f'Notebook {notebook_name} does not exist.')

    experiment_req = CreateExperimentRequest.create(template_eid, notebook_eid, attributes)
    return await rest_client.invoke_rest_post_async("entities/?force=true", experiment_req, CreateExperimentResponse)


def get_experiment_id_by_name(rest_client: IRestClient, experiment_name: str, is_template: bool) -> Optional[str]:
    return get_entity_id_by_name(rest_client, experiment_name, 'experiment', is_template)


async def get_experiment_id_by_name_async(rest_client: IRestClientAsync, experiment_name: str,
                                          is_template: bool) -> Optional[str]:
    return await get_entity_id_by_name_async(rest_client, experiment_name, 'experiment', is_template)


def get_notebook_id_by_name(rest_client: IRestClient, notebook_name: str) -> Optional[str]:
    return get_entity_id_by_name(rest_client, notebook_name, 'journal', False)


async def get_notebook_id_by_name_async(rest_client: IRestClientAsync, notebook_name: str) -> Optional[str]:
    return await get_entity_id_by_name_async(rest_client, notebook_name, 'journal', False)
