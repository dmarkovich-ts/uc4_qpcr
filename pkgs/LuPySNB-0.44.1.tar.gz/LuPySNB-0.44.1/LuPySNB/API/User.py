from LuPySNB.API.IRestClient import IRestClient
from LuPySNB.model.DTOs.UserDefinition import UserDefinition
from LuPySNB.model.requests.UserRequest import LundbeckOrganization, CreateUser
from LuPySNB.model.responses.ErrorList import ErrorList
from typing import Union, List
from LuPySNB.API import IRestClientAsync
from LuPySNB.model.responses.UserResponse import UserResponse,UserResponseList


def get_users(rest_client: IRestClient, query_string: str = None,enabled: bool = True) -> Union[UserResponseList, ErrorList]:
    enabled = str(enabled).lower()
    if query_string is None:
        endpoint = f'users/?&enabled={enabled}'
    else:
        endpoint = f'users/?q={query_string}&enabled={enabled}'
    return rest_client.invoke_rest_get(endpoint, UserResponseList)


async def get_users_async(rest_client: IRestClientAsync, query_string: str = None,enabled: bool = True) -> Union[UserResponseList, ErrorList]:
    enabled = str(enabled).lower()
    if query_string is None:
        endpoint = f'users/?&enabled={enabled}'
    else:
        endpoint = f'users/?q={query_string}&enabled={enabled}'
    return await rest_client.invoke_rest_get_async(endpoint, UserResponseList)


def get_users_by_alias(rest_client: IRestClient, initials: str) -> Union[List[UserDefinition], ErrorList]:
    users = get_users(rest_client)
    return list(filter(lambda x: x.attributes.alias is not None and x.attributes.alias.lower() == initials.lower(), users.data))\
        if isinstance(users, UserResponseList) else users


async def get_users_by_alias_async(rest_client: IRestClientAsync, initials: str) -> Union[List[UserDefinition], ErrorList]:
    users = await get_users_async(rest_client)
    return list(filter(lambda x: x.attributes.alias is not None and x.attributes.alias.lower() == initials.lower(), users.data))\
        if isinstance(users, UserResponseList) else users

def create_user(rest_client: IRestClient, alias: str, fist_name: str, last_name: str, organization: LundbeckOrganization, country: str = 'Denmark') -> Union[UserResponse, ErrorList]:
    new_user = CreateUser.create(alias, fist_name, last_name, organization, country)
    return rest_client.invoke_rest_post('users', new_user, UserResponse)

async def create_user_async(rest_client: IRestClientAsync, alias: str, fist_name: str, last_name: str, organization: LundbeckOrganization, country: str = 'Denmark') -> Union[UserResponse, ErrorList]:
    new_user = CreateUser.create(alias, fist_name, last_name, organization, country)
    return await rest_client.invoke_rest_post_async('users', new_user, UserResponse)

def get_user_by_id(rest_client: IRestClient, id: str) -> UserResponse:
    return rest_client.invoke_rest_get('users/' + id, UserResponse)

async def get_user_by_id_async(rest_client: IRestClientAsync, id: str) -> UserResponse:
    return await rest_client.invoke_rest_get_async('users/' + id, UserResponse)

