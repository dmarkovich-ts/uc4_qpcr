from LuPySNB.model.exceptions.LuPySNBException import LuPySNBException


class LuPySNBArgumentException(LuPySNBException):
    pass
