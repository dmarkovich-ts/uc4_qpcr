class LuPySNBException(Exception):
    pass