from LuPySNB.model.exceptions.LuPySNBException import LuPySNBException


class SignalsException(LuPySNBException):
    pass
