from LuPySNB.model.exceptions.LuPySNBException import LuPySNBException


class LuPySNBInternalException(LuPySNBException):
    pass
