from LuPySNB.model.DTOs.Container import Container
from LuPySNB.model.responses.APIPaginatedResponse import APIPaginatedResponse
from LuPySNB.model.responses.APIResponse import APIResponse
from LuPySNB.model.responses.APIPaginatedQueryResponse import APIPaginatedQueryResponse


class ContainerResponse(APIResponse):
    data: Container


ContainerResponseList = APIPaginatedResponse[Container]
ContainerListFromQuery = APIPaginatedQueryResponse[Container]
