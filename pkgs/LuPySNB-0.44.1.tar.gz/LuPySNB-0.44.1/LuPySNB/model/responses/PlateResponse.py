from abc import ABC
from typing import List
from pydantic import computed_field
from LuPySNB.model.responses.APIResponse import APIResponse
from LuPySNB.model.DTOs.Plate import Plate
from LuPySNB.model.DTOs.AttributeDescriptor import AttributeDescriptor


class PlateResponseBase(APIResponse, ABC):
    included: List[AttributeDescriptor]

    @computed_field
    @property
    def digest(self) -> str | None:
        entity_included = next(filter(lambda item: item.type == 'entity' and hasattr(item, 'attributes') and
                                                   item.attributes.type == 'plateContainer', self.included), None)
        return entity_included.attributes.digest if entity_included else None


class PlateResponse(PlateResponseBase):
    data: Plate


class PlateListResponse(PlateResponseBase):
    data: List[Plate]





