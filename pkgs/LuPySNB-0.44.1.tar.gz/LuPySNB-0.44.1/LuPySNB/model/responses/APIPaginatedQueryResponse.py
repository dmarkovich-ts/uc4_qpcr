from typing import Generic, TypeVar, List, Self, Optional
import re
from pydantic import BaseModel

from LuPySNB.model.responses.APIResponse import APIResponse

T = TypeVar("T")


class APIPaginatedQueryResponse(APIResponse, Generic[T]):
    class Links(BaseModel):
        self: str

    links: Links = None

    class Meta(BaseModel):
        count: int
        total: int

    meta: Meta

    data: List[T]

    def extend(self, other: Self):
        self.links = other.links
        self.data.extend(other.data)

    def next_link(self) -> Optional[str]:
        return re.sub(r"&page\[offset]=\d+", "", self.links.self) + f"&page[offset]={len(self.data)}" \
            if (self.links is not None) and (self.meta.total > len(self.data)) else None
