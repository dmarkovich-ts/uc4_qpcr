from typing import Generic, TypeVar, List, Self, Optional
from pydantic import BaseModel

from LuPySNB.model.responses.APIResponse import APIResponse

T = TypeVar("T")


class APIPaginatedResponse(APIResponse, Generic[T]):
    class Links(BaseModel):
        self: str
        first: str = None
        next: str = None

    links: Links = None
    data: List[T]

    def extend(self, other: Self):
        self.links = other.links
        self.data.extend(other.data)

    def next_link(self) -> Optional[str]:
        return self.links.next if self.links is not None else None
