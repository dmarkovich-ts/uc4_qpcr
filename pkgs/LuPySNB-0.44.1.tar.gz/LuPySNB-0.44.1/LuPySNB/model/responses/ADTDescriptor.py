from pydantic import BaseModel
from typing import List, Optional
from LuPySNB.model.DTOs.EntityLink import EntityLink
from LuPySNB.model.responses.APIResponse import APIResponse


class ADTDescriptor(APIResponse):
    links: EntityLink

    class Data(BaseModel):
        type: str
        id: str

        class Attributes(BaseModel):
            id: str
            type: str
            templateId: str = None

            class Column(BaseModel):
                key: str
                title: str
                type: str
                saved: Optional[bool] = None
                method: str = None

            columns: List[Column] = []
        attributes: Attributes

    data: Data
