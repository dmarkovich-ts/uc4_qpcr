from LuPySNB.model.responses.APIResponse import APIResponse
from LuPySNB.model.responses.EntityDescriptor import EntityDescriptor


class GetEntityResponse(APIResponse):
    data: EntityDescriptor
