from typing import Optional

from pydantic import BaseModel


class File(BaseModel):

    mime_type: str
    filename: Optional[str] = None
    content: bytes
