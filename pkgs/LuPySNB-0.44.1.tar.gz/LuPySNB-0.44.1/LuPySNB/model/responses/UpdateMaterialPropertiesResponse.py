from datetime import datetime
from typing import Union
from pydantic import BaseModel
from LuPySNB.model.DTOs import MaterialFieldValue
from LuPySNB.model.DTOs.EntityLink import EntityLink
from LuPySNB.model.responses.APIResponse import APIResponse


class UpdateMaterialPropertiesResponse(APIResponse):
    links: EntityLink

    class Data(BaseModel):
        type: str
        id: str
        name: str
        dataType: str
        inUse: bool

        class Attributes(BaseModel):
            id: str
            name: str
            value: Union[datetime, str, MaterialFieldValue.InternalReferenceValue, MaterialFieldValue.UserIdFieldValue]
