from typing import List

from LuPySNB.model.responses.APIResponse import APIResponse
from LuPySNB.model.DTOs.Container import Container


class CreateContainerResponse(APIResponse):
    data: List[Container]
