from typing import List
from LuPySNB.model.responses.APIResponse import APIResponse
from LuPySNB.model.DTOs.MaterialLibraryDescriptor import MaterialLibraryDescriptor


class MaterialLibraryList(APIResponse):
    data: List[MaterialLibraryDescriptor]
