from typing import List, Optional
from pydantic import BaseModel
from LuPySNB.model.DTOs.Field import Field
from LuPySNB.model.DTOs.EntityLink import EntityLink
from LuPySNB.model.responses.APIResponse import APIResponse


class MaterialsTableRow(APIResponse):
    class Data(BaseModel):
        type: str
        id: str

        class Attributes(BaseModel):
            id: str
            eid: Optional[str] = None
            assetId: Optional[str] = None
            assetTypeId: Optional[str] = None
            materialId: Optional[str] = None

            cells: List[Field] = []

        attributes: Attributes

    links: EntityLink

    data: Data


class MaterialsTable(APIResponse):
    links: EntityLink
    data: List[MaterialsTableRow.Data]
