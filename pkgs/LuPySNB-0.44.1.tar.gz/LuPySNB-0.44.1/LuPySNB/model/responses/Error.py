from LuPySNB.model.responses.APIResponse import APIResponse


class Error(APIResponse):
    status: int
    code: str
    title: str = None
    detail: str = None

    def __str__(self):
        error_str = f'{self.status} {self.code}'
        if self.title is not None:
            error_str += f': {self.title}'
            if self.detail is not None:
                error_str += f' - {self.detail}'
        elif self.detail is not None:
            error_str += f': {self.detail}'
        return error_str
