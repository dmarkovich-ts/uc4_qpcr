from LuPySNB.model.responses.APIResponse import APIResponse
from LuPySNB.model.DTOs.EntityLink import EntityLink
from pydantic import BaseModel

class MaterialsTableDescriptor(APIResponse):
    links: EntityLink

    class Data(BaseModel):
        type: str
        id: str

        class Attributes(BaseModel):
            id: str
            type: str
            libraryName: str

            class Column(BaseModel):
                key: str
                title: str
                type: str
                hidden: bool | None = None
                isMaterialField: bool | None = None
            
            columns: list[Column] = []
        
        attributes: Attributes
    
    data: Data
