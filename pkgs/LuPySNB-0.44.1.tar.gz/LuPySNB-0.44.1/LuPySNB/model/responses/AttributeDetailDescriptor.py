from typing import List
from pydantic import BaseModel

from LuPySNB.model.DTOs.HierarchicalOptions import HierarchicalOptions
from LuPySNB.model.responses.APIResponse import APIResponse
from LuPySNB.model.DTOs.EntityLink import EntityLink


class AttributeDetailDescriptor(APIResponse):
    links: EntityLink

    class Data(BaseModel):
        type: str
        id: str
        links: EntityLink

        class Attributes(BaseModel):
            id: str
            name: str
            type: str
            options: List[str] = None
            hierarchicalOptions: List[HierarchicalOptions] = None

        attributes: Attributes

        class Relationships(BaseModel):
            class ParentAttribute(BaseModel):
                class Data(BaseModel):
                    type: str
                    id: str

                data: Data

            parentAttribute: ParentAttribute = None

        relationships: Relationships = None

    data: Data
