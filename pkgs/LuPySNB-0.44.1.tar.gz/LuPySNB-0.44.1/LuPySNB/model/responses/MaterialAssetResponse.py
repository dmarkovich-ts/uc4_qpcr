from typing import List
from LuPySNB.model.DTOs.EntityLink import EntityLink
from LuPySNB.model.DTOs.MaterialLibraryItem import MaterialLibraryItem
from LuPySNB.model.responses.APIPaginatedResponse import APIPaginatedResponse
from LuPySNB.model.responses.APIResponse import APIResponse


class MaterialAssetResponse(APIResponse):
    data: MaterialLibraryItem


MaterialAssetResponseList = APIPaginatedResponse[MaterialLibraryItem]
