from typing import Any, Self, Optional

from pydantic import BaseModel


class APIResponse(BaseModel):

    def next_link(self) -> Optional[str]:
        return None

    def extend(self, other: Self):
        pass

