from LuPySNB.model.responses.APIResponse import APIResponse
from LuPySNB.model.DTOs.ContainerType import ContainerType
from LuPySNB.model.responses.APIPaginatedResponse import APIPaginatedResponse


class ContainerTypeResponse(APIResponse):
    data: ContainerType


ContainerTypeResponseList = APIPaginatedResponse[ContainerType]
