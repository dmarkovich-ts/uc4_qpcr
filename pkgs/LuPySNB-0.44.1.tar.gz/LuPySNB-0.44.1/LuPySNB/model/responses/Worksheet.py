from pydantic import BaseModel
from typing import List
from LuPySNB.model.DTOs.EntityLink import EntityLink
from LuPySNB.model.DTOs.Field import Field
from LuPySNB.model.DTOs.WorksheetFieldsDefinition import WorksheetFieldsDefinition
from LuPySNB.model.responses.APIResponse import APIResponse


class Worksheet(APIResponse):
    links: EntityLink

    class Data(BaseModel):
        type: str
        id: str

        class Attributes(BaseModel):
            fields: List[Field]

        attributes: Attributes

    data: Data

    included: List[WorksheetFieldsDefinition]
