from pydantic import BaseModel, computed_field
from typing import List, Optional, Any
from LuPySNB.model.DTOs.AttributeDescriptor import AttributeDescriptor
from LuPySNB.model.DTOs.EntityLink import EntityLink
from LuPySNB.model.DTOs.FieldValue import FieldValueTypes
from LuPySNB.model.responses.APIResponse import APIResponse


class ADTContent(APIResponse):
    links: EntityLink

    class Data(BaseModel):
        type: str
        id: str

        class Attributes(BaseModel):
            type: str
            id: str

            class Cell(BaseModel):
                key: str
                type: str
                name: str

                class Content(BaseModel):
                    value: FieldValueTypes = None
                    display: Optional[str] = None
                    type: Optional[str] = None
                    values: FieldValueTypes = None

                content: Optional[Content]

            cells: List[Cell] = None
            method: str = None

            @computed_field
            @property
            def is_header(self) -> bool:
                return self.method == 'header'

        attributes: Attributes

    data: List[Data]

    included: List[AttributeDescriptor | Any]

    @computed_field
    @property
    def digest(self) -> str | None:
        entity_included = next(filter(lambda item: item.type == 'entity' and hasattr(item, 'attributes') and
                                                   item.attributes.type == 'grid', self.included), None)
        return entity_included.attributes.digest if entity_included else None

    def name(self):
        adt_data = next((item for item in self.included if isinstance(item, self.ADTData)), None)
        return adt_data.attributes.name if adt_data else None
