from pydantic import BaseModel
from LuPySNB.model.responses.APIResponse import APIResponse
from LuPySNB.model.DTOs.EntityLink import EntityLink


class Attachment(APIResponse):
    links: EntityLink = None

    class Data(BaseModel):
        id: str
        type: str

    data: Data
