from typing import List
from LuPySNB.model.DTOs.AttributeDescriptor import AttributeDescriptor
from LuPySNB.model.responses.APIResponse import APIResponse


class AttributeDescriptorList(APIResponse):
    data: List[AttributeDescriptor]
