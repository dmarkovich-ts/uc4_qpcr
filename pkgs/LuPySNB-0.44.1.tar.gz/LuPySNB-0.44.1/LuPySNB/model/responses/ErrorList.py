from typing import List
from LuPySNB.model.responses.APIResponse import APIResponse
from LuPySNB.model.responses.Error import Error


class ErrorList(APIResponse):
    errors: List[Error]

    def __str__(self):
        return 'LuPySNB ErrorList:\n'+ '\n'.join([f'{i}: {e}' for i,e in enumerate(self.errors)])