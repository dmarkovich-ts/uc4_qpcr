from pydantic import BaseModel, Field, computed_field
from typing import Dict, List, Any, Optional
from datetime import datetime
from LuPySNB.model.responses.APIResponse import APIResponse
from LuPySNB.model.DTOs.EntityLink import EntityLink
from LuPySNB.model.DTOs.EntityRelationship import EntityRelationship
from LuPySNB.model.DTOs.EntityRelationshipList import EntityRelationshipList
from LuPySNB.model.DTOs.AttributeDescriptor import AttributeDescriptor


class EntityDescriptor(APIResponse):
    links: EntityLink = None
    id: str
    type: str

    class Attributes(BaseModel):
        libraryName: str | None = None
        id: str = None
        eid: str
        name: str
        description: str = None
        owner: str = None
        createdBy: str = None
        createdAt: datetime
        editedBy: str = None
        editedAt: datetime = None
        modifiedAt: datetime = None
        type: str
        state: str = None
        digest: str = None
        tags: Dict = None

        class AttributeValue(BaseModel):
            value: str
            values: List[str] = None
            details_: Dict[str, Any] = Field(alias='details', default=None)

            @computed_field
            @property
            def details(self) -> Dict[str, Dict[str, Any]]:
                return self.details_ if self.values is not None else {self.value: self.details_}

        fields: Dict[str, AttributeValue] = None

    attributes: Attributes

    relationships: Optional[Dict[str, EntityRelationship | EntityRelationshipList]] = None

    included: Optional[List[AttributeDescriptor]] = None
