from pydantic import BaseModel

from LuPySNB.model.DTOs.EntityLink import EntityLink
from LuPySNB.model.responses.APIResponse import APIResponse


class Page(APIResponse):
    class PageData(BaseModel):
        class PageAttributes(BaseModel):
            name: str | None = None
            index: int
        type: str
        id: str
        attributes: PageAttributes
    links: EntityLink
    data: PageData

class PageList(APIResponse):
    class PageListData(BaseModel):
        class PageListAttributes(BaseModel):
            class PageListAttributesEntity(BaseModel):
                entityEid: str
                entityName: str
                index: int
            name: str
            index: int
            entities: list[PageListAttributesEntity]
        type: str
        id: str
        attributes: PageListAttributes
    links: EntityLink
    data: list[PageListData]
