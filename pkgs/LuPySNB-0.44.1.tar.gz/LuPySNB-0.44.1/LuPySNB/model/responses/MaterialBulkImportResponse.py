from datetime import datetime

from pydantic import BaseModel

from LuPySNB.model.responses.APIResponse import APIResponse


class MaterialBulkImportResponse(APIResponse):
    class Data(BaseModel):
        type: str
        id: str

        class Attributes(BaseModel):
            createdAt: datetime
            startedAt: datetime = None
            completedAt: datetime = None
            status: str
            rule: str
            zoneId: str = None

            class Report(BaseModel):
                filename: str = None
                succeeded: int
                duplicated: int
                failed: int

            report: Report

        attributes: Attributes

    data: Data
