from datetime import datetime
from typing import Union, List
from pydantic import BaseModel
from LuPySNB.model.DTOs.EntityLink import EntityLink

from LuPySNB.model.responses.APIResponse import APIResponse


class UpdateEntityPropertiesResponse(APIResponse):
    class Data(BaseModel):
        type: str
        id: str

        class Attributes(BaseModel):
            id: str
            name: str
            value: Union[datetime, str] = None
            values: List[str] = None

        attributes: Attributes

    links: EntityLink

    data: List[Data]

