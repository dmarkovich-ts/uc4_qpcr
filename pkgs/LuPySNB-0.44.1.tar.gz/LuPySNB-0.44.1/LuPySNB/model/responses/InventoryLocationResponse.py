from LuPySNB.model.responses.APIResponse import APIResponse
from LuPySNB.model.DTOs.EntityLink import EntityLink
from LuPySNB.model.DTOs.InventoryLocation import InventoryLocation


class InventoryLocationResponse(APIResponse):
    links: EntityLink
    data: InventoryLocation
