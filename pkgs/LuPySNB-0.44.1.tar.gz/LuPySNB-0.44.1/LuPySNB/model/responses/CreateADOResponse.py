from LuPySNB.model.DTOs.EntityLink import EntityLink
from LuPySNB.model.responses.APIResponse import APIResponse
from LuPySNB.model.responses.EntityDescriptor import EntityDescriptor


class CreateADOResponse(APIResponse):
    links: EntityLink
    data: EntityDescriptor
