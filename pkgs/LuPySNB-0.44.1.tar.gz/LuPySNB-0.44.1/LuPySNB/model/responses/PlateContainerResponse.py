from pydantic import RootModel
from LuPySNB.model.responses.APIResponse import APIResponse
from LuPySNB.model.DTOs.PlateContainer import PlateContainer


class PlateContainerResponse(APIResponse, PlateContainer):
    pass



