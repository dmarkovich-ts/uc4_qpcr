from LuPySNB.model.responses.APIPaginatedResponse import APIPaginatedResponse
from LuPySNB.model.DTOs.UserDefinition import UserDefinition
from LuPySNB.model.responses.APIResponse import APIResponse


class UserResponse(APIResponse):
    data: UserDefinition

UserResponseList = APIPaginatedResponse[UserDefinition]
