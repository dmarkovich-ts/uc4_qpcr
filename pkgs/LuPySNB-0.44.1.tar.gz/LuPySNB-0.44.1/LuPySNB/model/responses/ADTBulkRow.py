from pydantic import BaseModel
from LuPySNB.model.DTOs.Field import Field
from LuPySNB.model.DTOs.EntityLink import EntityLink
from LuPySNB.model.responses.APIResponse import APIResponse


class ADTBulkRow(APIResponse):
    class Data(BaseModel):
        type: str
        id: str
        links: EntityLink

        class Attributes(BaseModel):
            id: str
            type: str

            cells: list[Field] = []

        attributes: Attributes

    data: list[Data]



