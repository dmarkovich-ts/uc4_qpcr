from LuPySNB.model.DTOs.InventoryItemField import InventoryItemField

ContainerField = InventoryItemField

