from typing import Optional

from pydantic import BaseModel
from LuPySNB.model.DTOs.EntityRelationship import EntityRelationship
from LuPySNB.model.DTOs.EntityRelationshipList import EntityRelationshipList


class EntityRelations(BaseModel):
    ancestors: EntityRelationshipList = []
    template: Optional[EntityRelationship] = None
