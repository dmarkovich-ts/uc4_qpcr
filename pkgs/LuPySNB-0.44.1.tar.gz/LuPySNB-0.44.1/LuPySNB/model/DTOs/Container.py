from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel
from LuPySNB.model.DTOs.EntityLink import EntityLink
from LuPySNB.model.DTOs.FieldValue import FieldValueTypes


class Container(BaseModel):
    type: str
    id: str
    links: EntityLink

    class Attributes(BaseModel):
        id: str
        name: str
        typeId: str
        typeName: str
        status: str
        state: str
        barcode: str
        coordinateX: int = None
        coordinateY: int = None
        unit: str = None
        amount: float = None
        displayAmount: str = None
        createdAt: datetime
        updatedAt: datetime
        digest: str

        class Location(BaseModel):
            id: str

        class Contents(BaseModel):
            entityId: str
            entityType: str
            createdAt: datetime
            updatedAt: datetime

        class Ancestors(BaseModel):
            id: str
            name: str
            coordinateX: int | None = None
            coordinateY: int | None = None

        class Fields(BaseModel):
            id: str

            class Definition(BaseModel):
                key: str
                title: str

            class Content(BaseModel):
                value: FieldValueTypes | None = None

            definition: Definition
            content: Optional[Content] | None = None

        contents: List[Contents]
        location: Location
        ancestors: List[Ancestors]
        fields: List[Fields]

    attributes: Attributes
