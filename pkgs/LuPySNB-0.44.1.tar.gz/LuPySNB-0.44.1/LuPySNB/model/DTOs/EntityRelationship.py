from typing import Optional
from pydantic import BaseModel
from LuPySNB.model.DTOs.EntityLink import EntityLink
from LuPySNB.model.DTOs.EntityRelationshipNode import EntityRelationshipNode


class EntityRelationship(BaseModel):
    links: Optional[EntityLink] = None
    data: Optional[EntityRelationshipNode] = None
