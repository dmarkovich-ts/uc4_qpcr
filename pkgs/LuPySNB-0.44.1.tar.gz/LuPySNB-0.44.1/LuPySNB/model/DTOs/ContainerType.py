from pydantic import BaseModel
from LuPySNB.model.DTOs.FieldDefinition import FieldDefinition
from LuPySNB.model.responses.APIResponse import APIResponse
from typing import List, Dict


class ContainerType(APIResponse):
    type: str
    id: str

    class Attributes(BaseModel):
        name: str

        class Fields(BaseModel):
            id: str
            definition: FieldDefinition

        fields: List[Fields]

    attributes: Attributes

    def get_field_map(self) -> Dict[str, FieldDefinition]:
        return dict(map(lambda x: (x.definition.title, x.definition), self.attributes.fields))
