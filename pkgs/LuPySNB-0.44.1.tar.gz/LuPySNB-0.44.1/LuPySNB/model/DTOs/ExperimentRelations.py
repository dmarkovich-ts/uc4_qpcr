from pydantic import BaseModel
from LuPySNB.model.DTOs.EntityRelationship import EntityRelationship
from LuPySNB.model.DTOs.EntityRelationshipList import EntityRelationshipList


class ExperimentRelations(BaseModel):
    ancestors: EntityRelationshipList = []
    template: EntityRelationship

