from typing import List
from pydantic import BaseModel
from LuPySNB.model.DTOs.EntityRelationshipNode import EntityRelationshipNode


class EntityRelationshipList(BaseModel):
    data: List[EntityRelationshipNode] = []
