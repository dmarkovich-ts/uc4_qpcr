from typing import List, Dict, Optional
from pydantic import BaseModel


class LibraryField(BaseModel):
    id: str
    name: str
    dataType: str
    mandatory: bool
    hidden: bool
    definedBy: str


class Numbering(BaseModel):
    format: str


class MaterialLibraryDescriptor(BaseModel):
    type: str = 'assetType'
    id: str

    class Attributes(BaseModel):
        name: str
        id: str
        enabled: bool

        class Assets(BaseModel):
            assetNameFieldId: str
            displayName: str
            fields: List[LibraryField]
            numbering: Numbering

        assets: Assets

        class Batches(BaseModel):
            displayName: str | None = None
            fields: List[LibraryField]
            numbering: Numbering | None = None

        batches: Batches

    attributes: Attributes

    def get_material_library_asset_field_map(self) -> Dict[str, LibraryField]:
        return dict(map(lambda x: (x.name, x), self.attributes.assets.fields))

    def get_material_library_batch_field_map(self) -> Dict[str, LibraryField]:
        return dict(map(lambda x: (x.name, x), self.attributes.batches.fields))
