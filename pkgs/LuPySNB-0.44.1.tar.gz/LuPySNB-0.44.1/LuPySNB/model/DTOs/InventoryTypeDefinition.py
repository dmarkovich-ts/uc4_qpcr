from typing import Optional, List, Dict
from pydantic import BaseModel

from LuPySNB.model.DTOs.FieldDefinition import FieldDefinition


class InventoryTypeDefinition(BaseModel):
    type: str
    id: str

    class Attributes(BaseModel):
        id: str
        name: str
        entityType: str
        description: Optional[str] = None
        isMovable: bool
        inUse: bool

        class Field(BaseModel):
            id: str

            class Definition(BaseModel):
                key: str
                title: str
                type: str = None
                attributeListEid: Optional[str] = None
                hidden: Optional[bool] = None
                multiSelect: Optional[bool] = None
                isRequired: Optional[bool] = None

            definition: Definition

        fields: List[Field]

    attributes: Attributes

    def get_field_map(self) -> Dict[str, FieldDefinition]:
        return dict(map(lambda x: (x.definition.title, FieldDefinition(key=x.definition.key,
                                                                       type=x.definition.type,
                                                                       title=x.definition.title)),
                        self.attributes.fields))
