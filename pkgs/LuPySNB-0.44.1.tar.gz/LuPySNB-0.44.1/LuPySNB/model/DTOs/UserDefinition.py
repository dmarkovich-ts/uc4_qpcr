from typing import Optional, List
from urllib.request import DataHandler

from pydantic import BaseModel

class UserDefinition(BaseModel):
    type: str
    id: str

    class Attributes(BaseModel):

        class License(BaseModel):
            id: str
            name: str
            active: bool

        lastLoginAt: Optional[str] = None
        createdAt: str
        userId: str
        userName: str
        alias: Optional[str] = None
        email: Optional[str] = None
        firstName: Optional[str] = None
        lastName: Optional[str] = None
        country: Optional[str] = None
        organization: Optional[str] = None
        isEnabled: bool
        licenses: List[License]

    class Relationships(BaseModel):

        class Roles(BaseModel):

            class Data(BaseModel):
                type: str
                id: str

            data: List[Data]

        roles: Roles


    relationships: Relationships
    attributes: Attributes