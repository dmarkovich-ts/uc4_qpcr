from pydantic import BaseModel
from typing import Optional

def get_entity_type_from_eid(eid: str) -> str:
    e_type = eid.split(":")[0]
    return e_type.split("-")[0] if '-' in e_type else e_type


class EntityRelationshipNode(BaseModel):
    type: Optional[str] = None
    id: str
