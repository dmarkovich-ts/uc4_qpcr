from pydantic import BaseModel
from typing import Any, Dict

from LuPySNB.model.DTOs.AttributeDescriptor import AttributeDescriptor


class PlateContainer(BaseModel):
    class Data(BaseModel):
        type: str = 'plateContainer'
        id: str

        class Attributes(BaseModel):
            type: str
            id: str
            eid: str
            name: str
            numberOfRows: int
            numberOfColumns: int
            numberOfPlates: int

        attributes: Attributes

    data: Data

    class AnnotationLayerDefinition(BaseModel):
        type: str = 'annotationLayerDefinition'
        id: str

        class Attributes(BaseModel):
            id: str
            type: str

            class AnnotationLayer(BaseModel):
                id: str
                name: str
                dataType: str
                annotationClass: str
                isPredefined: bool

            annotationLayers: list[AnnotationLayer]

        attributes: Attributes

    included: list[AnnotationLayerDefinition | AttributeDescriptor | Any]

    def get_annotation_layer_map(self) -> Dict[str, AnnotationLayerDefinition.Attributes.AnnotationLayer]:
        return dict(map(lambda x: (x.name, x),
                        next(map(lambda x: x.attributes.annotationLayers,
                                 filter(lambda y: isinstance(y, PlateContainer.AnnotationLayerDefinition),
                                        self.included)))))

