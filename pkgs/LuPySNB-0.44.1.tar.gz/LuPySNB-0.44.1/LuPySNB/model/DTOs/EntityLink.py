from pydantic import BaseModel


class EntityLink(BaseModel):
    self: str = None

