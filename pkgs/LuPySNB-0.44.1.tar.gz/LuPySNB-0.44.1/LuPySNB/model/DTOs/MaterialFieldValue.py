from __future__ import annotations

import abc
from datetime import datetime
from pydantic import BaseModel, computed_field
from LuPySNB.model.exceptions.LuPySNBInternalException import LuPySNBInternalException

InputTypes = str | list[str] | int | float | datetime | tuple


class MaterialFieldValue(BaseModel, abc.ABC):
    @classmethod
    def create_value(cls, field_type: str, elements: InputTypes) -> MaterialFieldValue | str | list[str] | int | float | datetime:
        if field_type in ['TEXT', 'ATTRIBUTE', 'INTEGER', 'DECIMAL']:
            if not type(elements) in [str, list, int, float]:
                raise LuPySNBInternalException(f'Invalid argument for field type {field_type}: {elements}')
            return elements
        elif field_type in ['DATETIME']:
            if not isinstance(elements, datetime):
                raise LuPySNBInternalException(f'Invalid argument for field type {field_type}: {elements}')
            return elements
        elif field_type in ['LINK']:
            if not isinstance(elements, tuple) or (len(elements) != 3):
                raise LuPySNBInternalException(f'Invalid argument for field type {field_type}: {elements}')
            return InternalReferenceValue(eid=elements[0], name=elements[1], type=elements[2])
        elif field_type in ['EXTERNAL_LINK']:
            if not isinstance(elements, tuple) or (len(elements) != 2):
                raise LuPySNBInternalException(f'Invalid argument for field type {field_type}: {elements}')
            return ExternalReferenceValue(link=elements[0], alias=elements[1])
        elif field_type in ['ATTACHED_FILE']:
            if not isinstance(elements, tuple) or (len(elements) != 2):
                raise LuPySNBInternalException(f'Invalid argument for field type {field_type}: {elements}')
            return FileAttachmentValue(filename=elements[0], base64=elements[1])
        else:
            raise LuPySNBInternalException(f'Unsupported field type: {field_type}')


    @computed_field
    @property
    @abc.abstractmethod
    def display_value(self) -> str:
        """Display value"""


class ComplexValue(MaterialFieldValue):
    rawValue: str
    displayValue: str

    @computed_field
    @property
    def display_value(self) -> str:
        return self.displayValue



class ExternalReferenceValue(MaterialFieldValue):
    link: str
    alias: str

    @computed_field
    @property
    def display_value(self) -> str:
        return self.alias


class InternalReferenceValue(MaterialFieldValue):
    eid: str
    name: str
    type: str

    @computed_field
    @property
    def display_value(self) -> str:
        return self.name


class UserIdFieldValue(MaterialFieldValue):
    userId: str
    userName: str

    @computed_field
    @property
    def display_value(self) -> str:
        return self.userName


class FileAttachmentValue(MaterialFieldValue):
    filename: str
    base64: str

    @computed_field
    @property
    def display_value(self) -> str:
        return self.filename


MaterialFieldValueTypes = datetime | str | list[str] | int | float | ComplexValue | UserIdFieldValue | InternalReferenceValue | ExternalReferenceValue | FileAttachmentValue
