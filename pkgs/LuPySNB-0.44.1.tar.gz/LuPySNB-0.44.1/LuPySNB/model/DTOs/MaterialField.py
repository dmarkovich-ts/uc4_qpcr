from pydantic import BaseModel
from LuPySNB.model.DTOs import MaterialFieldValue


class MaterialField(BaseModel):
    id: str = None
    name: str = None

    value: MaterialFieldValue.MaterialFieldValueTypes
