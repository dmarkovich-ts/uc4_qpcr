from datetime import datetime
from typing import List, Dict, Optional
from pydantic import BaseModel, computed_field
from LuPySNB.model.DTOs.EntityLink import EntityLink
from LuPySNB.model.DTOs.MaterialFieldValue import MaterialFieldValueTypes, MaterialFieldValue


class MaterialLibraryItem(BaseModel):
    type: str
    id: str
    links: EntityLink

    class Attributes(BaseModel):
        library: str = None
        assetTypeId: str = None
        assetId: str = None
        id: Optional[str] = None
        eid: str = None
        name: str = None
        synonyms: List[str] = None
        description: str = None
        createdAt: datetime = None
        editedAt: datetime = None
        type: str = None
        digest: str = None

        class FieldValue(BaseModel):
            value: MaterialFieldValueTypes

            @computed_field
            @property
            def display_value(self) -> str:
                return self.value.display_value if isinstance(self.value, MaterialFieldValue) else str(self.value)


        fields: Dict[str, FieldValue]

    attributes: Attributes

    class Relationships(BaseModel):
        class BatchList(BaseModel):
            class Data(BaseModel):
                type: str
                id: str

            data: List[Data]

        batches: Optional[BatchList] = None

    relationships: Relationships = None
