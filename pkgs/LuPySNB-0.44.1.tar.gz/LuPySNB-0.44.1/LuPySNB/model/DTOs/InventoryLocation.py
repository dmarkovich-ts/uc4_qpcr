from typing import List, Optional, Dict

from pydantic import BaseModel

from LuPySNB.model.DTOs.EntityLink import EntityLink


class InventoryLocation(BaseModel):
    type: str
    id: str
    links: EntityLink

    class Attributes(BaseModel):
        id: str
        name: str
        digest: str
        description: Optional[str] = None
        typeId: str
        typeName: str
        status: str
        isGrid: bool
        rows: int
        columns: int
        gridLayout: Optional[str] = None
        barcode: str
        ancestors: List[Dict[str, str]]

        class Field(BaseModel):
            id: str

            class Definition(BaseModel):
                key: str
                title: str
                type: str

            definition: Definition

        fields: List[Field]

    attributes: Attributes

    def get_path(self):
        location_node_names = [x['name'] for x in (self.attributes.ancestors)]
        location_node_names.reverse()
        location_node_names.append(self.attributes.name)
        return '/' + '/'.join(location_node_names)
