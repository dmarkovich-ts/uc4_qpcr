from typing import List, Self
from pydantic import BaseModel


class HierarchicalOptions(BaseModel):
    parentValue: str
    options: List[str]

    @classmethod
    def create(cls, parent_value: str, options: List[str]) -> Self:
        return HierarchicalOptions(parentValue=parent_value, options=options)




