from __future__ import annotations
from pydantic import BaseModel, Field, SerializeAsAny, AliasChoices
from typing import List, TypeVar, Generic, Self, Optional
from LuPySNB.model.requests.APIRequest import APIRequest

T = TypeVar('T')


class QueryTermBase(BaseModel):
    pass


class QueryExpressionBase(QueryTermBase, Generic[T]):
    class QueryExpressionData(BaseModel):
        field: str
        mode: Optional[str] = None
        asType: Optional[str] = Field(serialization_alias='as', default=None)
        inObject: Optional[str] = Field(serialization_alias='in', default=None)


class QueryMatch(QueryExpressionBase[T]):
    class QueryMatchData(QueryExpressionBase.QueryExpressionData):
        value: T

    match: SerializeAsAny[QueryMatchData] = Field(serialization_alias='$match',
                                                  validation_alias=AliasChoices('$match', 'match'))

    @classmethod
    def create(cls, field: str, value: T, mode: str = None, as_type: str = None, in_object: str = None) -> Self:
        return QueryMatch(
            match=cls.QueryMatchData(field=field, value=value, mode=mode, asType=as_type, inObject=in_object))


class QueryPrefix(QueryExpressionBase[T]):
    class QueryPrefixData(QueryExpressionBase.QueryExpressionData):
        value: T

    prefix: SerializeAsAny[QueryPrefixData] = Field(serialization_alias='$prefix',
                                                    validation_alias=AliasChoices('$prefix', 'prefix'))

    @classmethod
    def create(cls, field: str, value: T, mode: str = None, as_type: str = None, in_object: str = None) -> Self:
        return QueryPrefix(
            prefix=cls.QueryPrefixData(field=field, value=value, mode=mode, asType=as_type, inObject=in_object))


class QueryDateRange(QueryExpressionBase[T]):
    class QueryDateRangeData(QueryExpressionBase.QueryExpressionData):
        from_value: Optional[str] = Field(serialization_alias='from', default=None)
        to_value: Optional[str] = Field(serialization_alias='to', default=None)
        timezone: Optional[str] = 'Europe/Copenhagen'

    range: SerializeAsAny[QueryDateRangeData] = Field(serialization_alias='$range',
                                                      validation_alias=AliasChoices('$range', 'range'))

    @classmethod
    def create(cls, field: str, from_value: str, to_value: str, mode: str = None,
               as_type: str = None, in_object: str = None) -> Self:
        return QueryDateRange(
            range=cls.QueryDateRangeData(field=field, from_value=from_value, to_value=to_value,
                                         mode=mode, asType=as_type, inObject=in_object))


class QueryExists(QueryExpressionBase[T]):
    class QueryExistsData(QueryExpressionBase.QueryExpressionData):
        pass

    exists: SerializeAsAny[QueryExistsData] = Field(serialization_alias='$exists',
                                                    validation_alias=AliasChoices('$exists', 'exists'))

    @classmethod
    def create(cls, field: str, as_type: str = None, in_object: str = None) -> Self:
        return QueryExists(exists=cls.QueryExistsData(field=field, asType=as_type, inObject=in_object))


class QueryIn(QueryExpressionBase[T]):
    class QueryInData(QueryExpressionBase.QueryExpressionData):
        values: List[T]

    match: SerializeAsAny[QueryInData] = Field(serialization_alias='$in', validation_alias=AliasChoices('$in', 'match'))

    @classmethod
    def create(cls, field: str, values: List[T], mode: str = None, as_type: str = None, in_object: str = None) -> Self:
        return QueryIn(match=cls.QueryInData(field=field, values=values, mode=mode, asType=as_type, inObject=in_object))


class QueryRange(QueryExpressionBase[T]):
    class QueryRangeData(QueryExpressionBase.QueryExpressionData):
        from_value: T = Field(serialization_alias='from')
        to_value: T =  Field(serialization_alias='to')

    range: SerializeAsAny[QueryRangeData] = Field(serialization_alias='$range',
                                                  validation_alias=AliasChoices('$range', 'range'))

    @classmethod
    def create(cls, field: str, from_value: T, to_value: T, mode: str = None, as_type: str = None,
               in_object: str = None) -> Self:
        return QueryRange(
            range=cls.QueryRangeData(field=field, from_value=from_value, to_value=to_value, mode=mode, asType=as_type,
                                     inObject=in_object))


class QueryChild(QueryTermBase, Generic[T]):
    child: SerializeAsAny[QueryTermBase] = Field(serialization_alias='$child')

    @classmethod
    def create(cls, child: QueryTermBase) -> Self:
        return QueryChild(child=child)


class QueryParent(QueryTermBase, Generic[T]):
    parent: SerializeAsAny[QueryTermBase] = Field(serialization_alias='$parent')

    @classmethod
    def create(cls, parent: QueryTermBase) -> Self:
        return QueryParent(parent=parent)


class NotQueryTerm(QueryTermBase):
    notList: List[SerializeAsAny[QueryTermBase]] = Field(serialization_alias='$not',
                                                         validation_alias=AliasChoices('$not', 'notList'))

    @classmethod
    def create(cls, terms: List[QueryTermBase]) -> Self:
        return NotQueryTerm(notList=terms)


class AndQueryTerm(QueryTermBase):
    andList: List[SerializeAsAny[QueryTermBase]] = Field(serialization_alias='$and',
                                                         validation_alias=AliasChoices('$and', 'andList'))

    @classmethod
    def create(cls, terms: List[QueryTermBase]) -> Self:
        return AndQueryTerm(andList=terms)


class OrQueryTerm(QueryTermBase):
    orList: List[SerializeAsAny[QueryTermBase]] = Field(serialization_alias='$or',
                                                        validation_alias=AliasChoices('$or', 'orList'))

    @classmethod
    def create(cls, terms: List[QueryTermBase]) -> Self:
        return OrQueryTerm(orList=terms)


class Query(APIRequest):
    query: AndQueryTerm
