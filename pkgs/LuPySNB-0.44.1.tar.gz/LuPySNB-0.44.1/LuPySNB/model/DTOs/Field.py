from typing import Optional

from pydantic import BaseModel, SerializeAsAny
from LuPySNB.model.DTOs.FieldValue import FieldValueTypes


class Field(BaseModel):
    key: str
    type: str | None = None
    name: str | None = None

    content: Optional[FieldValueTypes] = None
