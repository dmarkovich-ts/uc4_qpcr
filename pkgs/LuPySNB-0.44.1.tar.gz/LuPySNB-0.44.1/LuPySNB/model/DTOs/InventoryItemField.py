from pydantic import BaseModel, SerializeAsAny
from LuPySNB.model.DTOs.FieldValue import FieldValue


class InventoryItemField(BaseModel):
    id: str
    content: SerializeAsAny[FieldValue]

