from LuPySNB.model.DTOs.InventoryItemField import InventoryItemField

LocationField = InventoryItemField
