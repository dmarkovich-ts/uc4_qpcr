from pydantic import BaseModel, computed_field
from typing import Optional, Any, Self, Tuple
from LuPySNB.model.DTOs.FieldValue import FieldValue
from LuPySNB.model.exceptions.LuPySNBInternalException import LuPySNBInternalException


class Plate(BaseModel):
    type: str = 'plate'
    id: str

    class Attributes(BaseModel):
        type: Optional[str] = None
        id: Optional[str] = None
        eid: Optional[str] = None
        name: Optional[str] = None
        plate_id: Optional[str] = None
        numberOfRows: Optional[int] = None
        numberOfColumns: Optional[int] = None

        class AnnotationLayer(BaseModel):
            id: str
            name: Optional[str] = None
            dataType: Optional[str] = None
            value: Optional[str] = None

            class Well(BaseModel):
                wellId: str

                class WellContent(BaseModel):
                    type: Optional[str] = None
                    user: Optional[str] = None
                    value: Any

                    @classmethod
                    def create(cls, data_type: str, annotation_class: str, value: Any) -> Self:
                        match data_type, annotation_class:
                            case 'LINK', _:
                                if not isinstance(value, Tuple) or len(value) != 3:
                                    raise LuPySNBInternalException(
                                        f'Invalid argument for field type {data_type}: {value}')
                                return cls(type=value[0], value=value[1], user=value[2])
                            case 'INTEGER', 'other' | 'replicate':
                                if not isinstance(value, int):
                                    raise LuPySNBInternalException(
                                        f'Invalid argument for field type {data_type}: {value}')
                                return cls(type=data_type, value=value)
                            case 'INTEGER', 'concentration':
                                if not isinstance(value, Tuple) or len(value) != 2:
                                    raise LuPySNBInternalException(
                                        f'Invalid argument for field type {data_type}: {value}')
                                return cls(value=f'{value[0]} {value[1]}')
                            case 'TEXT', _:
                                if not isinstance(value, str):
                                    raise LuPySNBInternalException(
                                        f'Invalid argument for field type {data_type}: {value}')
                                return cls(type=data_type, value=value)
                            case _:
                                raise LuPySNBInternalException(f'Unsupported field type: {data_type}')

                content: Optional[WellContent] = None

            wells: Optional[list[Well]] = None

        annotationLayers: list[AnnotationLayer]

    attributes: Attributes
