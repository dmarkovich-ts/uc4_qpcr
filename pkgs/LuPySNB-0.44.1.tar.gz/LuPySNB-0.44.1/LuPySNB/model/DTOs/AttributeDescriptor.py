from pydantic import BaseModel
from typing import Optional
from LuPySNB.model.DTOs.EntityLink import EntityLink


class AttributeDescriptor(BaseModel):
    type: str
    id: str
    links: Optional[EntityLink] = None

    class Attributes(BaseModel):
        id: Optional[str] = None
        type: str
        eid: Optional[str] = None
        templateId: Optional[str] = None
        name: Optional[str] = None
        digest: Optional[str] = None

    attributes: Attributes

