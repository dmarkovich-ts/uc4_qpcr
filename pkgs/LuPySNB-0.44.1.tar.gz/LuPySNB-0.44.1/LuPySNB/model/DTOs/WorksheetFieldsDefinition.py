from typing import List, Union
from pydantic import BaseModel
from LuPySNB.model.DTOs.FieldDefinition import FieldDefinition


class WorksheetFieldsDefinition(BaseModel):
    type: str = 'worksheetFieldsDefinition'
    id: str

    class WorksheetFieldsDefinitionAttributes(BaseModel):
        type: str
        id: str
        fieldsDefinition: List[FieldDefinition]

    class EntityAttributes(BaseModel):
        type: str
        eid: str

    attributes: Union[WorksheetFieldsDefinitionAttributes, EntityAttributes]
