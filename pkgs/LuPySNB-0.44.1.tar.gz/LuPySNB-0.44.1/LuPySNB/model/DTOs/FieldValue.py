from datetime import datetime
from types import NoneType
from typing import Union, Tuple, Self, Generic, TypeVar, Optional, Any
from pydantic import BaseModel, computed_field, RootModel
from LuPySNB.model.exceptions.LuPySNBInternalException import LuPySNBInternalException

T = TypeVar('T')

InputValueTypes = Union[int, float, str, bool, datetime, Tuple, NoneType]


class FieldValue(BaseModel):
    @classmethod
    def create_value(cls, field_type: str, elements: InputValueTypes) -> Self:
        if type(elements) == NoneType:
            return NullFieldValue()
        elif field_type in ('number', 'integer'):
            if not type(elements) in [float, int]:
                raise LuPySNBInternalException(f'Invalid argument for field type {field_type}: {elements}')
            return SimpleFieldValue[type(elements)](value=elements)
        elif field_type in ['text', 'variableMeasure', 'autotextList']:
            return SimpleFieldValue[str](value=str(elements))
        elif field_type in ('date', 'datetime'):
            if not type(elements) in [datetime, str]:
                raise LuPySNBInternalException(f'Invalid argument for field type {field_type}: {elements}')
            return SimpleFieldValue[datetime](value=elements)
        elif field_type == 'boolean':
            if not isinstance(elements, bool):
                raise LuPySNBInternalException(f'Invalid argument for field type {field_type}: {elements}')
            return SimpleFieldValue[bool](value=elements)
        elif field_type == 'link':
            if not isinstance(elements, Tuple) or (len(elements) != 3):
                raise LuPySNBInternalException(f'Invalid argument for field type {field_type}: {elements}')
            return LinkFieldValue(type=elements[0], display=elements[1], value=elements[2])
        elif field_type == 'externalLink':
            if not isinstance(elements, Tuple) or (len(elements) != 2):
                raise LuPySNBInternalException(f'Invalid argument for field type {field_type}: {elements}')
            return ExternalLinkFieldValue(display=elements[0], value=elements[1])
        elif field_type == 'attributeList':
            if isinstance(elements, str):
                return SimpleFieldValue[type(elements)](value=elements)
            elif isinstance(elements, tuple):
                return MultiselectFieldValues(values=elements)
            else:
                raise LuPySNBInternalException(f'Invalid argument for field type {field_type}: {elements}')
        elif field_type == 'multiSelectList':
            if not isinstance(elements, list):
                raise LuPySNBInternalException(f'Invalid argument for field type {field_type}: {elements}')
            return MultiselectFieldValues(values=elements)
        elif field_type == 'unit':
            if isinstance(elements, Tuple) and (len(elements) == 2):
                return UnitFieldValue(value=elements[0], user=elements[1])
            elif isinstance(elements, (int, float)):
                return SimpleFieldValue[type(elements)](value=elements)
            else:
                raise LuPySNBInternalException(f'Invalid argument for field type {field_type}: {elements}')
        else:
            raise LuPySNBInternalException(f'Unsupported field type: {field_type}')


class NullFieldValue(FieldValue, RootModel):
    root: NoneType = None

    def __str__(self):
        return ''


class SimpleFieldValue(FieldValue, Generic[T]):
    value: T

    def __str__(self):
        return str(self.value) if self.value is not None else ''


class MultiselectFieldValues(FieldValue):
    values: list

    def __str__(self):
        return ', '.join(self.values)


class LinkFieldValue(FieldValue):
    type: str
    display: str
    value: str

    def __str__(self):
        return self.display


class ExternalLinkFieldValue(FieldValue):
    display: str
    value: str

    @computed_field
    @property
    def user(self) -> str:
        return self.display

    def __str__(self):
        return self.value


class UserIdFieldValue(FieldValue):
    display: str

    class User(BaseModel):
        userId: str
        email: str
        alias: str

    value: User

    def __str__(self):
        return self.display


class UnitFieldValue(FieldValue):
    value: float
    user: str

    def __str__(self):
        return self.user


class FileAttachmentFieldValue(FieldValue):
    class Attachment(BaseModel):
        fileId: str
        fileName: str
        mimeType: Optional[str]
        size: int
    value: Attachment

    def __str__(self):
        return self.value.fileName


FieldValueTypes = Union[SimpleFieldValue[bool], SimpleFieldValue[float], SimpleFieldValue[int], SimpleFieldValue[str],
    SimpleFieldValue[datetime], LinkFieldValue, ExternalLinkFieldValue, MultiselectFieldValues, UnitFieldValue,
    UserIdFieldValue, FileAttachmentFieldValue, Any]
