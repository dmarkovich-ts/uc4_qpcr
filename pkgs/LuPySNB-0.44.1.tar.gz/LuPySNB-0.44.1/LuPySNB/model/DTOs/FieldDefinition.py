from typing import Optional
from pydantic import BaseModel


class FieldDefinition(BaseModel):
    key: str
    title: str
    type: str
    embeddedEid: Optional[str] = None
    hidden: Optional[bool] = None



