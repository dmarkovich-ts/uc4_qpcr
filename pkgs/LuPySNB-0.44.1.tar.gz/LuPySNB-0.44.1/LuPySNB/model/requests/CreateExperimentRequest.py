from pydantic import BaseModel
from typing import Dict, Any, Self
from LuPySNB.model.requests.APIRequest import APIRequest
from LuPySNB.model.DTOs.ExperimentRelations import ExperimentRelations
from LuPySNB.model.DTOs.EntityRelationship import EntityRelationship
from LuPySNB.model.DTOs.EntityRelationshipList import EntityRelationshipList
from LuPySNB.model.DTOs.EntityRelationshipNode import EntityRelationshipNode


class CreateExperimentRequest(APIRequest):
    class ExperimentRequestData(BaseModel):
        type: str = "experiment"
        attributes: Dict[str, Any]
        relationships: ExperimentRelations

    data: ExperimentRequestData

    @classmethod
    def create(cls, template_id: str, parent_id: str | None, attributes: Dict[str, Any]) -> Self:
        if parent_id is not None:
            ancestors = EntityRelationshipList(data=[EntityRelationshipNode(type="journal", id=parent_id)])
        else:
            ancestors = EntityRelationshipList()

        return CreateExperimentRequest(
            data=CreateExperimentRequest.ExperimentRequestData(attributes=attributes, relationships=ExperimentRelations(
                ancestors=ancestors,
                template=EntityRelationship(data=EntityRelationshipNode(type="experiment", id=template_id)))))
