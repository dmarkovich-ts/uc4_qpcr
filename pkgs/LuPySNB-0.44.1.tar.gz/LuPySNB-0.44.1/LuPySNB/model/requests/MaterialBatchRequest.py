from typing import List, Tuple, Dict, Optional, Self, Union
from pydantic import BaseModel
from LuPySNB.model.DTOs.MaterialFieldValue import MaterialFieldValue, InputTypes
from LuPySNB.model.requests.APIRequest import APIRequest
from LuPySNB.model.DTOs.MaterialField import MaterialField
from LuPySNB.model.DTOs.MaterialLibraryDescriptor import LibraryField


class MaterialBatchRequest(APIRequest):
    class Data(BaseModel):
        type: str = 'batch'
        id: Optional[str]

        class Attributes(BaseModel):
            fields: List[MaterialField]

        attributes: Attributes

    data: Data

    @classmethod
    def create(cls, id: Optional[str], fields: Optional[List[Tuple[str, InputTypes]]],
                                       field_map: Optional[Dict[str, LibraryField]]) -> Optional[Self]:
        if (fields is not None) and (field_map is not None):
            return MaterialBatchRequest(data=MaterialBatchRequest.Data(id=id,
                attributes=MaterialBatchRequest.Data.Attributes(
                    fields=list(map(lambda x: MaterialField(id=field_map[x[0]].id,
                        value=MaterialFieldValue.create_value(field_map[x[0]].dataType, x[1])), fields)))))
        else:
            return None
