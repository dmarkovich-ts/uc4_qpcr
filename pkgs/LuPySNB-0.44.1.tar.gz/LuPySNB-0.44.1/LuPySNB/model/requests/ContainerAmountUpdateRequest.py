from LuPySNB.model.requests.APIRequest import APIRequest
from pydantic import BaseModel
from typing import List, Tuple, Self


class ContainerAmountUpdateRequest(APIRequest):
    class Data(BaseModel):
        type: str = 'inventoryContainer'

        class Attributes(BaseModel):
            amount: str

        attributes: Attributes

    data: Data

    @classmethod
    def create(cls, amount: str) -> Self:
        return ContainerAmountUpdateRequest(data=ContainerAmountUpdateRequest.Data(
            attributes=ContainerAmountUpdateRequest.Data.Attributes(amount=amount)))
