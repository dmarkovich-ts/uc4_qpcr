from typing import Self, Optional

from pydantic import BaseModel

from LuPySNB.model.requests.APIRequest import APIRequest


class ContainerStatusUpdateRequest(APIRequest):
    class Data(BaseModel):
        type: str = 'inventoryContainer'

        class Attributes(BaseModel):
            coordinateX: int | None = None
            coordinateY: int | None = None

            class Location(BaseModel):
                id: str

            class Owner(BaseModel):
                userId: str

            location: Location
            owner: Owner

        attributes: Attributes

    data: Data

    @classmethod
    def create(cls, location_eid: str,coordinate_x: int | None, coordinate_y: int | None, user_id: str) -> Self:
        return ContainerStatusUpdateRequest(
            data=ContainerStatusUpdateRequest.Data(
                attributes=ContainerStatusUpdateRequest.Data.Attributes(
                    location=(ContainerStatusUpdateRequest.Data.Attributes.Location(id=location_eid)),
                    coordinateX=str(coordinate_x) if coordinate_x is not None else None,
                    coordinateY=str(coordinate_y) if coordinate_y is not None else None,
                    owner=(ContainerStatusUpdateRequest.Data.Attributes.Owner(userId=user_id))
                )))
