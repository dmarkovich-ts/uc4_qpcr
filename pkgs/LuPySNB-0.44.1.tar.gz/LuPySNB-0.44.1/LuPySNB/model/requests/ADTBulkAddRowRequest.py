from pydantic import BaseModel, SerializeAsAny
from typing import List, Tuple, Self, Optional
from LuPySNB.model.DTOs.FieldValue import FieldValue, InputValueTypes
from LuPySNB.model.requests.APIRequest import APIRequest


class ADTBulkAddRowRequest(APIRequest):
    class Data(BaseModel):
        type: str = "adtRow"

        class Attributes(BaseModel):
            class Cell(BaseModel):
                key: str
                content: SerializeAsAny[FieldValue]

            action: Optional[str] = 'create'
            cells: List[Cell]

        attributes: Attributes

    data: list[Data]

    @classmethod
    def create(cls, bulk_data: list[list[tuple[str, str, InputValueTypes]]]) -> Self:
        data_list = []
        for row in bulk_data:
            data_list.append(
                cls.Data(
                    attributes=cls.Data.Attributes(
                        cells=[
                            cls.Data.Attributes.Cell(
                                key=col[0],
                                content=FieldValue.create_value(col[1], col[2])
                            )
                            for col in row
                        ]
                    )
                )
            )
        return cls(data=data_list)
