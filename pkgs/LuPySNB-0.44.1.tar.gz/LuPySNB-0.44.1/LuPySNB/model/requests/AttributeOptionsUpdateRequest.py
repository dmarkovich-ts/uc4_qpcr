from typing import List, Optional, Self
from pydantic import BaseModel
from LuPySNB.model.requests.APIRequest import APIRequest
from LuPySNB.model.DTOs.HierarchicalOptions import HierarchicalOptions


class AttributeOptionsUpdateRequest(APIRequest):
    class Data(BaseModel):
        type: str = "attribute"
        id: str

        class Attributes(BaseModel):
            options: List[str] = None
            hierarchicalOptions: List[HierarchicalOptions] = None
        attributes: Attributes

    data: Data

    @classmethod
    def create_flat(cls, eid: str, options: List[str]) -> Self:
        return AttributeOptionsUpdateRequest(data=AttributeOptionsUpdateRequest.Data(id=eid,
                        attributes=AttributeOptionsUpdateRequest.Data.Attributes(options=options)))

    @classmethod
    def create_hierarchical(cls, eid: str, options: List[HierarchicalOptions]) -> Self:
        return AttributeOptionsUpdateRequest(data=AttributeOptionsUpdateRequest.Data(id=eid,
                        attributes=AttributeOptionsUpdateRequest.Data.Attributes(hierarchicalOptions=options)))





