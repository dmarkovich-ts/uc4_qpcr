from LuPySNB.model.DTOs.ContainerField import ContainerField
from LuPySNB.model.DTOs.FieldDefinition import FieldDefinition
from LuPySNB.model.DTOs.FieldValue import FieldValue
from LuPySNB.model.DTOs.MaterialFieldValue import InputTypes
from LuPySNB.model.requests.APIRequest import APIRequest
from pydantic import BaseModel
from typing import List, Tuple, Self, Dict


class ContainerUpdateRequest(APIRequest):
    class Data(BaseModel):
        type: str = 'inventoryContainer'

        class Attributes(BaseModel):
            fields: List[ContainerField]

        attributes: Attributes

    data: Data

    @classmethod
    def create(cls, fields_data: List[Tuple[str, InputTypes]], field_map: Dict[str, FieldDefinition]) -> Self:
        return ContainerUpdateRequest(data=ContainerUpdateRequest.Data(
            attributes=ContainerUpdateRequest.Data.Attributes(
                fields=list(map(lambda x: ContainerField(
                    id=field_map[x[0]].key,
                    content=FieldValue.create_value(field_map[x[0]].type, x[1])), fields_data)))))

