from pydantic import BaseModel
from typing import List, Tuple, Self
from LuPySNB.model.DTOs.Field import Field
from LuPySNB.model.DTOs.FieldValue import InputValueTypes, FieldValue
from LuPySNB.model.requests.APIRequest import APIRequest


class WorksheetUpdateRequest(APIRequest):
    class Data(BaseModel):
        type: str = 'worksheet'
        id: str

        class Attributes(BaseModel):
            fields: List[Field]

        attributes: Attributes

    data: Data

    @classmethod
    def create(cls, worksheet_id: str, data: List[Tuple[str, str, InputValueTypes]]) -> Self:
        return WorksheetUpdateRequest(data=WorksheetUpdateRequest.Data(
            id=worksheet_id, attributes=WorksheetUpdateRequest.Data.Attributes(
                fields=list(map(lambda x: Field(key=x[0],
                            content=FieldValue.create_value(x[1], x[2])),  data)))))
