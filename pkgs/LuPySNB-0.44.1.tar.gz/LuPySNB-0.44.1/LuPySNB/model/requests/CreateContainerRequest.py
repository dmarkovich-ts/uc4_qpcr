from typing import Dict, Self, List, Optional, Tuple
from pydantic import BaseModel

from LuPySNB.model.DTOs.FieldDefinition import FieldDefinition
from LuPySNB.model.DTOs.ContainerField import ContainerField
from LuPySNB.model.DTOs.FieldValue import FieldValue
from LuPySNB.model.DTOs.MaterialFieldValue import InputTypes
from LuPySNB.model.requests.APIRequest import APIRequest


class CreateContainerRequest(APIRequest):
    class Data(BaseModel):
        type: str = 'inventoryContainer'

        class Attributes(BaseModel):
            typeId: str
            amount: float
            unit: str
            barcode: str = None
            coordinateX: Optional[int] = None
            coordinateY: Optional[int] = None

            class Location(BaseModel):
                id: str

            class EntityId(BaseModel):
                entityId: str

            location: Location
            contents: List[EntityId]
            fields: List[ContainerField]

        attributes: Attributes

    data: Data

    @classmethod
    def create(cls, container_type_id: str, amount: float, location_eid: str, coordinateX: int, coordinateY: int, barcode: str, content_eid: str,
               field_data: List[Tuple[str, InputTypes]], field_map: Dict[str, FieldDefinition], unit: str = 'g') -> Self:
        return CreateContainerRequest(
            data=CreateContainerRequest.Data(
                attributes=CreateContainerRequest.Data.Attributes(
                    typeId=container_type_id,
                    amount=amount,
                    unit=unit,
                    location=(CreateContainerRequest.Data.Attributes.Location(id=location_eid)),
                    coordinateX=coordinateX,
                    coordinateY=coordinateY,
                    barcode=barcode,
                    contents=[CreateContainerRequest.Data.Attributes.EntityId(entityId=content_eid)],
                    fields=list(map(lambda x: ContainerField(
                        id=field_map[x[0]].key,
                        content=FieldValue.create_value(field_map[x[0]].type, x[1])), field_data)))))




