from pydantic import BaseModel
from typing import Self
from LuPySNB.model.requests.APIRequest import APIRequest


class EntityReview(APIRequest):
    class EntityRequestData(BaseModel):
        class Attributes(BaseModel):
            reason: str
        attributes: Attributes
    data: EntityRequestData

    @classmethod
    def create(cls, reason: str) -> Self:
        return cls(
            data=cls.EntityRequestData(
                attributes=cls.EntityRequestData.Attributes(reason=reason)
            )
        )
