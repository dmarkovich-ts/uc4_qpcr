from pydantic import BaseModel
from typing import Dict, Any, Self, List
from LuPySNB.model.requests.APIRequest import APIRequest


class UpdateEntityRequest(APIRequest):
    class EntityRequestData(BaseModel):
        attributes: Dict[str, Any]

    data: List[EntityRequestData]

    @classmethod
    def create(cls, attributes_list: List[Dict[str, Any]]) -> Self:
        return UpdateEntityRequest(
            data=list(map(lambda attributes: UpdateEntityRequest.EntityRequestData(attributes=attributes), attributes_list))
        )
