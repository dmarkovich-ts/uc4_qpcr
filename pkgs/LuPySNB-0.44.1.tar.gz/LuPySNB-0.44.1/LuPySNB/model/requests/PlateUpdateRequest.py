from typing import Optional, Self, List, Tuple, Any, Dict
from LuPySNB.model.requests.APIRequest import APIRequest
from LuPySNB.model.DTOs.Plate import Plate
from LuPySNB.model.DTOs.PlateContainer import PlateContainer
from LuPySNB.model.exceptions.LuPySNBArgumentException import LuPySNBArgumentException


class PlateUpdateRequest(APIRequest):
    data: Plate

    @classmethod
    def create(cls, name: str, annotations_layers_map: Dict[str, PlateContainer.AnnotationLayerDefinition.Attributes.AnnotationLayer],
               annotation_layers: List[Tuple[str, List[Tuple[str, Any]]]]) -> Self:
        missing_fields = list(filter(lambda x: x[0] not in annotations_layers_map, annotation_layers))
        if len(missing_fields) > 0:
            raise LuPySNBArgumentException(f'Missing annotation layer definitions for: {", ".join(map(lambda x: x[0], missing_fields))}')

        return cls(data=Plate(id=name, attributes=Plate.Attributes(
            plateId=name,
            annotationLayers=list(
                map(lambda x: Plate.Attributes.AnnotationLayer(id=annotations_layers_map[x[0]].id,
                                                               wells=list(
                                                                   map(lambda y: Plate.Attributes.AnnotationLayer.Well(
                                                                       wellId=y[0],
                                                                       content=Plate.Attributes.AnnotationLayer.Well.WellContent.create(
                                                                           annotations_layers_map[x[0]].dataType,
                                                                           annotations_layers_map[x[0]].annotationClass,
                                                                           y[1])),
                                                                       x[1]))), annotation_layers)))))

