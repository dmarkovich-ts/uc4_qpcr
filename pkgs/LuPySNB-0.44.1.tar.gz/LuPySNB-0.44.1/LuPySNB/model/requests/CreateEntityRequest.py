from pydantic import BaseModel
from typing import Dict, Any, Self
from LuPySNB.model.requests.APIRequest import APIRequest
from LuPySNB.model.DTOs.EntityRelations import EntityRelations
from LuPySNB.model.DTOs.EntityRelationship import EntityRelationship
from LuPySNB.model.DTOs.EntityRelationshipList import EntityRelationshipList
from LuPySNB.model.DTOs.EntityRelationshipNode import EntityRelationshipNode, get_entity_type_from_eid


class CreateEntityRequest(APIRequest):
    class EntityRequestData(BaseModel):
        type: str
        attributes: Dict[str, Any]
        relationships: EntityRelations

    data: EntityRequestData

    @classmethod
    def create(cls, template_id: str, parent_id: str | None, attributes: Dict[str, Any],
               entity_type: str = None) -> Self:
        ancestors = EntityRelationshipList(data=
                                           [EntityRelationshipNode(type=get_entity_type_from_eid(parent_id),
                                                                   id=parent_id)]) if parent_id is not None else EntityRelationshipList(data=[])
        entity_relations = EntityRelations(ancestors=ancestors) if template_id is None else EntityRelations(
            ancestors=ancestors,
            template=EntityRelationship(
                data=EntityRelationshipNode(type=get_entity_type_from_eid(template_id), id=template_id)))
        e_type = entity_type if entity_type is not None else get_entity_type_from_eid(template_id)
        return CreateEntityRequest(
            data=CreateEntityRequest.EntityRequestData(type=e_type, attributes=attributes,
                                                       relationships=entity_relations)
        )
