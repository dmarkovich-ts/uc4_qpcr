from LuPySNB.model.DTOs.LocationField import LocationField
from LuPySNB.model.DTOs.FieldDefinition import FieldDefinition
from LuPySNB.model.DTOs.FieldValue import FieldValue
from LuPySNB.model.DTOs.MaterialFieldValue import InputTypes
from LuPySNB.model.requests.APIRequest import APIRequest
from pydantic import BaseModel
from typing import List, Tuple, Self, Dict


class UpdateInventoryLocationRequest(APIRequest):
    class Data(BaseModel):
        type: str = 'inventoryLocation'

        class Attributes(BaseModel):
            fields: List[LocationField]

        attributes: Attributes

    data: Data

    @classmethod
    def create(cls, fields_data: List[Tuple[str, InputTypes]], field_map: Dict[str, FieldDefinition]) -> Self:
        return UpdateInventoryLocationRequest(data=UpdateInventoryLocationRequest.Data(
            attributes=UpdateInventoryLocationRequest.Data.Attributes(
                fields=list(map(lambda x: LocationField(
                    id=field_map[x[0]].key,
                    content=FieldValue.create_value(field_map[x[0]].type, x[1])), fields_data)))))

