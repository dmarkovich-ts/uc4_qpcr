from typing import List, Dict, Tuple, Self, Union
from pydantic import BaseModel
from LuPySNB.model.DTOs.MaterialFieldValue import MaterialFieldValue, InputTypes
from LuPySNB.model.DTOs.MaterialField import MaterialField
from LuPySNB.model.DTOs.MaterialLibraryDescriptor import LibraryField
from LuPySNB.model.requests.APIRequest import APIRequest


class UpdateMaterialPropertiesRequest(APIRequest):
    class Data(BaseModel):
        attributes: MaterialField

    data: List[Data]

    @classmethod
    def create(cls, fields: List[Tuple[str, InputTypes]], field_map: Dict[str, LibraryField]) -> Self:
        return UpdateMaterialPropertiesRequest(data=list(map(
            lambda x: UpdateMaterialPropertiesRequest.Data(attributes=MaterialField(name=x[0],
                value=MaterialFieldValue.create_value(field_map[x[0]].dataType, x[1]))), fields)))
