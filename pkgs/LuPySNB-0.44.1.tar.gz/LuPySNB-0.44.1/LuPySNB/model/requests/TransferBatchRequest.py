from typing import Self

from pydantic import BaseModel
from LuPySNB.model.requests.APIRequest import APIRequest


class TransferBatchRequest(APIRequest):
    class Data(BaseModel):
        type: str = 'batchTransfer'

        class Attributes(BaseModel):
            assetId: str
        attributes: Attributes

    data: Data

    @classmethod
    def create(cls, asset_id: str) -> Self:
        return TransferBatchRequest(
            data=TransferBatchRequest.Data(
                attributes=TransferBatchRequest.Data.Attributes(
                    assetId=asset_id
                )
            )
        )
