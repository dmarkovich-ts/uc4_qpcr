from pydantic import BaseModel
from typing import Self
from LuPySNB.model.requests.APIRequest import APIRequest
from enum import Enum

class LundbeckOrganization(str, Enum):
    lundbeck = 'lundbeck'
    lundbecksandbox = 'lundbecksandbox'
    lundbecktest = 'lundbecktest'

class CreateUser(APIRequest):

    class CreateUserData(BaseModel):
        class CreateUserAttributes(BaseModel):
            alias: str
            country: str
            emailAddress: str
            firstName: str
            lastName: str
            organization: str

        attributes: CreateUserAttributes
    data: CreateUserData

    @classmethod
    def create(cls, alias: str, first_name: str, last_name: str, organization: LundbeckOrganization, country: str = 'Denmark') -> Self:
        # raise if organization is not in organization
        if not isinstance(organization, LundbeckOrganization):
            raise ValueError(f"Organization must be one of {', '.join([o.value for o in LundbeckOrganization])}")
        #if organization not in LundbeckOrganization:
        #    raise ValueError(f"Organization must be one of {', '.join([o.value for o in LundbeckOrganization])}")
        email = f"{alias}@lundbeck.com"
        user_attributes = CreateUser.CreateUserData.CreateUserAttributes(alias=alias.upper(), emailAddress=email, firstName=first_name, lastName=last_name, organization=organization, country=country)
        return CreateUser(data=CreateUser.CreateUserData(attributes=user_attributes))
