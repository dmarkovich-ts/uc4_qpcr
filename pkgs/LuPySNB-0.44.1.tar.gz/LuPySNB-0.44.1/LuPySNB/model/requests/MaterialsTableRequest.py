from pydantic import BaseModel
from typing import List, Self, Any
from LuPySNB.model.requests.APIRequest import APIRequest


class MaterialsTableAddRowRequest(APIRequest):
    class Data(BaseModel):
        type: str = "materialsTableRow"

        class Attributes(BaseModel):
            class Cell(BaseModel):
                class Content(BaseModel):
                    value: Any

                key: str
                content: Content

            materialId: str
            cells: List[Cell] = []

        attributes: Attributes

    data: Data

    @classmethod
    def create(cls, material_id: str, cells: list[dict] | None = None) -> Self:
        if cells is None:
            cells = []
        return MaterialsTableAddRowRequest(
            data=MaterialsTableAddRowRequest.Data(attributes=MaterialsTableAddRowRequest.Data.Attributes(
                materialId=material_id,
                cells=[MaterialsTableAddRowRequest.Data.Attributes.Cell(
                    key=cell['key'],
                    content=MaterialsTableAddRowRequest.Data.Attributes.Cell.Content(
                        value=cell['value']
                    )
                ) for cell in cells]
            ))
        )


class MaterialsTableAddMultipleRowRequest(APIRequest):
    class Data(BaseModel):
        type: str = "materialsTableRow"

        class Attributes(BaseModel):
            class Cell(BaseModel):
                class Content(BaseModel):
                    value: Any

                key: str
                content: Content

            action: str = 'create'
            materialId: str
            cells: List[Cell] = []

        attributes: Attributes

    data: List[Data]

    @classmethod
    def create(cls, material_ids: List[str], cells: List[List[dict]] | None = None) -> Self:
        if cells is None:
            cells = [[] for _ in material_ids]
        if len(cells) != len(material_ids):
            raise ValueError(
                f"Number of cell lists ({len(cells)}) must match number of material IDs ({len(material_ids)})")
        return MaterialsTableAddMultipleRowRequest(
            data=[MaterialsTableAddMultipleRowRequest.Data(
                attributes=MaterialsTableAddMultipleRowRequest.Data.Attributes(
                    materialId=material_id,
                    cells=[MaterialsTableAddMultipleRowRequest.Data.Attributes.Cell(
                        key=cell['key'],
                        content=MaterialsTableAddMultipleRowRequest.Data.Attributes.Cell.Content(
                            value=cell['value']
                        )
                    ) for cell in row_cells]
                )
            ) for material_id, row_cells in zip(material_ids, cells)]
        )
