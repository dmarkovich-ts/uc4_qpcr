from pydantic import BaseModel, SerializeAsAny
from typing import List, Tuple, Self
from LuPySNB.model.DTOs.FieldValue import FieldValue, InputValueTypes
from LuPySNB.model.requests.APIRequest import APIRequest


class ADTAddRowRequest(APIRequest):
    class Data(BaseModel):
        type: str = "adtRow"

        class Attributes(BaseModel):
            class Cell(BaseModel):
                key: str
                content: SerializeAsAny[FieldValue]

            cells: List[Cell]

        attributes: Attributes

    data: Data

    @classmethod
    def create(cls, data: List[Tuple[str, str, InputValueTypes]]) -> Self:
        return ADTAddRowRequest(data=ADTAddRowRequest.Data(attributes=ADTAddRowRequest.Data.Attributes(
            cells=list(map(lambda x: ADTAddRowRequest.Data.Attributes.Cell(key=x[0], content=FieldValue.create_value(
                x[1], x[2])), data)))))
