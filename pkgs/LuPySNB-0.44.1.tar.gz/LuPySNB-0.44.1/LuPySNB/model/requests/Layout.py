from pydantic import BaseModel
from typing import Self
from LuPySNB.model.requests.APIRequest import APIRequest


class NewPageRequest(APIRequest):
    class NewPageRequestData(BaseModel):
        class NewPageRequestAttributes(BaseModel):
            name: str
            index: int

        type: str = "layoutPage"
        attributes: NewPageRequestAttributes

    data: NewPageRequestData

    @classmethod
    def create(cls, name: str, index: int = -1) -> Self:
        return NewPageRequest(data=NewPageRequest.NewPageRequestData(
            attributes=NewPageRequest.NewPageRequestData.NewPageRequestAttributes(name=name, index=index))
        )

class PutEntityOnPageRequest(APIRequest):
    class PutEntityOnPageRequestData(BaseModel):
        class PutEntityOnPageRequestAttributes(BaseModel):
            pageId: str
            index: int

        type: str = "layoutLocation"
        attributes: PutEntityOnPageRequestAttributes

    data: PutEntityOnPageRequestData

    @classmethod
    def create(cls, page_id: str, index: int = -1) -> Self:
        return PutEntityOnPageRequest(data=PutEntityOnPageRequest.PutEntityOnPageRequestData(
            attributes=PutEntityOnPageRequest.PutEntityOnPageRequestData.PutEntityOnPageRequestAttributes(pageId=page_id, index=index))
        )