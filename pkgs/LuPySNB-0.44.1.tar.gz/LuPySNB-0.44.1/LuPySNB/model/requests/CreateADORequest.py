from pydantic import BaseModel
from typing import Dict, Any, Self

from LuPySNB.model.DTOs.EntityRelationshipList import EntityRelationshipList
from LuPySNB.model.requests.APIRequest import APIRequest
from LuPySNB.model.DTOs.EntityRelations import EntityRelations
from LuPySNB.model.DTOs.EntityRelationship import EntityRelationship
from LuPySNB.model.DTOs.EntityRelationshipNode import EntityRelationshipNode


class CreateADORequest(APIRequest):
    class ADORequestData(BaseModel):
        class AdoTypeName(BaseModel):
            adoTypeName: str

        type: str = 'ado'
        meta: AdoTypeName
        attributes: Dict[str, Any]
        relationships: EntityRelations

    data: ADORequestData

    @classmethod
    def create(cls, ado_type: str, template_id: str, attributes: Dict[str, Any]) -> Self:
        # an ADO can not have any parents
        entity_relations = EntityRelations(ancestors=EntityRelationshipList(data=[]),
                                           template=EntityRelationship(
                                               data=EntityRelationshipNode(type='ado', id=template_id))
                                           )
        meta = CreateADORequest.ADORequestData.AdoTypeName(adoTypeName=ado_type)
        return CreateADORequest(
            data=CreateADORequest.ADORequestData(meta=meta,attributes=attributes,
                                                 relationships=entity_relations)
        )
