from typing import List, Tuple, Dict, Optional, Self, Union
from pydantic import BaseModel, RootModel
from LuPySNB.model.DTOs.MaterialFieldValue import MaterialFieldValue, InputTypes
from LuPySNB.model.DTOs.MaterialLibraryDescriptor import LibraryField
from LuPySNB.model.requests.APIRequest import APIRequest
from LuPySNB.model.requests.MaterialBatchRequest import MaterialBatchRequest
from LuPySNB.model.DTOs.MaterialField import MaterialField


class MaterialAssetRequest(APIRequest):
    class Data(BaseModel):
        type: str = 'asset'
        id: Optional[str]

        class Attributes(BaseModel):
            synonyms: List[str] = None
            fields: List[MaterialField]

        attributes: Attributes

        class Relationships(BaseModel):
            batch: Optional[MaterialBatchRequest]

        relationships: Relationships

    data: Data

    @classmethod
    def create(cls, asset_id: Optional[str], batch_id: Optional[str], synonyms: List[str],
               asset_fields: List[Tuple[str, InputTypes]],
               asset_field_map: Dict[str, LibraryField],
               batch_fields: Optional[List[Tuple[str, InputTypes]]],
               batch_field_map: Optional[Dict[str, LibraryField]]) -> Self:
        return MaterialAssetRequest(data=MaterialAssetRequest.Data(
            id=asset_id, attributes=MaterialAssetRequest.Data.Attributes(synonyms=synonyms, fields=list(
                map(lambda x: MaterialField(id=asset_field_map[x[0]].id,
                                            value=MaterialFieldValue.create_value(
                                                asset_field_map[x[0]].dataType, x[1])), asset_fields))),
            relationships=MaterialAssetRequest.Data.Relationships(
                batch=MaterialBatchRequest.create(batch_id, batch_fields, batch_field_map))))


class MaterialAssetRequestList(APIRequest, RootModel):
    root: List[MaterialAssetRequest]
