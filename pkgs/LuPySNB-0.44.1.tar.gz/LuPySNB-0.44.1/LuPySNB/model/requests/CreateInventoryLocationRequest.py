from typing import Dict, Self, Union, List, Optional
from pydantic import BaseModel

from LuPySNB.model.DTOs.FieldDefinition import FieldDefinition
from LuPySNB.model.DTOs.LocationField import LocationField
from LuPySNB.model.DTOs.FieldValue import FieldValue
from LuPySNB.model.requests.APIRequest import APIRequest


class CreateInventoryLocationRequest(APIRequest):
    class Data(BaseModel):
        type: str

        class Attributes(BaseModel):
            name: str
            typeId: str
            barcode: Optional[str] = None
            ancestors: List[Dict[str, str]]
            isGrid: bool
            rows: Optional[int] = None
            columns: Optional[int] = None

            fields: List[LocationField]

        attributes: Attributes

    data: Data

    @classmethod
    def create(cls, parent_id: Optional[str], name: str, barcode: str, rows: Optional[int], columns: Optional[int],
               location_type_id: str, field_data: Dict[str, Union[str, List[str]]],
               field_map: Dict[str, FieldDefinition]) -> Self:
        ancestors = [{"id": parent_id}] if parent_id is not None else []

        return CreateInventoryLocationRequest(
            data=CreateInventoryLocationRequest.Data(type="inventoryLocation",
                                                     attributes=CreateInventoryLocationRequest.Data.Attributes(
                                                         name=name,
                                                         barcode=barcode,
                                                         ancestors=ancestors,
                                                         typeId=location_type_id,
                                                         rows=rows,
                                                         columns=columns,
                                                         isGrid=rows is not None and columns is not None,
                                                         fields=list(map(lambda x: LocationField(
                                                             id=field_map[x].key,
                                                             content=FieldValue.create_value(field_map[x].type,
                                                                                             field_data[x])),
                                                                         field_data)))))
