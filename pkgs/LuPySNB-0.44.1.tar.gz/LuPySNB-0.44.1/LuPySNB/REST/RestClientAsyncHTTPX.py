import re
from io import BytesIO
import httpx
import httpx_retries
from urllib.parse import unquote
from typing import Callable, Awaitable, AsyncGenerator, Optional
from pydantic import ValidationError
from LuPySNB.REST.RestConfig import RestConfig
from LuPySNB.model.exceptions.SignalsException import SignalsException
from LuPySNB.model.requests.APIRequest import APIRequest
from LuPySNB.model.responses.File import File
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.Error import Error
from LuPySNB.API.IRestClientAsync import IRestClientAsync


class RestClientAsyncHTTPX(IRestClientAsync):
    T = IRestClientAsync.T

    _config: RestConfig
    _session: httpx.AsyncClient

    def __init__(self, config: RestConfig):
        self._config = config
        if len(self._config.request_retry) > 0:
            retry = httpx_retries.Retry(**self._config.request_retry)
            transport = httpx_retries.RetryTransport(retry=retry)
        else:
            transport = None
        self._session = httpx.AsyncClient(base_url=self._config.base_url,
                                          headers=self._config.headers,
                                          timeout=self._config.request_timeout,
                                          verify=self._config.request_verify,
                                          event_hooks= {
                                              'request': self._config.request_event_hooks,
                                              'response': self._config.response_event_hooks
                                          },
                                          transport=transport)

    async def aclose(self):
        await self._session.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.aclose()
        if exc_val is not None:
            raise exc_val
        return self

    async def invoke_rest_post_async(self, endpoint: str, req_body: Optional[APIRequest], ret_type: T | None,
                                     use_pagination: bool = False) \
            -> T | None |  ErrorList:
        operation = lambda url: self._session.post(url, content=req_body.model_dump_json(by_alias=True, exclude_none=True).encode('utf8')
                                                   if req_body else None)
        if ret_type is None:
            r = await operation(endpoint)
            return None if r.is_success else self._handle_error(r)
        return await self._get_paged_response_async(endpoint, use_pagination,
                                                    operation,
                                                    ret_type)

    async def invoke_rest_post_file_async(self, endpoint: str, mime_type: str, req_body: BytesIO, ret_type: T) \
            -> T | ErrorList:
        headers_to_use = self._config.headers.copy()
        headers_to_use['Content-Type'] = mime_type
        r = await self._session.post(endpoint, content=self._yield_content(req_body), headers=headers_to_use)
        return ret_type(**r.json()) if r.is_success else self._handle_error(r)
    
    async def invoke_rest_put_async(self, endpoint: str, req_body: APIRequest, ret_type: T) -> T | ErrorList:
        r = await self._session.put(endpoint,
                                    content=req_body.model_dump_json(by_alias=True, exclude_none=True).encode('utf8'))
        return ret_type(**r.json()) if r.is_success else self._handle_error(r)

    async def invoke_rest_put_file_async(self, endpoint: str, mime_type: str, req_body: BytesIO, ret_type: T) \
            -> T | ErrorList:
        headers_to_use = self._config.headers.copy()
        headers_to_use['Content-Type'] = mime_type
        r = await self._session.put(endpoint, content=self._yield_content(req_body), headers=headers_to_use)
        return ret_type(**r.json()) if r.is_success else self._handle_error(r)

    async def invoke_rest_patch_async(self, endpoint: str, req_body: APIRequest, ret_type: T) -> T | ErrorList:
        r = await self._session.patch(endpoint,
                                      content=req_body.model_dump_json(by_alias=True, exclude_none=True).encode('utf8'))
        return ret_type(**r.json()) if r.is_success else self._handle_error(r)

    async def invoke_rest_patch_file_async(self, endpoint: str, mime_type: str, req_body: BytesIO, ret_type: T) \
            -> T | ErrorList:
        headers_to_use = self._config.headers.copy()
        headers_to_use['Content-Type'] = mime_type
        r = await self._session.patch(endpoint, content=self._yield_content(req_body), headers=headers_to_use)
        return ret_type(**r.json()) if r.is_success else self._handle_error(r)

    async def invoke_rest_get_async(self, endpoint: str, ret_type: T, use_pagination: bool = False)\
            -> T | ErrorList:
        return await self._get_paged_response_async(endpoint, use_pagination,
                                                    lambda url: self._session.get(url), ret_type)

    async def invoke_rest_get_file_async(self, endpoint: str) -> File | ErrorList:
        headers_to_use = self._config.headers.copy()
        headers_to_use['Accept'] = 'application/octet-stream'
        r = await self._session.get(endpoint, headers=headers_to_use)
        mime_type = r.headers['content-type']
        filename = unquote(re.findall(r"filename\*=utf-8''(.+)", r.headers['content-disposition'])[0]) if 'content-disposition' in r.headers else None
        return File(filename=filename, content=r.content, mime_type=mime_type) if r.is_success else self._handle_error(r)

    async def invoke_rest_delete_async(self, endpoint: str) -> None | ErrorList:
        r = await self._session.delete(endpoint)
        return None if r.is_success else self._handle_error(r)

    async def _get_paged_response_async(self, endpoint: str, use_pagination: bool,
                                        request_operation: Callable[[str], Awaitable[httpx.Response]], ret_type: T) \
            -> T | ErrorList:
        url = endpoint
        if use_pagination and self._config.next_limit is not None:
            url = url + ('&' if '?' in url else '?') + f'page[limit]={self._config.next_limit}'

        ret_val = None
        while url is not None:
            r = await request_operation(url)
            if r.is_success:
                curr_val = ret_type(**r.json())
                if ret_val is None:
                    ret_val = curr_val
                else:
                    ret_val.extend(curr_val)
                url = ret_val.next_link() if self._config.auto_expand else None
            else:
                return self._handle_error(r)
        return ret_val

    @classmethod
    async def _yield_content(cls, req_body: BytesIO) -> AsyncGenerator[bytes, None]:
        yield req_body.read()

    def _handle_error(self, r: httpx.Response) -> ErrorList:
        try:
            error_list = ErrorList(**r.json())
            if self._config.raise_on_signals_error:
                raise SignalsException(error_list)
            else:
                return error_list
        except ValidationError:
            r.raise_for_status()
        except SignalsException:
            raise
        except:
            if r.status_code == 429:
                error = {'status': 429, 'code': 'Too many requests'}
                if 'retry-after' in r.headers:
                    error['detail'] = f"Retry after {r.headers['retry-after']} seconds"
                if self._config.raise_on_signals_error:
                    raise SignalsException(ErrorList(errors=[Error(**error)]))
                else:
                    return ErrorList(errors=[Error(**error)])
            else:
                r.raise_for_status()
