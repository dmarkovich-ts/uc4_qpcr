import re
from io import BytesIO
import requests
import requests.adapters
from urllib.parse import unquote
from typing import Callable, Any, Optional
from pydantic import ValidationError
from LuPySNB.REST.RestConfig import RestConfig
from LuPySNB.model.exceptions.SignalsException import SignalsException
from LuPySNB.model.requests.APIRequest import APIRequest
from LuPySNB.model.responses.File import File
from LuPySNB.model.responses.ErrorList import ErrorList
from LuPySNB.model.responses.Error import Error
from LuPySNB.API.IRestClient import IRestClient


class RestClientRequests(IRestClient):
    T = IRestClient.T

    _config: RestConfig
    _session: requests.Session

    class RestConfigRequests(RestConfig):
        mounts: dict[str, Any] = None

    def __init__(self, config: RestConfig):
        self._config = config
        self._session = requests.Session()
        self._session.headers = self._config.headers
        if self._config.request_event_hooks != []:
            raise NotImplementedError("Request event hooks are not supported in Requests. ")
        self._session.hooks['response'].extend(self._config.response_event_hooks)
        if len(self._config.request_retry) > 0:
            retry = requests.adapters.Retry(**self._config.request_retry)
            self._session.mount('http://', requests.adapters.HTTPAdapter(max_retries = retry))
            self._session.mount('https://', requests.adapters.HTTPAdapter(max_retries = retry))
        
        if isinstance(self._config, self.RestConfigRequests) and self._config.mounts is not None:
            for key, value in self._config.mounts.items():
                self._session.mount(key, value)

    def close(self):
        self._session.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        if exc_val is not None:
            raise exc_val
        return self

    def invoke_rest_post(self, endpoint: str, req_body: Optional[APIRequest], ret_type: T | None, use_pagination: bool = False) \
            -> T | None | ErrorList:
        if ret_type  is None:
            r = self._session.post(self._config.base_url + '/' + endpoint,
                               data=req_body.model_dump_json(by_alias=True, exclude_none=True).encode('utf8') if req_body else None,
                               timeout=self._config.request_timeout,
                               verify=self._config.request_verify)
            return None if 199 < r.status_code < 300 else self._handle_error(r)
        return self._get_paged_response(endpoint, use_pagination,
                                        lambda url: self._session.post(url,
                                                                       data=req_body.model_dump_json(by_alias=True,
                                                                                                     exclude_none=True).
                                                                       encode('utf8') if req_body else None),
                                                                       ret_type)

    def invoke_rest_post_file(self, endpoint: str, mime_type: str, req_body: BytesIO, ret_type: T) \
            -> T | ErrorList:
        headers_to_use = self._config.headers.copy()
        headers_to_use['Content-Type'] = mime_type
        r = self._session.post(self._config.base_url + '/' + endpoint, data=req_body, headers=headers_to_use,
                               timeout=self._config.request_timeout,
                               verify=self._config.request_verify)
        return ret_type(**r.json()) if 199 < r.status_code < 300 else self._handle_error(r)

    def invoke_rest_put(self, endpoint: str, req_body: APIRequest, ret_type: T) -> T | ErrorList:
        r = self._session.put(self._config.base_url + '/' + endpoint,
                              data=req_body.model_dump_json(by_alias=True, exclude_none=True).encode('utf8'),
                              timeout=self._config.request_timeout,
                              verify=self._config.request_verify)
        return ret_type(**r.json()) if 199 < r.status_code < 300 else self._handle_error(r)

    def invoke_rest_put_file(self, endpoint: str, mime_type: str, req_body: BytesIO, ret_type: T) \
            -> T | ErrorList:
        headers_to_use = self._config.headers.copy()
        headers_to_use['Content-Type'] = mime_type
        r = self._session.put(self._config.base_url + '/' + endpoint, data=req_body, headers=headers_to_use,
                              timeout=self._config.request_timeout,
                              verify=self._config.request_verify)
        return ret_type(**r.json()) if 199 < r.status_code < 300 else self._handle_error(r)

    def invoke_rest_patch(self, endpoint: str, req_body: APIRequest, ret_type: T) -> T | ErrorList:
        r = self._session.patch(self._config.base_url + '/' + endpoint,
                                timeout=self._config.request_timeout,
                                verify=self._config.request_verify,
                                data=req_body.model_dump_json(by_alias=True, exclude_none=True).encode('utf8'))
        return ret_type(**r.json()) if 199 < r.status_code < 300 else self._handle_error(r)

    def invoke_rest_patch_file(self, endpoint: str, mime_type: str, req_body: BytesIO, ret_type: T) \
            -> T | ErrorList:
        headers_to_use = self._config.headers.copy()
        headers_to_use['Content-Type'] = mime_type
        r = self._session.patch(self._config.base_url + '/' + endpoint, data=req_body, headers=headers_to_use,
                                timeout=self._config.request_timeout,
                                verify=self._config.request_verify)
        return ret_type(**r.json()) if 199 < r.status_code < 300 else self._handle_error(r)

    def invoke_rest_get(self, endpoint: str, ret_type: T, use_pagination: bool = False) -> T | ErrorList:
        return self._get_paged_response(endpoint, use_pagination,
                                        lambda url: self._session.get(url), ret_type)

    def invoke_rest_get_file(self, endpoint: str) -> File | ErrorList:
        headers_to_use = self._config.headers.copy()
        headers_to_use['Accept'] = 'application/octet-stream'
        r = self._session.get(self._config.base_url + '/' + endpoint, headers=headers_to_use, timeout=self._config.request_timeout,
                              verify=self._config.request_verify)
        mime_type = r.headers['content-type']
        filename = unquote(re.findall(r"filename\*=utf-8''(.+)", r.headers['content-disposition'])[
                               0]) if 'content-disposition' in r.headers else None
        return File(filename=filename, content=r.content,
                    mime_type=mime_type) if 199 < r.status_code < 300 else self._handle_error(r)

    def invoke_rest_delete(self, endpoint: str) -> None | ErrorList:
        r = self._session.delete(self._config.base_url + '/' + endpoint, timeout=self._config.request_timeout,
                                 verify=self._config.request_verify)
        return None if 199 < r.status_code < 300 else self._handle_error(r)

    def _get_paged_response(self, endpoint: str, use_pagination: bool, request_operation: Callable[[str],
    requests.Response], ret_type: T) -> T | ErrorList:
        url = f'{self._config.base_url}/{endpoint}'
        if use_pagination and self._config.next_limit is not None:
            url = url + ('&' if '?' in url else '?') + f'page[limit]={self._config.next_limit}'

        ret_val = None
        while url is not None:
            r = request_operation(url)
            if 199 < r.status_code < 300:
                curr_val = ret_type(**r.json())
                if ret_val is None:
                    ret_val = curr_val
                else:
                    ret_val.extend(curr_val)
                url = ret_val.next_link() if self._config.auto_expand else None
            else:
                return self._handle_error(r)
        return ret_val

    def _handle_error(self, r: requests.Response) -> ErrorList:
        try:
            error_list = ErrorList(**r.json())
            if self._config.raise_on_signals_error:
                raise SignalsException(error_list)
            else:
                return error_list
        except ValidationError:
            r.raise_for_status()
        except SignalsException:
            raise
        except:
            if r.status_code == 429:
                error = {'status': 429, 'code': 'Too many requests'}
                if 'retry-after' in r.headers:
                    error['detail'] = f"Retry after {r.headers['retry-after']} seconds"
                if self._config.raise_on_signals_error:
                    raise SignalsException(ErrorList(errors=[Error(**error)]))
                else:
                    return ErrorList(errors=[Error(**error)])
            else:
                r.raise_for_status()
