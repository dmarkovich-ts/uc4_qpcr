from pydantic import BaseModel
from typing import Any
from collections.abc import Callable, Awaitable
from httpx import Request as HttpxRequest, Response as  HttpxResponse
from requests import Response as RequestsResponse

RequestType = HttpxRequest # Requests no longer supports request hooks
ResponseType = HttpxResponse | RequestsResponse

EventHookRequestType = Callable[[RequestType], None] | Callable[[RequestType], Awaitable]
EventHookResponseType = Callable[[ResponseType], None] | Callable[[ResponseType], Awaitable]

class RestConfig(BaseModel):
    base_url: str
    next_limit: int = 100
    request_timeout: int = 30
    request_verify: bool = True
    auto_expand: bool = True
    raise_on_signals_error: bool = False
    headers: dict[str, str] = None
    request_retry: dict[str, Any] = {}
    request_event_hooks: list[EventHookRequestType] = []
    response_event_hooks: list[EventHookResponseType] = []
