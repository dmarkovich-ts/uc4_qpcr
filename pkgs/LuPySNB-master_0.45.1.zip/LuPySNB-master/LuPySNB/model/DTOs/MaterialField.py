from pydantic import BaseModel
from typing import Optional
from LuPySNB.model.DTOs import MaterialFieldValue


class MaterialField(BaseModel):
    id: str = None
    name: str = None

    value: Optional[MaterialFieldValue.MaterialFieldValueTypes] = None
    values: Optional[list[MaterialFieldValue.MaterialFieldValueTypes]] = None
